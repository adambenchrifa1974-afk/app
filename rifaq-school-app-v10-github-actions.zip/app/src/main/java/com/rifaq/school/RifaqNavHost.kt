package com.rifaq.school

import android.graphics.Color as AndroidColor
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DynamicFeed
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.DynamicFeed
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.rifaq.school.core.common.auth.AuthRepository
import com.rifaq.school.core.designsystem.component.backdropSource
import com.rifaq.school.core.designsystem.component.rememberBackdropState
import com.rifaq.school.core.navigation.RifaqDestination
import com.rifaq.school.feature.authentication.LoginScreen
import com.rifaq.school.feature.authentication.WelcomeScreen
import com.rifaq.school.feature.chat.ChatDetailRoute
import com.rifaq.school.feature.challenges.ChallengesRoute
import com.rifaq.school.feature.challenges.QuizRoute
import com.rifaq.school.feature.chat.ChatRoute
import com.rifaq.school.feature.chat.NewChatRoute
import com.rifaq.school.feature.groups.GroupsRoute
import com.rifaq.school.feature.home.CreatePostRoute
import com.rifaq.school.feature.home.HomeRoute
import com.rifaq.school.feature.home.NotificationsRoute
import com.rifaq.school.feature.home.ReelsRoute
import com.rifaq.school.feature.planner.PlannerRoute
import com.rifaq.school.feature.posts.PostsRoute
import com.rifaq.school.feature.profile.ProfileRoute
import com.rifaq.school.feature.profile.SettingsScreen
import com.rifaq.school.feature.subjects.SubjectDetailRoute
import com.rifaq.school.feature.subjects.SubjectsRoute

private data class TopLevelTab(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val selectedIcon: ImageVector,
)

// الترتيب هنا يبدأ من اليمين في الواجهة العربية (RTL).
private val TopLevelTabs = listOf(
    TopLevelTab(RifaqDestination.HOME, "الرئيسية", Icons.Outlined.Home, Icons.Filled.Home),
    TopLevelTab(RifaqDestination.SUBJECTS, "المواد", Icons.Outlined.MenuBook, Icons.Filled.MenuBook),
    TopLevelTab(RifaqDestination.POSTS, "استكشاف", Icons.Outlined.DynamicFeed, Icons.Filled.DynamicFeed),
    TopLevelTab(RifaqDestination.REELS, "ريلز", Icons.Outlined.PlayArrow, Icons.Filled.PlayArrow),
    TopLevelTab(RifaqDestination.GROUPS, "المجموعات", Icons.Outlined.Groups, Icons.Filled.Groups),
    TopLevelTab(RifaqDestination.PROFILE, "حسابي", Icons.Outlined.Person, Icons.Filled.Person),
)

private val DetailSpring = spring<IntOffset>(
    dampingRatio = 0.85f,
    stiffness = Spring.StiffnessMediumLow,
)

@Composable
fun RifaqApp(darkMode: Boolean, onDarkModeChange: (Boolean) -> Unit) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val route = backStackEntry?.destination?.route
    val showBottomBar = TopLevelTabs.any { it.route == route }
    val backdrop = rememberBackdropState()

    // أيقونات شريط الحالة تتبع الوضع الفاتح/الداكن.
    val activity = LocalContext.current as? ComponentActivity
    LaunchedEffect(darkMode) {
        val style = if (darkMode) {
            SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        } else {
            SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
        }
        activity?.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
    }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        // انتقالات ناعمة كالماء: تلاشٍ مع تكبير خفيف، ونوابض في الشاشات الفرعية.
        NavHost(
            navController = navController,
            startDestination = if (AuthRepository.isSignedIn) RifaqDestination.HOME else RifaqDestination.WELCOME,
            modifier = Modifier.fillMaxSize().backdropSource(backdrop),
            enterTransition = {
                fadeIn(tween(260)) + scaleIn(
                    initialScale = 0.96f,
                    animationSpec = tween(320, easing = FastOutSlowInEasing),
                )
            },
            exitTransition = { fadeOut(tween(160)) },
            popEnterTransition = {
                fadeIn(tween(260)) + scaleIn(
                    initialScale = 0.96f,
                    animationSpec = tween(320, easing = FastOutSlowInEasing),
                )
            },
            popExitTransition = { fadeOut(tween(160)) },
        ) {
            composable(RifaqDestination.WELCOME) {
                WelcomeScreen(
                    onStart = { navController.navigate(RifaqDestination.LOGIN) },
                    onLoginClick = { navController.navigate(RifaqDestination.LOGIN) },
                )
            }
            composable(RifaqDestination.LOGIN) {
                LoginScreen(
                    onLoginSuccess = {
                        navController.navigate(RifaqDestination.HOME) {
                            popUpTo(RifaqDestination.WELCOME) { inclusive = true }
                        }
                    },
                )
            }
            composable(RifaqDestination.HOME) {
                HomeRoute(
                    onCreatePost = { navController.navigate(RifaqDestination.CREATE) },
                    onOpenPlanner = { navController.navigate(RifaqDestination.PLANNER) },
                    onOpenChallenges = { navController.navigate(RifaqDestination.CHALLENGES) },
                    onOpenChats = { navController.navigate(RifaqDestination.CHATS) },
                    onOpenNotifications = { navController.navigate(RifaqDestination.NOTIFICATIONS) },
                    onOpenReels = { navController.navigate(RifaqDestination.REELS) },
                )
            }
            composable(RifaqDestination.SUBJECTS) {
                SubjectsRoute(onOpenSubject = { id -> navController.navigate(RifaqDestination.subjectDetail(id)) })
            }
            composable(
                route = RifaqDestination.SUBJECT_DETAIL,
                arguments = listOf(navArgument(RifaqDestination.SUBJECT_ID_ARG) { type = NavType.StringType }),
                enterTransition = { slideInHorizontally(DetailSpring) { -it } + fadeIn(tween(200)) },
                popExitTransition = { slideOutHorizontally(DetailSpring) { -it } + fadeOut(tween(180)) },
            ) { entry ->
                SubjectDetailRoute(
                    subjectId = entry.arguments?.getString(RifaqDestination.SUBJECT_ID_ARG).orEmpty(),
                    onBack = { navController.popBackStack() },
                )
            }
            composable(
                route = RifaqDestination.CHATS,
                enterTransition = { slideInHorizontally(DetailSpring) { -it } + fadeIn(tween(200)) },
                popExitTransition = { slideOutHorizontally(DetailSpring) { -it } + fadeOut(tween(180)) },
            ) {
                ChatRoute(
                    onOpenChat = { id -> navController.navigate(RifaqDestination.chatDetail(id)) },
                    onNewChat = { navController.navigate(RifaqDestination.NEW_CHAT) },
                    onBack = { navController.popBackStack() },
                )
            }
            composable(
                route = RifaqDestination.NEW_CHAT,
                enterTransition = { slideInHorizontally(DetailSpring) { -it } + fadeIn(tween(200)) },
                popExitTransition = { slideOutHorizontally(DetailSpring) { -it } + fadeOut(tween(180)) },
            ) {
                NewChatRoute(
                    onBack = { navController.popBackStack() },
                    onOpened = { id ->
                        navController.navigate(RifaqDestination.chatDetail(id)) {
                            popUpTo(RifaqDestination.NEW_CHAT) { inclusive = true }
                        }
                    },
                )
            }
            composable(RifaqDestination.POSTS) { PostsRoute() }
            composable(RifaqDestination.GROUPS) { GroupsRoute() }
            composable(RifaqDestination.PROFILE) {
                ProfileRoute(
                    onOpenSettings = { navController.navigate(RifaqDestination.SETTINGS) },
                    onOpenChallenges = { navController.navigate(RifaqDestination.CHALLENGES) },
                )
            }
            composable(
                route = RifaqDestination.SETTINGS,
                enterTransition = { slideInHorizontally(DetailSpring) { -it } + fadeIn(tween(200)) },
                popExitTransition = { slideOutHorizontally(DetailSpring) { -it } + fadeOut(tween(180)) },
            ) {
                SettingsScreen(
                    darkMode = darkMode,
                    onDarkModeChange = onDarkModeChange,
                    onBack = { navController.popBackStack() },
                    onLogout = {
                        AuthRepository.signOut()
                        navController.navigate(RifaqDestination.WELCOME) {
                            popUpTo(navController.graph.id) { inclusive = true }
                        }
                    },
                )
            }
            composable(
                route = RifaqDestination.PLANNER,
                enterTransition = { slideInHorizontally(DetailSpring) { -it } + fadeIn(tween(200)) },
                popExitTransition = { slideOutHorizontally(DetailSpring) { -it } + fadeOut(tween(180)) },
            ) {
                PlannerRoute(onBack = { navController.popBackStack() })
            }
            composable(
                route = RifaqDestination.CHALLENGES,
                enterTransition = { slideInHorizontally(DetailSpring) { -it } + fadeIn(tween(200)) },
                popExitTransition = { slideOutHorizontally(DetailSpring) { -it } + fadeOut(tween(180)) },
            ) {
                ChallengesRoute(
                    onBack = { navController.popBackStack() },
                    onOpenQuiz = { id, daily ->
                        navController.navigate(RifaqDestination.quiz(id, daily))
                    },
                )
            }
            composable(
                route = RifaqDestination.QUIZ,
                arguments = listOf(
                    navArgument(RifaqDestination.QUIZ_ID_ARG) { type = NavType.StringType },
                    navArgument(RifaqDestination.QUIZ_DAILY_ARG) { type = NavType.StringType },
                ),
                enterTransition = { slideInHorizontally(DetailSpring) { -it } + fadeIn(tween(200)) },
                popExitTransition = { slideOutHorizontally(DetailSpring) { -it } + fadeOut(tween(180)) },
            ) {
                QuizRoute(onBack = { navController.popBackStack() })
            }
            composable(
                route = RifaqDestination.CHAT_DETAIL,
                arguments = listOf(
                    navArgument(RifaqDestination.CHAT_ID_ARG) { type = NavType.StringType },
                ),
                enterTransition = { slideInHorizontally(DetailSpring) { -it } + fadeIn(tween(200)) },
                popExitTransition = { slideOutHorizontally(DetailSpring) { -it } + fadeOut(tween(180)) },
            ) {
                ChatDetailRoute(onBack = { navController.popBackStack() })
            }
            composable(
                route = RifaqDestination.NOTIFICATIONS,
                enterTransition = { slideInHorizontally(DetailSpring) { -it } + fadeIn(tween(200)) },
                popExitTransition = { slideOutHorizontally(DetailSpring) { -it } + fadeOut(tween(180)) },
            ) {
                NotificationsRoute(onBack = { navController.popBackStack() })
            }
            composable(
                route = RifaqDestination.REELS,
                enterTransition = { slideInVertically(spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow)) { it } + fadeIn(tween(200)) },
                popExitTransition = { slideOutVertically(spring(dampingRatio = 0.9f, stiffness = Spring.StiffnessMedium)) { it } + fadeOut(tween(180)) },
            ) {
                ReelsRoute(onBack = { navController.popBackStack() })
            }
            composable(
                route = RifaqDestination.CREATE,
                enterTransition = { slideInVertically(spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow)) { it } + fadeIn(tween(200)) },
                popExitTransition = { slideOutVertically(spring(dampingRatio = 0.9f, stiffness = Spring.StiffnessMedium)) { it } + fadeOut(tween(180)) },
            ) {
                CreatePostRoute(onClose = { navController.popBackStack() })
            }
        }

        AnimatedVisibility(
            visible = showBottomBar,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(
                spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow),
            ) { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
            InstaTabBar(
                route = route,
                onSelect = { target ->
                    navController.navigate(target) {
                        popUpTo(RifaqDestination.HOME) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
            )
        }
    }
}

/** شريط تنقل مسطّح بأسلوب إنستغرام: أيقونات فقط، خط فاصل رفيع، والأيقونة المحددة ممتلئة وترتد قليلًا. */
@Composable
private fun InstaTabBar(
    route: String?,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val scheme = MaterialTheme.colorScheme
    Column(
        modifier
            .fillMaxWidth()
            .background(scheme.background),
    ) {
        Box(Modifier.fillMaxWidth().height(0.5.dp).background(scheme.outline))
        Row(Modifier.fillMaxWidth().navigationBarsPadding().height(52.dp)) {
            TopLevelTabs.forEach { tab ->
                val selected = tab.route == route
                val iconScale by animateFloatAsState(
                    targetValue = if (selected) 1.15f else 1f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessMedium,
                    ),
                    label = "tabScale",
                )
                val interaction = remember { MutableInteractionSource() }
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(interactionSource = interaction, indication = null) {
                            onSelect(tab.route)
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (selected) tab.selectedIcon else tab.icon,
                        contentDescription = tab.label,
                        tint = if (selected) scheme.onBackground else scheme.onSurfaceVariant,
                        modifier = Modifier.size(27.dp).scale(iconScale),
                    )
                }
            }
        }
    }
}
