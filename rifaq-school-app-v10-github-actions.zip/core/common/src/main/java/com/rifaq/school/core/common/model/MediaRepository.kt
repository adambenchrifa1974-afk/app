package com.rifaq.school.core.common.model

import android.net.Uri
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.tasks.await
import java.util.UUID

/** Uploads user-selected media to private-by-rules Firebase Storage paths. */
object MediaRepository {
    private val storage get() = FirebaseStorage.getInstance()

    /** Upload a post image and return its download URL; callers should surface failures to the user. */
    suspend fun uploadPostImage(uri: Uri): String {
        val uid = FirebaseAuth.getInstance().currentUser?.uid
            ?: throw IllegalStateException("يجب تسجيل الدخول قبل رفع صورة")
        val ref = storage.reference.child("post-media/$uid/${UUID.randomUUID()}.jpg")
        ref.putFile(uri).await()
        return ref.downloadUrl.await().toString()
    }

    /** Upload a story image. The document metadata and expiry are stored separately in Firestore. */
    suspend fun uploadStoryImage(uri: Uri): String {
        val uid = FirebaseAuth.getInstance().currentUser?.uid
            ?: throw IllegalStateException("يجب تسجيل الدخول قبل رفع قصة")
        val ref = storage.reference.child("story-media/$uid/${UUID.randomUUID()}.jpg")
        ref.putFile(uri).await()
        return ref.downloadUrl.await().toString()
    }

    /** Upload a short video; Firebase Storage rules enforce the maximum size and MIME type. */
    suspend fun uploadReelVideo(uri: Uri): String {
        val uid = FirebaseAuth.getInstance().currentUser?.uid
            ?: throw IllegalStateException("يجب تسجيل الدخول قبل رفع فيديو")
        val ref = storage.reference.child("reel-media/$uid/${UUID.randomUUID()}.mp4")
        ref.putFile(uri).await()
        return ref.downloadUrl.await().toString()
    }
}
