package com.rifaq.school.core.common.model

import android.net.Uri
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import java.util.Date

/** Firebase-backed entry points for social features; caller must handle and display thrown errors. */
object SocialCloudRepository {
    private val auth get() = FirebaseAuth.getInstance()
    private val db get() = FirebaseFirestore.getInstance()

    private fun requireUid(): String = auth.currentUser?.uid
        ?: throw IllegalStateException("يجب تسجيل الدخول أولاً")

    suspend fun createStory(imageUri: Uri): String {
        val uid = requireUid()
        val mediaUrl = MediaRepository.uploadStoryImage(imageUri)
        val expiresAt = Date(System.currentTimeMillis() + 24L * 60 * 60 * 1000)
        val doc = db.collection("stories").document()
        doc.set(
            mapOf(
                "authorUid" to uid,
                "authorName" to (ProfileRepository.profile.value.name),
                "mediaUrl" to mediaUrl,
                "createdAt" to FieldValue.serverTimestamp(),
                "expiresAt" to Timestamp(expiresAt),
                "viewedBy" to emptyList<String>(),
            ),
        ).await()
        return doc.id
    }

    suspend fun createReel(videoUri: Uri, caption: String): String {
        val uid = requireUid()
        val cleanCaption = caption.trim().take(2200)
        val videoUrl = MediaRepository.uploadReelVideo(videoUri)
        val doc = db.collection("reels").document()
        doc.set(
            mapOf(
                "authorUid" to uid,
                "authorName" to ProfileRepository.profile.value.name,
                "caption" to cleanCaption,
                "videoUrl" to videoUrl,
                "likedBy" to emptyList<String>(),
                "commentCount" to 0,
                "createdAt" to FieldValue.serverTimestamp(),
            ),
        ).await()
        return doc.id
    }

    suspend fun follow(targetUid: String) {
        val uid = requireUid()
        require(targetUid.isNotBlank() && targetUid != uid) { "لا يمكن متابعة هذا الحساب" }
        db.collection("follows").document("${uid}_$targetUid").set(
            mapOf(
                "followerUid" to uid,
                "followingUid" to targetUid,
                "createdAt" to FieldValue.serverTimestamp(),
            ),
        ).await()
    }

    suspend fun unfollow(targetUid: String) {
        val uid = requireUid()
        db.collection("follows").document("${uid}_$targetUid").delete().await()
    }

    suspend fun report(targetType: String, targetId: String, reason: String) {
        val uid = requireUid()
        val cleanReason = reason.trim().take(500)
        require(targetType in setOf("post", "reel", "story", "user", "comment"))
        require(targetId.isNotBlank() && cleanReason.isNotBlank()) { "حدد المحتوى وسبب الإبلاغ" }
        db.collection("reports").add(
            mapOf(
                "reporterUid" to uid,
                "targetType" to targetType,
                "targetId" to targetId,
                "reason" to cleanReason,
                "status" to "open",
                "createdAt" to FieldValue.serverTimestamp(),
            ),
        ).await()
    }
}
