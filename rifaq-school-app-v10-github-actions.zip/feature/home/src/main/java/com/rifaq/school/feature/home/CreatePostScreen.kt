package com.rifaq.school.feature.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import android.net.Uri
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.style.TextOverflow
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import com.rifaq.school.core.common.model.MediaRepository
import com.rifaq.school.core.common.model.DemoData
import com.rifaq.school.core.common.model.FeedRepository
import com.rifaq.school.core.designsystem.component.RifaqAvatar
import com.rifaq.school.core.designsystem.component.RifaqCover
import com.rifaq.school.core.designsystem.component.RifaqHeader

/** شاشة إنشاء منشور: نص مع صورة حقيقية اختيارية تُرفع إلى Firebase Storage. */
@Composable
fun CreatePostRoute(onClose: () -> Unit) {
    var text by rememberSaveable { mutableStateOf("") }
    var cover by rememberSaveable { mutableStateOf<Int?>(null) }
    var selectedImage by remember { mutableStateOf<Uri?>(null) }
    var uploading by remember { mutableStateOf(false) }
    var uploadError by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedImage = uri
        uploadError = null
    }
    val scheme = MaterialTheme.colorScheme

    Column(Modifier.fillMaxSize().background(scheme.background).imePadding()) {
        RifaqHeader(
            title = "منشور جديد",
            leading = {
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.Close, contentDescription = "إغلاق")
                }
            },
            trailing = {
                TextButton(
                    onClick = {
                        if (uploading) return@TextButton
                        scope.launch {
                            uploading = true
                            uploadError = null
                            try {
                                val mediaUrl = selectedImage?.let { MediaRepository.uploadPostImage(it) }
                                FeedRepository.addPost(text, cover, mediaUrl)
                                onClose()
                            } catch (error: Exception) {
                                uploadError = error.localizedMessage ?: "تعذّر نشر المنشور. تحقق من اتصالك وإعدادات Firebase Storage."
                            } finally {
                                uploading = false
                            }
                        }
                    },
                    enabled = text.isNotBlank() && !uploading,
                ) {
                    if (uploading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    else Text("نشر", fontWeight = FontWeight.Bold)
                }
            },
        )
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RifaqAvatar(DemoData.user.name, size = 44.dp)
                Text(
                    DemoData.user.name,
                    modifier = Modifier.padding(horizontal = 12.dp),
                    style = MaterialTheme.typography.titleMedium,
                )
            }
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("ما الذي يدور في ذهنك؟") },
                minLines = 4,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = scheme.surfaceVariant,
                    unfocusedContainerColor = scheme.surfaceVariant,
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                ),
            )
            Text("إضافة صورة حقيقية", style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = { imagePicker.launch("image/*") }) {
                Text(if (selectedImage == null) "اختيار صورة من الجهاز" else "تغيير الصورة")
            }
            selectedImage?.let { uri ->
                AsyncImage(
                    model = uri,
                    contentDescription = "معاينة الصورة المختارة",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().aspectRatio(1.15f).clip(RoundedCornerShape(16.dp)),
                )
            }
            uploadError?.let { Text(it, color = MaterialTheme.colorScheme.error, maxLines = 3, overflow = TextOverflow.Ellipsis) }
            Text("أو اختر غلافًا لونيًا", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(scheme.surfaceVariant)
                        .border(
                            if (cover == null) 2.dp else 0.dp,
                            scheme.primary,
                            CircleShape,
                        )
                        .clickable { cover = null },
                    contentAlignment = Alignment.Center,
                ) { Text("بدون", style = MaterialTheme.typography.bodyMedium) }
                for (i in 0..5) {
                    RifaqCover(
                        seed = i,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .border(
                                if (cover == i) 2.dp else 0.dp,
                                scheme.primary,
                                CircleShape,
                            )
                            .clickable { cover = i },
                    )
                }
            }
            val selected = cover
            if (selected != null) {
                RifaqCover(
                    seed = selected,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1.6f)
                        .clip(RoundedCornerShape(16.dp)),
                )
            }
        }
    }
}
