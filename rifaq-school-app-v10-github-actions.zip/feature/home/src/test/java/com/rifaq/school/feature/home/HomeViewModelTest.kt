package com.rifaq.school.feature.home

import com.rifaq.school.core.common.model.DemoData
import com.rifaq.school.core.common.model.SocialRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * المنشورات تأتي من Firestore (فارغة قبل تسجيل الدخول)، لذلك نختبر هنا المنطق المحلي فقط
 * دون إنشاء HomeViewModel الذي يحتاج Firebase.
 */
class HomeViewModelTest {
    @Test
    fun demoStories_startWithMyStory() {
        assertTrue(DemoData.stories.isNotEmpty())
        assertTrue(DemoData.stories.first().isMine)
    }

    @Test
    fun toggleFollow_addsThenRemoves() {
        val name = "اسم تجريبي"
        assertFalse(name in SocialRepository.followed.value)
        SocialRepository.toggleFollow(name)
        assertTrue(name in SocialRepository.followed.value)
        SocialRepository.toggleFollow(name)
        assertFalse(name in SocialRepository.followed.value)
    }

    @Test
    fun markStoryViewed_isRecorded() {
        SocialRepository.markStoryViewed(3)
        assertTrue(3 in SocialRepository.viewedStories.value)
        assertEquals(1, SocialRepository.viewedStories.value.count { it == 3 })
    }
}
