package com.rifaq.school.core.common.model

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * مصدر منشورات الرئيسية وتعليقاتها في الذاكرة فقط (يُفقد عند إغلاق التطبيق).
 * سيُستبدل لاحقًا بمستودع حقيقي مدعوم بالشبكة وقاعدة البيانات.
 */
object FeedRepository {
    private val _posts = MutableStateFlow(DemoData.posts)
    val posts: StateFlow<List<Post>> = _posts.asStateFlow()

    /** التعليقات حسب رقم المنشور (أو رقم الريلز + [REEL_ID_OFFSET]). */
    private val _comments = MutableStateFlow<Map<Int, List<Comment>>>(
        DemoData.posts.associate { it.id to DemoData.comments },
    )
    val comments: StateFlow<Map<Int, List<Comment>>> = _comments.asStateFlow()

    fun addPost(text: String, cover: Int?) {
        val user = ProfileRepository.profile.value
        _posts.update { current ->
            val nextId = (current.maxOfOrNull { it.id } ?: 0) + 1
            listOf(
                Post(
                    id = nextId,
                    authorName = user.name,
                    authorRole = "طالب",
                    timeAgo = "الآن",
                    text = text.trim(),
                    likes = 0,
                    comments = 0,
                    cover = cover,
                ),
            ) + current
        }
    }

    fun toggleLike(postId: Int) = updatePost(postId) {
        it.copy(liked = !it.liked, likes = (it.likes + if (it.liked) -1 else 1).coerceAtLeast(0))
    }

    /** إعجاب فقط (للنقر المزدوج): لا يلغي الإعجاب إن كان موجودًا. */
    fun like(postId: Int) {
        if (_posts.value.firstOrNull { it.id == postId }?.liked == false) toggleLike(postId)
    }

    fun toggleSave(postId: Int) = updatePost(postId) { it.copy(saved = !it.saved) }

    fun deletePost(postId: Int) {
        _posts.update { list -> list.filterNot { it.id == postId } }
    }

    /** إخفاء منشور من الرئيسية فقط (لا يحذفه). */
    fun hidePost(postId: Int) = deletePost(postId)

    fun addComment(postId: Int, text: String, parentId: Int? = null) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val author = ProfileRepository.profile.value.name
        _comments.update { map ->
            val current = map[postId].orEmpty()
            val nextId = (current.maxOfOrNull { it.id } ?: 0) + 1
            map + (postId to current + Comment(nextId, author, clean, parentId = parentId))
        }
        updatePost(postId) { it.copy(comments = it.comments + 1) }
    }

    fun toggleCommentLike(postId: Int, commentId: Int) {
        _comments.update { map ->
            val current = map[postId] ?: return@update map
            map + (
                postId to current.map {
                    if (it.id == commentId) {
                        it.copy(liked = !it.liked, likes = (it.likes + if (it.liked) -1 else 1).coerceAtLeast(0))
                    } else {
                        it
                    }
                }
                )
        }
    }

    private fun updatePost(postId: Int, change: (Post) -> Post) {
        _posts.update { list -> list.map { if (it.id == postId) change(it) else it } }
    }

    const val REEL_ID_OFFSET = 1000
}
