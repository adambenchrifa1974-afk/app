package com.rifaq.school.core.common.model

data class UserProfile(
    val name: String,
    val role: String,
    val posts: Int,
    val followers: Int,
    val following: Int,
) {
    val firstName: String get() = name.substringBefore(' ')
}

data class Story(val id: Int, val name: String, val isMine: Boolean = false)

/** [cover] رقم الغلاف الملوّن للصورة، أو null إذا كان المنشور نصيًا فقط. */
data class Post(
    val id: Int,
    val authorName: String,
    val authorRole: String,
    val timeAgo: String,
    val text: String,
    val likes: Int,
    val comments: Int,
    val cover: Int?,
    val liked: Boolean = false,
    val saved: Boolean = false,
)

/** تعليق على منشور أو ريلز. [parentId] غير فارغ يعني أنه رد على تعليق آخر. */
data class Comment(
    val id: Int,
    val author: String,
    val text: String,
    val timeAgo: String = "الآن",
    val likes: Int = 0,
    val liked: Boolean = false,
    val parentId: Int? = null,
)

/** مقطع ريلز قصير (يُعرض حاليًا كغلاف ملوّن إلى حين ربط الفيديو الحقيقي). */
data class Reel(
    val id: Int,
    val author: String,
    val caption: String,
    val music: String,
    val cover: Int,
    val likes: Int,
    val comments: Int,
)

enum class NoticeKind { LIKE, COMMENT, FOLLOW, MENTION }

/** إشعار في شاشة النشاط. [today] لتقسيمها إلى «اليوم» و«هذا الأسبوع». */
data class Notice(
    val id: Int,
    val user: String,
    val kind: NoticeKind,
    val text: String,
    val timeAgo: String,
    val cover: Int? = null,
    val today: Boolean = true,
)

data class ChatPreview(
    val id: Int,
    val name: String,
    val lastMessage: String,
    val time: String,
    val unread: Int,
)

data class ChatMessage(val id: Int, val text: String, val mine: Boolean, val time: String)

data class GroupPreview(
    val id: Int,
    val name: String,
    val symbol: String,
    val members: Int,
    val posts: Int,
)

data class ExploreItem(
    val id: Int,
    val title: String,
    val author: String,
    val likes: Int,
    val category: String,
    /** نسبة الارتفاع إلى العرض لبطاقة الصورة. */
    val ratio: Float,
)
