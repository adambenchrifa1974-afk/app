package com.rifaq.school.core.navigation

object RifaqDestination {
    const val WELCOME = "welcome"
    const val LOGIN = "login"
    const val HOME = "home"
    const val CHATS = "chats"
    const val POSTS = "posts"
    const val GROUPS = "groups"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"
    const val CREATE = "create"
    const val PLANNER = "planner"
    const val CHALLENGES = "challenges"
    const val SUBJECTS = "subjects"
    const val NOTIFICATIONS = "notifications"
    const val REELS = "reels"

    const val SUBJECT_ID_ARG = "subjectId"
    const val SUBJECT_DETAIL = "subject/{$SUBJECT_ID_ARG}"
    fun subjectDetail(id: String) = "subject/$id"

    const val QUIZ_ID_ARG = "id"
    const val QUIZ_DAILY_ARG = "daily"
    const val QUIZ = "quiz/{$QUIZ_ID_ARG}/{$QUIZ_DAILY_ARG}"
    fun quiz(id: String, daily: Boolean) = "quiz/$id/${if (daily) 1 else 0}"

    const val CHAT_ID_ARG = "id"
    const val CHAT_DETAIL = "chat/{$CHAT_ID_ARG}"
    fun chatDetail(id: Int) = "chat/$id"
}
