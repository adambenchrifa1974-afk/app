package com.rifaq.school.feature.home

import androidx.lifecycle.ViewModel
import com.rifaq.school.core.common.model.DemoData
import com.rifaq.school.core.common.model.FeedRepository
import com.rifaq.school.core.common.model.Post
import com.rifaq.school.core.common.model.SocialRepository
import com.rifaq.school.core.common.model.Story
import com.rifaq.school.core.common.model.UserProfile
import kotlinx.coroutines.flow.StateFlow

class HomeViewModel : ViewModel() {
    val user: UserProfile = DemoData.user
    val stories: List<Story> = DemoData.stories
    val posts: StateFlow<List<Post>> = FeedRepository.posts
    val followed: StateFlow<Set<String>> = SocialRepository.followed
    val viewedStories: StateFlow<Set<Int>> = SocialRepository.viewedStories

    fun toggleLike(id: Int) = FeedRepository.toggleLike(id)
    fun like(id: Int) = FeedRepository.like(id)
    fun toggleSave(id: Int) = FeedRepository.toggleSave(id)
    fun toggleFollow(name: String) = SocialRepository.toggleFollow(name)
    fun unfollow(name: String) = SocialRepository.unfollow(name)
    fun hide(id: Int) = FeedRepository.hidePost(id)
    fun delete(id: Int) = FeedRepository.deletePost(id)
}
