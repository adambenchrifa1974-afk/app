# قواعد R8 الخاصة بالتطبيق (فارغة حاليًا)

# Firebase
-keepattributes Signature,*Annotation*
-keep class com.google.firebase.** { *; }
