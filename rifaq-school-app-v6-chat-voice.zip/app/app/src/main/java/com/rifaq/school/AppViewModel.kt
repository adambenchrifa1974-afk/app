package com.rifaq.school

import androidx.lifecycle.ViewModel
import com.rifaq.school.core.common.storage.LocalStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** حالة على مستوى التطبيق. null = اتباع إعداد النظام. الاختيار محفوظ على الجهاز. */
class AppViewModel : ViewModel() {
    private val _darkOverride = MutableStateFlow(readSaved())
    val darkOverride: StateFlow<Boolean?> = _darkOverride.asStateFlow()

    fun setDarkMode(enabled: Boolean) {
        _darkOverride.value = enabled
        LocalStore.putInt(DARK_KEY, if (enabled) 1 else 0)
    }

    private fun readSaved(): Boolean? = when (LocalStore.getInt(DARK_KEY, -1)) {
        1 -> true
        0 -> false
        else -> null
    }

    private companion object {
        const val DARK_KEY = "dark_mode"
    }
}
