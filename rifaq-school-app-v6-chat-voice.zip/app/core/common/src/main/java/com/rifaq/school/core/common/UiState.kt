package com.rifaq.school.core.common

/** حالة عامة لعرض البيانات القادمة من طبقة غير متزامنة. */
sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}
