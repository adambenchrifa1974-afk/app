package com.rifaq.school.core.common.auth

import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.userProfileChangeRequest
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.rifaq.school.core.common.chat.ChatRepository
import com.rifaq.school.core.common.model.FeedRepository
import com.rifaq.school.core.common.model.ProfileRepository
import kotlinx.coroutines.tasks.await

/** المصادقة عبر Firebase (بريد إلكتروني + كلمة مرور) مع حفظ ملف المستخدم في Firestore. */
object AuthRepository {
    private val auth get() = FirebaseAuth.getInstance()
    private val db get() = FirebaseFirestore.getInstance()

    val isSignedIn: Boolean get() = auth.currentUser != null
    val currentUid: String? get() = auth.currentUser?.uid

    suspend fun signIn(email: String, password: String): Result<Unit> = runCatching {
        val user = auth.signInWithEmailAndPassword(email.trim(), password).await().user ?: error("no user")
        val ref = db.collection("users").document(user.uid)
        val doc = runCatching { ref.get().await() }.getOrNull()
        val name = doc?.getString("name") ?: user.displayName ?: email.substringBefore('@')
        val role = doc?.getString("role") ?: DEFAULT_ROLE
        // ينشئ ملف المستخدم إن لم يكن موجودًا (حسابات أُنشئت قبل ظهور المحادثات).
        ref.set(mapOf("name" to name, "email" to email.trim(), "role" to role), SetOptions.merge())
        ProfileRepository.update(name, role)
        startData()
    }.mapFailure()

    suspend fun signUp(name: String, email: String, password: String): Result<Unit> = runCatching {
        val cleanName = name.trim()
        val user = auth.createUserWithEmailAndPassword(email.trim(), password).await().user
            ?: error("no user")
        user.updateProfile(userProfileChangeRequest { displayName = cleanName }).await()
        db.collection("users").document(user.uid).set(
            mapOf(
                "name" to cleanName,
                "email" to email.trim(),
                "role" to DEFAULT_ROLE,
                "createdAt" to com.google.firebase.Timestamp.now(),
            ),
        ).await()
        ProfileRepository.update(cleanName, DEFAULT_ROLE)
        startData()
    }.mapFailure()

    /** يرسل رابط إعادة تعيين كلمة المرور إلى البريد. */
    suspend fun resetPassword(email: String): Result<Unit> = runCatching {
        auth.sendPasswordResetEmail(email.trim()).await()
        Unit
    }.mapFailure()

    private fun startData() {
        FeedRepository.start()
        ChatRepository.start()
    }

    fun signOut() {
        FeedRepository.stop()
        ChatRepository.stop()
        auth.signOut()
    }

    private fun <T> Result<T>.mapFailure(): Result<T> = recoverCatching { e ->
        throw AuthException(
            when (e) {
                is FirebaseAuthWeakPasswordException -> "كلمة المرور ضعيفة، استخدم 6 أحرف على الأقل"
                is FirebaseAuthUserCollisionException -> "هذا البريد مسجّل مسبقًا، جرّب تسجيل الدخول"
                is FirebaseAuthInvalidUserException,
                is FirebaseAuthInvalidCredentialsException -> "البريد الإلكتروني أو كلمة المرور غير صحيحة"
                is FirebaseNetworkException -> "تعذّر الاتصال بالإنترنت"
                else -> "حدث خطأ غير متوقع، حاول مرة أخرى"
            },
        )
    }

    private const val DEFAULT_ROLE = "طالب"
}

class AuthException(message: String) : Exception(message)
