package com.rifaq.school.core.common.chat

import android.util.Base64
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.DocumentSnapshot.ServerTimestampBehavior
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.rifaq.school.core.common.model.AppUser
import com.rifaq.school.core.common.model.ChatMsg
import com.rifaq.school.core.common.model.ChatSummary
import com.rifaq.school.core.common.model.ProfileRepository
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

/**
 * محادثات فردية حقيقية عبر Firestore:
 *  chats/{uidA_uidB}                 members, memberNames, lastMessage, lastTime, lastSenderUid, unread{uid}
 *  chats/{id}/messages/{mid}         senderUid, type (text|voice), text, seconds, createdAt
 *  chats/{id}/audio/{mid}            data (base64 AAC)، تُجلب عند التشغيل فقط
 * الرسائل الصوتية تُخزَّن داخل Firestore (حد أقصى 60 ثانية ≈ 200 كيلوبايت) ولا تحتاج Firebase Storage.
 */
object ChatRepository {
    private const val CHATS = "chats"
    private const val VOICE_PREVIEW = "🎤 رسالة صوتية"

    private val db get() = FirebaseFirestore.getInstance()
    private val uid: String? get() = FirebaseAuth.getInstance().currentUser?.uid

    private val _chats = MutableStateFlow<List<ChatSummary>>(emptyList())
    val chats: StateFlow<List<ChatSummary>> = _chats.asStateFlow()
    val totalUnread: Flow<Int> = _chats.map { list -> list.sumOf { it.unread } }

    private val names = ConcurrentHashMap<String, String>()
    private var listener: ListenerRegistration? = null

    fun nameOf(chatId: String): String? = names[chatId]

    fun start() {
        val me = uid ?: return
        if (listener != null) return
        listener = db.collection(CHATS).whereArrayContains("members", me)
            .addSnapshotListener { snap, _ ->
                if (snap == null) return@addSnapshotListener
                snap.documents.forEach { d -> d.otherName(me)?.let { names[d.id] = it } }
                _chats.value = snap.documents
                    .mapNotNull { it.toSummary(me) }
                    .filter { it.lastMessage.isNotEmpty() }
                    .sortedByDescending { it.millis }
            }
    }

    fun stop() {
        listener?.remove()
        listener = null
        names.clear()
        _chats.value = emptyList()
    }

    suspend fun loadUsers(): Result<List<AppUser>> = runCatching {
        val me = uid
        db.collection("users").limit(300).get().await().documents.mapNotNull { d ->
            val name = d.getString("name")
            if (d.id == me || name.isNullOrBlank()) null else AppUser(d.id, name, d.getString("role").orEmpty())
        }.sortedBy { it.name }
    }

    /** يفتح (أو ينشئ) محادثة فردية مع [other] ويُرجع معرّفها. */
    suspend fun openDirectChat(other: AppUser): Result<String> = runCatching {
        val me = uid ?: error("not signed in")
        require(other.uid != me)
        val id = listOf(me, other.uid).sorted().joinToString("_")
        val ref = db.collection(CHATS).document(id)
        val exists = runCatching { ref.get().await().exists() }.getOrDefault(false)
        if (!exists) {
            ref.set(
                mapOf(
                    "members" to listOf(me, other.uid),
                    "memberNames" to mapOf(me to ProfileRepository.profile.value.name, other.uid to other.name),
                    "lastMessage" to "",
                    "unread" to mapOf(me to 0, other.uid to 0),
                ),
            )
        }
        names[id] = other.name
        id
    }

    fun messages(chatId: String): Flow<List<ChatMsg>> = callbackFlow {
        val me = uid
        val reg = db.collection(CHATS).document(chatId).collection("messages")
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .addSnapshotListener { snap, _ ->
                if (snap != null) trySend(snap.documents.mapNotNull { it.toMsg(me) })
            }
        awaitClose { reg.remove() }
    }

    fun sendText(chatId: String, text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val me = uid ?: return
        val chatRef = db.collection(CHATS).document(chatId)
        val msgRef = chatRef.collection("messages").document()
        db.batch()
            .set(
                msgRef,
                mapOf(
                    "senderUid" to me,
                    "senderName" to ProfileRepository.profile.value.name,
                    "type" to "text",
                    "text" to clean,
                    "createdAt" to FieldValue.serverTimestamp(),
                ),
            )
            .update(chatRef, bump(chatId, me, clean.take(80)))
            .commit()
    }

    fun sendVoice(chatId: String, bytes: ByteArray, seconds: Int) {
        val me = uid ?: return
        val chatRef = db.collection(CHATS).document(chatId)
        val msgRef = chatRef.collection("messages").document()
        db.batch()
            .set(
                chatRef.collection("audio").document(msgRef.id),
                mapOf("data" to Base64.encodeToString(bytes, Base64.NO_WRAP), "seconds" to seconds),
            )
            .set(
                msgRef,
                mapOf(
                    "senderUid" to me,
                    "senderName" to ProfileRepository.profile.value.name,
                    "type" to "voice",
                    "seconds" to seconds,
                    "createdAt" to FieldValue.serverTimestamp(),
                ),
            )
            .update(chatRef, bump(chatId, me, VOICE_PREVIEW))
            .commit()
    }

    suspend fun loadAudio(chatId: String, msgId: String): ByteArray? {
        val data = runCatching {
            db.collection(CHATS).document(chatId).collection("audio").document(msgId)
                .get().await().getString("data")
        }.getOrNull()
        return data?.let { runCatching { Base64.decode(it, Base64.DEFAULT) }.getOrNull() }
    }

    fun markReadIfNeeded(chatId: String) {
        val me = uid ?: return
        val unread = _chats.value.firstOrNull { it.id == chatId }?.unread ?: 0
        if (unread > 0) db.collection(CHATS).document(chatId).update("unread.$me", 0)
    }

    private fun bump(chatId: String, me: String, preview: String): Map<String, Any> {
        val other = chatId.split("_").firstOrNull { it != me }.orEmpty()
        return mapOf(
            "lastMessage" to preview,
            "lastTime" to FieldValue.serverTimestamp(),
            "lastSenderUid" to me,
            "unread.$other" to FieldValue.increment(1),
        )
    }

    private fun DocumentSnapshot.members(): List<String> =
        (get("members") as? List<*>)?.filterIsInstance<String>().orEmpty()

    private fun DocumentSnapshot.otherName(me: String): String? {
        val other = members().firstOrNull { it != me } ?: return null
        return (get("memberNames") as? Map<*, *>)?.get(other) as? String
    }

    private fun DocumentSnapshot.toSummary(me: String): ChatSummary? {
        val other = members().firstOrNull { it != me } ?: return null
        val millis = getTimestamp("lastTime", ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L
        val unread = ((get("unread") as? Map<*, *>)?.get(me) as? Number)?.toInt() ?: 0
        return ChatSummary(
            id = id,
            name = otherName(me) ?: "مستخدم",
            otherUid = other,
            lastMessage = getString("lastMessage").orEmpty(),
            time = ChatTime.listTime(millis),
            unread = unread,
            millis = millis,
        )
    }

    private fun DocumentSnapshot.toMsg(me: String?): ChatMsg? {
        val millis = getTimestamp("createdAt", ServerTimestampBehavior.ESTIMATE)?.toDate()?.time
        val voice = getString("type") == "voice"
        return ChatMsg(
            id = id,
            text = getString("text").orEmpty(),
            mine = me != null && getString("senderUid") == me,
            time = millis?.let { ChatTime.clock(it) } ?: "الآن",
            voiceSeconds = if (voice) (getLong("seconds") ?: 0L).toInt() else null,
        )
    }
}
