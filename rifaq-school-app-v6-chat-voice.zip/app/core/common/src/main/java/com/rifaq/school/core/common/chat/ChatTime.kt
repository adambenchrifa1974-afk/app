package com.rifaq.school.core.common.chat

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** تنسيق أوقات المحادثات. */
object ChatTime {
    /** ساعة:دقيقة، تُستخدم داخل المحادثة. */
    fun clock(millis: Long): String =
        SimpleDateFormat("HH:mm", Locale.ENGLISH).format(Date(millis))

    /** في قائمة المحادثات: الوقت إن كانت اليوم، «أمس»، وإلا اليوم/الشهر. */
    fun listTime(millis: Long, now: Long = System.currentTimeMillis()): String {
        if (millis <= 0L) return ""
        val day = Calendar.getInstance().apply { timeInMillis = millis }
        val today = Calendar.getInstance().apply { timeInMillis = now }
        val yesterday = Calendar.getInstance().apply {
            timeInMillis = now
            add(Calendar.DAY_OF_YEAR, -1)
        }
        fun same(a: Calendar, b: Calendar) =
            a.get(Calendar.YEAR) == b.get(Calendar.YEAR) &&
                a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
        return when {
            same(day, today) -> clock(millis)
            same(day, yesterday) -> "أمس"
            else -> SimpleDateFormat("d/M", Locale.ENGLISH).format(Date(millis))
        }
    }
}
