package com.rifaq.school.core.common.gamification

import com.rifaq.school.core.common.storage.LocalStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONObject

const val XP_PER_LEVEL = 100

fun levelFor(xp: Int): Int = 1 + xp / XP_PER_LEVEL

data class GamificationStats(
    val xp: Int = 0,
    val quizzesCompleted: Int = 0,
    val perfectScores: Int = 0,
) {
    val level: Int get() = levelFor(xp)
    val xpIntoLevel: Int get() = xp % XP_PER_LEVEL
}

/** 10 نقاط لكل إجابة صحيحة، و20 إضافية للعلامة الكاملة، ومضاعفة في تحدي اليوم. */
fun computeAward(correct: Int, total: Int, isDaily: Boolean): Int {
    if (total <= 0) return 0
    var xp = correct * 10
    if (correct == total) xp += 20
    return if (isDaily) xp * 2 else xp
}

data class Badge(val id: String, val title: String, val description: String)

object Badges {
    val all = listOf(
        Badge("first_quiz", "الخطوة الأولى", "أكمل أول اختبار"),
        Badge("perfect", "علامة كاملة", "أجب عن كل أسئلة اختبار إجابة صحيحة"),
        Badge("xp_100", "مئة نقطة", "اجمع 100 نقطة خبرة"),
        Badge("quiz_5", "مثابر", "أكمل 5 اختبارات"),
        Badge("tasks_5", "منظّم", "أنجز 5 مهام في المخطط"),
        Badge("level_3", "المستوى الثالث", "ابلغ المستوى 3"),
    )

    fun earnedIds(stats: GamificationStats, tasksDone: Int): Set<String> = buildSet {
        if (stats.quizzesCompleted >= 1) add("first_quiz")
        if (stats.perfectScores >= 1) add("perfect")
        if (stats.xp >= 100) add("xp_100")
        if (stats.quizzesCompleted >= 5) add("quiz_5")
        if (tasksDone >= 5) add("tasks_5")
        if (stats.level >= 3) add("level_3")
    }
}

/** نقاط الخبرة والإنجازات، محفوظة على الجهاز نفسه (قابلة للتلاعب محليًا إلى أن يوجد خادم). */
object GamificationRepository {
    private val _stats = MutableStateFlow(GamificationStats())
    val stats: StateFlow<GamificationStats> = _stats.asStateFlow()
    private var loaded = false
    private var awarded: Map<String, String> = emptyMap()

    fun load() {
        if (loaded) return
        loaded = true
        _stats.value = GamificationStats(
            xp = LocalStore.getInt("xp", 0),
            quizzesCompleted = LocalStore.getInt("quizzes_completed", 0),
            perfectScores = LocalStore.getInt("perfect_scores", 0),
        )
        awarded = parseAwarded(LocalStore.getString("awarded", "{}"))
    }

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    /**
     * يسجّل إتمام اختبار ويعيد النقاط الممنوحة. النقاط تُمنح مرة واحدة فقط لكل اختبار في اليوم.
     */
    fun completeQuiz(quizId: String, correct: Int, total: Int, isDaily: Boolean): Int {
        val day = today()
        val key = quizId + "|" + (if (isDaily) "daily" else "free")
        val already = awarded[key] == day
        val xp = if (already) 0 else computeAward(correct, total, isDaily)
        if (!already) {
            awarded = awarded + (key to day)
            _stats.update {
                it.copy(
                    xp = it.xp + xp,
                    quizzesCompleted = it.quizzesCompleted + 1,
                    perfectScores = it.perfectScores + if (correct == total) 1 else 0,
                )
            }
            val s = _stats.value
            LocalStore.putInt("xp", s.xp)
            LocalStore.putInt("quizzes_completed", s.quizzesCompleted)
            LocalStore.putInt("perfect_scores", s.perfectScores)
            LocalStore.putString("awarded", JSONObject(awarded).toString())
        }
        return xp
    }

    private fun parseAwarded(raw: String): Map<String, String> = runCatching {
        val obj = JSONObject(raw)
        buildMap { obj.keys().forEach { key -> put(key, obj.getString(key)) } }
    }.getOrDefault(emptyMap())
}

/** حالة اختبار جارٍ. منطق خالص يسهل اختباره. */
data class QuizState(
    val quiz: Quiz,
    val index: Int = 0,
    val selected: Int? = null,
    val correct: Int = 0,
    val finished: Boolean = false,
    val xpEarned: Int = 0,
) {
    val question: Question get() = quiz.questions[index]
    val answered: Boolean get() = selected != null
}

object QuizLogic {
    fun select(state: QuizState, option: Int): QuizState {
        if (state.finished || state.selected != null) return state
        val isCorrect = option == state.question.correctIndex
        return state.copy(selected = option, correct = state.correct + if (isCorrect) 1 else 0)
    }

    fun advance(state: QuizState): QuizState {
        if (state.finished || state.selected == null) return state
        return if (state.index < state.quiz.questions.lastIndex) {
            state.copy(index = state.index + 1, selected = null)
        } else {
            state.copy(finished = true)
        }
    }
}
