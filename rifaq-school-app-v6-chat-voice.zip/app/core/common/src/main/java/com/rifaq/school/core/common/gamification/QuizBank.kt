package com.rifaq.school.core.common.gamification

data class Question(
    val text: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
)

data class Quiz(
    val id: String,
    val title: String,
    val subject: String,
    val questions: List<Question>,
)

private fun q(text: String, correct: Int, explanation: String, vararg options: String) =
    Question(text, options.toList(), correct, explanation)

object QuizBank {
    val quizzes: List<Quiz> = listOf(
        Quiz(
            id = "math", title = "اختبار الرياضيات", subject = "الرياضيات",
            questions = listOf(
                q("ما ناتج 12 × 8؟", 1, "12 × 8 = 96.", "86", "96", "108", "88"),
                q("ما قيمة π تقريبًا؟", 1, "قيمة π تساوي تقريبًا 3.14.", "2.14", "3.14", "4.13", "3.41"),
                q("ما حل المعادلة 2x + 6 = 14؟", 1, "2x = 8 إذن x = 4.", "x = 3", "x = 4", "x = 5", "x = 10"),
                q("ما مساحة مستطيل طوله 7 وعرضه 5؟", 2, "المساحة = الطول × العرض = 7 × 5 = 35.", "12", "24", "35", "70"),
                q("ما الجذر التربيعي للعدد 81؟", 2, "9 × 9 = 81.", "7", "8", "9", "10"),
            ),
        ),
        Quiz(
            id = "science", title = "اختبار العلوم", subject = "العلوم",
            questions = listOf(
                q("ما وحدة قياس القوة في النظام الدولي؟", 1, "وحدة القوة هي النيوتن.", "الجول", "النيوتن", "الواط", "الباسكال"),
                q("أي غاز تمتصه النباتات في عملية البناء الضوئي؟", 2, "تمتص النباتات ثاني أكسيد الكربون وتطلق الأكسجين.", "الأكسجين", "النيتروجين", "ثاني أكسيد الكربون", "الهيدروجين"),
                q("كم عدد كواكب المجموعة الشمسية؟", 1, "ثمانية كواكب.", "7", "8", "9", "10"),
                q("ما الرمز الكيميائي للماء؟", 1, "جزيء الماء يتكون من ذرتي هيدروجين وذرة أكسجين: H2O.", "CO2", "H2O", "O2", "NaCl"),
                q("ما سرعة الضوء تقريبًا في الفراغ؟", 2, "تساوي تقريبًا 300000 كيلومتر في الثانية.", "300 كم/ث", "3000 كم/ث", "300000 كم/ث", "30000 كم/ث"),
            ),
        ),
        Quiz(
            id = "arabic", title = "اختبار اللغة العربية", subject = "اللغة العربية",
            questions = listOf(
                q("ما إعراب كلمة «العلمُ» في جملة: «العلمُ نورٌ»؟", 0, "هي مبتدأ مرفوع، وكلمة «نورٌ» خبره.", "مبتدأ مرفوع", "خبر مرفوع", "فاعل", "مفعول به"),
                q("ما جمع كلمة «كتاب»؟", 1, "جمع «كتاب» هو «كتب».", "كتابات", "كتب", "كتّاب", "أكتاب"),
                q("ما ضد كلمة «قريب»؟", 0, "ضد القريب هو البعيد.", "بعيد", "سريع", "كبير", "عالٍ"),
                q("أي الكلمات التالية فعل؟", 1, "«كتبَ» فعل ماضٍ، والباقي أسماء.", "مدرسة", "كتبَ", "قلم", "جميل"),
                q("ما مفرد كلمة «رجال»؟", 0, "مفرد «رجال» هو «رجل».", "رجل", "رجلان", "راجل", "رجيل"),
            ),
        ),
        Quiz(
            id = "english", title = "English Quiz", subject = "الإنجليزية",
            questions = listOf(
                q("What is the plural of \"child\"?", 1, "The plural of child is children.", "childs", "children", "childes", "childrens"),
                q("Choose the correct sentence.", 1, "With she/he/it we add -s to the verb: She goes.", "She go to school.", "She goes to school.", "She going to school.", "She gone school."),
                q("What is the opposite of \"hot\"?", 0, "The opposite of hot is cold.", "cold", "big", "fast", "slow"),
                q("She ___ football every Sunday.", 1, "Present simple with she takes -s: plays.", "play", "plays", "playing", "played"),
                q("What is the past tense of \"go\"?", 2, "Go is irregular: go - went - gone.", "go", "goed", "went", "gone"),
            ),
        ),
    )

    fun byId(id: String): Quiz? = quizzes.firstOrNull { it.id == id }

    /** اختبار اليوم يتبدّل كل يوم بالتناوب. */
    fun dailyQuiz(dayOfYear: Int): Quiz = quizzes[Math.floorMod(dayOfYear, quizzes.size)]
}
