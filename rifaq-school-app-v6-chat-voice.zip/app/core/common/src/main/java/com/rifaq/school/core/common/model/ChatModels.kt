package com.rifaq.school.core.common.model

/** ملخص محادثة في قائمة المحادثات. [millis] للترتيب (الأحدث أولًا). */
data class ChatSummary(
    val id: String,
    val name: String,
    val otherUid: String,
    val lastMessage: String,
    val time: String,
    val unread: Int,
    val millis: Long = 0L,
)

/** رسالة في محادثة. [voiceSeconds] غير فارغ يعني أنها رسالة صوتية. */
data class ChatMsg(
    val id: String,
    val text: String,
    val mine: Boolean,
    val time: String,
    val voiceSeconds: Int? = null,
)

/** مستخدم مسجّل يمكن بدء محادثة معه. */
data class AppUser(val uid: String, val name: String, val role: String)
