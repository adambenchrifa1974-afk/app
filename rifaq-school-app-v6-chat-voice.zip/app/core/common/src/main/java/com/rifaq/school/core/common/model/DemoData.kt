package com.rifaq.school.core.common.model

/**
 * بيانات تجريبية لعرض الواجهات فقط. ستُستبدل بمصدر بيانات حقيقي (شبكة/قاعدة بيانات)
 * عند بناء وحدتي network وdatabase.
 */
object DemoData {
    val user = UserProfile(
        name = "أحمد السعيدي",
        role = "طالب في ثانوية ابن رشد",
        posts = 42,
        followers = 124,
        following = 98,
    )

    val stories = listOf(
        Story(0, "قصتي", isMine = true),
        Story(1, "سارة"),
        Story(2, "يوسف"),
        Story(3, "مريم"),
        Story(4, "ليلى"),
    )

    val posts = listOf(
        Post(
            id = "1",
            authorName = "أحمد السعيدي",
            authorRole = "طالب",
            timeAgo = "منذ ساعتين",
            text = "كانت تجربة رائعة في مسابقة العلوم اليوم! شكرًا لكل من ساهم في التنظيم.",
            likes = 48, comments = 12, cover = 0,
        ),
        Post(
            id = "2",
            authorName = "مريم العلوي",
            authorRole = "طالبة",
            timeAgo = "منذ 3 ساعات",
            text = "هنا حل التمرين رقم 5 من الصفحة 12، لمن يريد المراجعة قبل الاختبار.",
            likes = 15, comments = 15, cover = 3,
        ),
        Post(
            id = "3",
            authorName = "الأستاذ كريم",
            authorRole = "أستاذ الرياضيات",
            timeAgo = "أمس",
            text = "تذكير: امتحان الرياضيات يوم الإثنين القادم، بالتوفيق للجميع.",
            likes = 63, comments = 9, cover = null,
        ),
        Post(
            id = "4",
            authorName = "سارة محمد",
            authorRole = "طالبة",
            timeAgo = "منذ 5 ساعات",
            text = "صور من رحلة النادي العلمي إلى المتحف، كانت رحلة ممتعة ومفيدة!",
            likes = 87, comments = 21, cover = 2,
        ),
        Post(
            id = "5",
            authorName = "يوسف",
            authorRole = "طالب",
            timeAgo = "أمس",
            text = "نتيجة مباراة الأقسام: فاز فريقنا 3-1، شكرًا لكل من شجّعنا.",
            likes = 54, comments = 8, cover = 1,
        ),
    )

    val comments = listOf(
        Comment("1", "سارة محمد", "مبروك يا أحمد! تستحق ذلك", "منذ ساعة", likes = 4),
        Comment("2", "يوسف", "كان عرضكم من أجمل العروض", "منذ ساعة", likes = 2),
        Comment("3", "مريم العلوي", "شكرًا على المشاركة، أين الصور الأخرى؟", "منذ 40 د", likes = 1),
        Comment("4", "أحمد السعيدي", "@مريم العلوي سأنشرها قريبًا", "منذ 30 د", parentId = "3"),
    )

    val reels = listOf(
        Reel(1, "مريم العلوي", "حل سريع لمسألة الاحتمالات في 30 ثانية #رياضيات #مراجعة", "الصوت الأصلي - مريم", 3, 342, 28),
        Reel(2, "يوسف", "أجمل أهدافنا في مباراة الأقسام ⚽ #رياضة", "حماس - مباراة الأقسام", 1, 521, 63),
        Reel(3, "سارة محمد", "تجربة كيميائية ممتعة في مختبر المدرسة #علوم", "الصوت الأصلي - سارة", 5, 278, 19),
        Reel(4, "ليلى", "لوحتي الجديدة في معرض الفنون 🎨 #فن", "ألحان هادئة", 4, 410, 35),
    )

    val notices = listOf(
        Notice(1, "سارة محمد", NoticeKind.LIKE, "أعجبها منشورك", "منذ 10 د", cover = 0),
        Notice(2, "يوسف", NoticeKind.COMMENT, "علّق: كان عرضكم من أجمل العروض", "منذ 25 د", cover = 0),
        Notice(3, "ليلى", NoticeKind.FOLLOW, "بدأت بمتابعتك", "منذ ساعة"),
        Notice(4, "مريم العلوي", NoticeKind.MENTION, "ذكرتك في تعليق: @أحمد شكرًا على الملخص", "منذ ساعتين", cover = 3),
        Notice(5, "الأستاذ كريم", NoticeKind.LIKE, "أعجبه منشورك", "أمس", cover = 0, today = false),
        Notice(6, "رنا", NoticeKind.FOLLOW, "بدأت بمتابعتك", "أمس", today = false),
        Notice(7, "سارة محمد", NoticeKind.COMMENT, "علّقت: مبروك يا أحمد!", "منذ 3 أيام", cover = 0, today = false),
    )

    val chats = listOf(
        ChatPreview(1, "أصدقاء القسم", "سارة: تمام، سنلتقي غدًا", "10:24", 3),
        ChatPreview(2, "المحادثة الخاصة", "أحمد: شكرًا لك", "09:50", 1),
        ChatPreview(3, "مجموعة الرياضيات", "مريم: هل المسألة صعبة نوعًا ما؟", "09:12", 2),
        ChatPreview(4, "مجموعة العلوم", "يوسف: هذا مفيد جدًا", "08:45", 1),
        ChatPreview(5, "المكتبة المدرسية", "تم إرسال الملف", "أمس", 0),
        ChatPreview(6, "الإدارة", "إعلان: امتحان الرياضيات يوم الإثنين", "أمس", 0),
    )

    /** رسائل ابتدائية لمحادثة معيّنة (تجريبية). */
    fun messagesFor(chatId: Int): List<ChatMessage> {
        val chat = chats.firstOrNull { it.id == chatId } ?: return emptyList()
        return listOf(
            ChatMessage(1, "مرحبًا! هل راجعت درس اليوم؟", mine = false, time = "09:40"),
            ChatMessage(2, "نعم، سأرسل لك الملخص بعد قليل", mine = true, time = "09:42"),
            ChatMessage(3, chat.lastMessage.substringAfter(": "), mine = false, time = chat.time),
        )
    }

    val groups = listOf(
        GroupPreview(1, "قسم الرياضيات", "π", 24, 1),
        GroupPreview(2, "قسم الفيزياء", "Φ", 18, 3),
        GroupPreview(3, "قسم اللغة العربية", "ع", 27, 2),
        GroupPreview(4, "قسم الإنجليزية", "A", 21, 1),
        GroupPreview(5, "النشاطات المدرسية", "★", 15, 15),
    )

    val exploreCategories = listOf("الكل", "الدراسة", "المسابقات", "الفعاليات", "الرياضة", "الفن")

    val explore = listOf(
        ExploreItem(1, "ملخص درس الفيزياء: الحركة الدائرية", "مريم العلوي", 128, "الدراسة", 1.25f),
        ExploreItem(2, "صور من مسابقة العلوم", "أحمد السعيدي", 96, "المسابقات", 0.9f),
        ExploreItem(3, "جدول مباريات كرة القدم المدرسية", "يوسف", 74, "الرياضة", 1.1f),
        ExploreItem(4, "معرض الفنون التشكيلية", "ليلى", 211, "الفن", 1.4f),
        ExploreItem(5, "نصائح للمراجعة قبل الامتحانات", "الأستاذ كريم", 305, "الدراسة", 1.0f),
        ExploreItem(6, "رحلة النادي العلمي", "سارة محمد", 88, "الفعاليات", 1.2f),
        ExploreItem(7, "تحدي الرياضيات الأسبوعي", "مريم العلوي", 142, "المسابقات", 1.3f),
        ExploreItem(8, "تدريبات فريق السلة", "يوسف", 57, "الرياضة", 0.85f),
        ExploreItem(9, "ورشة الخط العربي", "ليلى", 119, "الفن", 1.15f),
        ExploreItem(10, "حفل نهاية الفصل", "سارة محمد", 173, "الفعاليات", 1.35f),
    )
}
