package com.rifaq.school.core.common.model

import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.DocumentSnapshot.ServerTimestampBehavior
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * منشورات الرئيسية وتعليقاتها من Firestore (`posts` و`posts/{id}/comments`) مع تحديث لحظي.
 * تعليقات الريلز ما زالت محلية في الذاكرة (معرّفها يبدأ بـ [REEL_PREFIX]) إلى حين ربط الريلز.
 */
object FeedRepository {
    const val REEL_PREFIX = "reel_"
    private const val POSTS = "posts"
    private const val COMMENTS = "comments"

    private val db get() = FirebaseFirestore.getInstance()
    private val uid: String? get() = FirebaseAuth.getInstance().currentUser?.uid

    private val _posts = MutableStateFlow<List<Post>>(emptyList())
    val posts: StateFlow<List<Post>> = _posts.asStateFlow()

    /** التعليقات حسب معرّف المنشور (أو [REEL_PREFIX] + رقم الريلز). */
    private val _comments = MutableStateFlow<Map<String, List<Comment>>>(
        DemoData.reels.associate { REEL_PREFIX + it.id to DemoData.comments },
    )
    val comments: StateFlow<Map<String, List<Comment>>> = _comments.asStateFlow()

    private val hidden = mutableSetOf<String>()
    private var postsListener: ListenerRegistration? = null
    private val commentListeners = mutableMapOf<String, ListenerRegistration>()

    /** يبدأ الاستماع للمنشورات. آمن للاستدعاء أكثر من مرة. */
    fun start() {
        if (postsListener != null || uid == null) return
        postsListener = db.collection(POSTS)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(100)
            .addSnapshotListener { snap, _ ->
                val me = uid
                if (snap != null) {
                    _posts.value = snap.documents.mapNotNull { it.toPost(me) }.filter { it.id !in hidden }
                }
            }
    }

    /** يوقف كل المستمعين ويمسح البيانات (عند تسجيل الخروج). */
    fun stop() {
        postsListener?.remove()
        postsListener = null
        commentListeners.values.forEach { it.remove() }
        commentListeners.clear()
        hidden.clear()
        _posts.value = emptyList()
        _comments.update { map -> map.filterKeys { it.startsWith(REEL_PREFIX) } }
    }

    fun addPost(text: String, cover: Int?) {
        val me = uid ?: return
        val clean = text.trim()
        if (clean.isEmpty()) return
        db.collection(POSTS).add(
            mapOf(
                "authorUid" to me,
                "authorName" to ProfileRepository.profile.value.name,
                "authorRole" to "طالب",
                "text" to clean,
                "cover" to cover,
                "likedBy" to emptyList<String>(),
                "savedBy" to emptyList<String>(),
                "commentCount" to 0,
                "createdAt" to FieldValue.serverTimestamp(),
            ),
        )
    }

    fun toggleLike(postId: String) {
        val me = uid ?: return
        val liked = _posts.value.firstOrNull { it.id == postId }?.liked ?: return
        db.collection(POSTS).document(postId)
            .update("likedBy", if (liked) FieldValue.arrayRemove(me) else FieldValue.arrayUnion(me))
    }

    /** إعجاب فقط (للنقر المزدوج): لا يلغي الإعجاب إن كان موجودًا. */
    fun like(postId: String) {
        if (_posts.value.firstOrNull { it.id == postId }?.liked == false) toggleLike(postId)
    }

    fun toggleSave(postId: String) {
        val me = uid ?: return
        val saved = _posts.value.firstOrNull { it.id == postId }?.saved ?: return
        db.collection(POSTS).document(postId)
            .update("savedBy", if (saved) FieldValue.arrayRemove(me) else FieldValue.arrayUnion(me))
    }

    /** حذف منشور يملكه المستخدم (القواعد ترفض حذف منشورات الآخرين). */
    fun deletePost(postId: String) {
        db.collection(POSTS).document(postId).delete()
    }

    /** إخفاء منشور من الرئيسية على هذا الجهاز فقط (لا يحذفه). */
    fun hidePost(postId: String) {
        hidden += postId
        _posts.update { list -> list.filterNot { it.id == postId } }
    }

    /** يبدأ الاستماع لتعليقات منشور. لا يفعل شيئًا للريلز. */
    fun observeComments(postId: String) {
        if (postId.startsWith(REEL_PREFIX) || postId in commentListeners || uid == null) return
        commentListeners[postId] = db.collection(POSTS).document(postId).collection(COMMENTS)
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .addSnapshotListener { snap, _ ->
                val me = uid
                if (snap != null) {
                    val list = snap.documents.mapNotNull { it.toComment(me) }
                    _comments.update { it + (postId to list) }
                }
            }
    }

    fun stopObservingComments(postId: String) {
        commentListeners.remove(postId)?.remove()
    }

    fun addComment(postId: String, text: String, parentId: String? = null) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val name = ProfileRepository.profile.value.name
        if (postId.startsWith(REEL_PREFIX)) {
            _comments.update { map ->
                val current = map[postId].orEmpty()
                val nextId = ((current.mapNotNull { it.id.toIntOrNull() }.maxOrNull() ?: 0) + 1).toString()
                map + (postId to current + Comment(nextId, name, clean, parentId = parentId))
            }
            return
        }
        val me = uid ?: return
        val post = db.collection(POSTS).document(postId)
        post.collection(COMMENTS).add(
            mapOf(
                "authorUid" to me,
                "author" to name,
                "text" to clean,
                "parentId" to parentId,
                "likedBy" to emptyList<String>(),
                "createdAt" to FieldValue.serverTimestamp(),
            ),
        )
        post.update("commentCount", FieldValue.increment(1))
    }

    fun toggleCommentLike(postId: String, commentId: String) {
        if (postId.startsWith(REEL_PREFIX)) {
            _comments.update { map ->
                val current = map[postId] ?: return@update map
                map + (
                    postId to current.map {
                        if (it.id == commentId) {
                            it.copy(liked = !it.liked, likes = (it.likes + if (it.liked) -1 else 1).coerceAtLeast(0))
                        } else {
                            it
                        }
                    }
                    )
            }
            return
        }
        val me = uid ?: return
        val liked = _comments.value[postId]?.firstOrNull { it.id == commentId }?.liked ?: return
        db.collection(POSTS).document(postId).collection(COMMENTS).document(commentId)
            .update("likedBy", if (liked) FieldValue.arrayRemove(me) else FieldValue.arrayUnion(me))
    }

    private fun DocumentSnapshot.toPost(me: String?): Post? {
        val text = getString("text") ?: return null
        val likedBy = stringList("likedBy")
        val authorUid = getString("authorUid").orEmpty()
        return Post(
            id = id,
            authorName = getString("authorName").orEmpty(),
            authorRole = getString("authorRole").orEmpty(),
            timeAgo = timeAgo(getTimestamp("createdAt", ServerTimestampBehavior.ESTIMATE)),
            text = text,
            likes = likedBy.size,
            comments = (getLong("commentCount") ?: 0L).toInt().coerceAtLeast(0),
            cover = getLong("cover")?.toInt(),
            liked = me != null && me in likedBy,
            saved = me != null && me in stringList("savedBy"),
            authorUid = authorUid,
            mine = me != null && me == authorUid,
        )
    }

    private fun DocumentSnapshot.toComment(me: String?): Comment? {
        val text = getString("text") ?: return null
        val likedBy = stringList("likedBy")
        return Comment(
            id = id,
            author = getString("author").orEmpty(),
            text = text,
            timeAgo = timeAgo(getTimestamp("createdAt", ServerTimestampBehavior.ESTIMATE)),
            likes = likedBy.size,
            liked = me != null && me in likedBy,
            parentId = getString("parentId"),
            authorUid = getString("authorUid").orEmpty(),
        )
    }

    private fun DocumentSnapshot.stringList(field: String): List<String> =
        (get(field) as? List<*>)?.filterIsInstance<String>().orEmpty()

    internal fun timeAgo(ts: Timestamp?, nowMillis: Long = System.currentTimeMillis()): String {
        if (ts == null) return "الآن"
        val minutes = ((nowMillis - ts.toDate().time) / 60_000).coerceAtLeast(0)
        return when {
            minutes < 1 -> "الآن"
            minutes < 60 -> "منذ $minutes د"
            minutes < 24 * 60 -> "منذ ${minutes / 60} ساعة"
            minutes < 48 * 60 -> "أمس"
            else -> "منذ ${minutes / (24 * 60)} أيام"
        }
    }
}
