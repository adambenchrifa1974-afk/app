package com.rifaq.school.core.common.model

/** قسم دراسي (آداب، رياضيات...). */
data class SchoolSection(val id: String, val name: String, val symbol: String)

/** مستوى دراسي (السنة الأولى...). */
data class SchoolLevel(val id: String, val name: String)

/**
 * مجموعة مدرسية. إذا كان [sectionId] فقط فهي مجموعة القسم كله،
 * وإذا كان [levelId] فقط فهي مجموعة المستوى كله، وإذا وُجدا معًا فهي مجموعة القسم في ذلك المستوى.
 */
data class SchoolGroup(
    val id: Int,
    val name: String,
    val symbol: String,
    val sectionId: String?,
    val levelId: String?,
    val members: Int,
    val posts: Int,
)

enum class LessonType(val label: String) { SUMMARY("ملخص"), VIDEO("فيديو"), EXERCISES("تمارين"), EXAM("فرض") }

/** درس منشور في مادة، ينتمي لوحدة ([unit]) ولمستوى ([levelId]). */
data class Lesson(
    val id: Int,
    val subjectId: String,
    val levelId: String,
    val unit: String,
    val title: String,
    val type: LessonType,
    val date: String,
    val teacher: String,
)

data class Subject(val id: String, val name: String, val symbol: String, val teacher: String)
