package com.rifaq.school.core.common.model

/**
 * أقسام ومستويات ومجموعات ومواد ودروس تجريبية. الأسماء قابلة للتعديل بحرية
 * لتطابق مدرستك؛ كل شيء يُشتق من هذه القوائم.
 */
object SchoolData {
    val sections = listOf(
        SchoolSection("lit", "آداب", "ع"),
        SchoolSection("math", "رياضيات", "π"),
        SchoolSection("sci", "علوم تجريبية", "⚗"),
        SchoolSection("eco", "اقتصاد وتصرف", "%"),
    )

    val levels = listOf(
        SchoolLevel("y1", "السنة الأولى"),
        SchoolLevel("y2", "السنة الثانية"),
        SchoolLevel("y3", "السنة الثالثة"),
        SchoolLevel("y4", "السنة الرابعة"),
    )

    /** السنة الأولى جذع مشترك، فلا أقسام فيها. */
    private val sectionLevels = levels.filter { it.id != "y1" }

    val groups: List<SchoolGroup> = buildList {
        var id = 1
        levels.forEach { l -> add(SchoolGroup(id++, "مستوى ${l.name}", "★", null, l.id, 80 + id * 7, 5 + id)) }
        sections.forEach { s -> add(SchoolGroup(id++, "قسم ${s.name}", s.symbol, s.id, null, 60 + id * 5, 4 + id)) }
        sectionLevels.forEach { l ->
            sections.forEach { s ->
                add(SchoolGroup(id++, "${s.name} - ${l.name}", s.symbol, s.id, l.id, 18 + id % 15, 1 + id % 9))
            }
        }
    }

    val subjects = listOf(
        Subject("ar", "اللغة العربية", "ع", "الأستاذة سلمى"),
        Subject("fr", "اللغة الفرنسية", "Fr", "الأستاذ كمال"),
        Subject("en", "اللغة الإنجليزية", "A", "الأستاذة هالة"),
        Subject("math", "الرياضيات", "π", "الأستاذ كريم"),
        Subject("phy", "الفيزياء", "Φ", "الأستاذ رياض"),
        Subject("svt", "علوم الحياة والأرض", "🧬", "الأستاذة منى"),
        Subject("hg", "التاريخ والجغرافيا", "🌍", "الأستاذ وليد"),
        Subject("phi", "الفلسفة", "💭", "الأستاذة نادية"),
        Subject("inf", "الإعلامية", "</>", "الأستاذ فارس"),
    )

    private fun l(id: Int, s: String, lv: String, unit: String, title: String, t: LessonType, date: String): Lesson {
        val teacher = subjects.first { it.id == s }.teacher
        return Lesson(id, s, lv, unit, title, t, date, teacher)
    }

    private val S = LessonType.SUMMARY
    private val V = LessonType.VIDEO
    private val E = LessonType.EXERCISES
    private val X = LessonType.EXAM

    val lessons: List<Lesson> = listOf(
        l(1, "math", "y2", "الوحدة 1: الدوال", "ملخص: الدوال العددية", S, "12 أكتوبر"),
        l(2, "math", "y2", "الوحدة 1: الدوال", "تمارين: النهايات", E, "13 أكتوبر"),
        l(3, "math", "y2", "الوحدة 2: المتتاليات", "فيديو: المتتالية الحسابية", V, "15 أكتوبر"),
        l(4, "math", "y2", "الوحدة 2: المتتاليات", "فرض مراقبة عدد 1", X, "16 أكتوبر"),
        l(5, "math", "y4", "الوحدة 1: التكامل", "ملخص: التكامل والمساحات", S, "10 أكتوبر"),
        l(6, "math", "y4", "الوحدة 1: التكامل", "تمارين: حساب التكاملات", E, "14 أكتوبر"),
        l(7, "math", "y1", "الوحدة 1: الأعداد", "ملخص: المجموعات العددية", S, "9 أكتوبر"),
        l(8, "phy", "y2", "الوحدة 1: الحركة", "فيديو: الحركة المستقيمة", V, "11 أكتوبر"),
        l(9, "phy", "y2", "الوحدة 1: الحركة", "تمارين: السرعة والتسارع", E, "14 أكتوبر"),
        l(10, "phy", "y3", "الوحدة 1: الكهرباء", "ملخص: الدارة RLC", S, "12 أكتوبر"),
        l(11, "phy", "y4", "الوحدة 1: الميكانيك", "ملخص: قوانين نيوتن", S, "8 أكتوبر"),
        l(12, "phy", "y4", "الوحدة 1: الميكانيك", "فرض تأليفي عدد 1", X, "15 أكتوبر"),
        l(13, "ar", "y1", "الوحدة 1: النص الأدبي", "ملخص: خصائص الشعر الجاهلي", S, "9 أكتوبر"),
        l(14, "ar", "y2", "الوحدة 1: النحو", "تمارين: الإعراب", E, "13 أكتوبر"),
        l(15, "ar", "y3", "الوحدة 1: البلاغة", "فيديو: التشبيه والاستعارة", V, "14 أكتوبر"),
        l(16, "ar", "y4", "الوحدة 1: الأدب الحديث", "ملخص: الشعر المعاصر", S, "11 أكتوبر"),
        l(17, "fr", "y1", "Unité 1", "Résumé : Le présent de l'indicatif", S, "10 أكتوبر"),
        l(18, "fr", "y2", "Unité 1", "Exercices : La phrase complexe", E, "12 أكتوبر"),
        l(19, "fr", "y4", "Unité 1", "Vidéo : Dissertation", V, "13 أكتوبر"),
        l(20, "en", "y2", "Unit 1", "Summary: Present perfect", S, "11 أكتوبر"),
        l(21, "en", "y3", "Unit 1", "Exercises: Conditionals", E, "14 أكتوبر"),
        l(22, "en", "y4", "Unit 1", "Video: Essay writing", V, "15 أكتوبر"),
        l(23, "svt", "y2", "الوحدة 1: الخلية", "ملخص: بنية الخلية", S, "10 أكتوبر"),
        l(24, "svt", "y3", "الوحدة 1: الوراثة", "فيديو: قوانين مندل", V, "13 أكتوبر"),
        l(25, "svt", "y4", "الوحدة 1: المناعة", "تمارين: الاستجابة المناعية", E, "15 أكتوبر"),
        l(26, "hg", "y2", "الوحدة 1: التاريخ", "ملخص: الثورة الصناعية", S, "9 أكتوبر"),
        l(27, "hg", "y4", "الوحدة 1: الجغرافيا", "ملخص: العولمة", S, "12 أكتوبر"),
        l(28, "phi", "y4", "الوحدة 1: الإنسان", "ملخص: الحرية والمسؤولية", S, "11 أكتوبر"),
        l(29, "phi", "y4", "الوحدة 1: الإنسان", "تمارين: تحليل نص فلسفي", E, "14 أكتوبر"),
        l(30, "inf", "y3", "الوحدة 1: الخوارزميات", "تمارين: الحلقات والشروط", E, "13 أكتوبر"),
        l(31, "inf", "y4", "الوحدة 1: قواعد البيانات", "فيديو: نموذج SQL", V, "15 أكتوبر"),
    )

    /**
     * إذا اختير القسم والمستوى معًا نعرض مجموعاتهما العامة ومجموعتهما المشتركة،
     * وإذا اختير واحد فقط نعرض كل المجموعات المرتبطة به.
     */
    fun groupsFor(sectionId: String?, levelId: String?): List<SchoolGroup> = groups.filter { g ->
        if (sectionId != null && levelId != null) {
            (g.sectionId == null || g.sectionId == sectionId) && (g.levelId == null || g.levelId == levelId)
        } else {
            (sectionId == null || g.sectionId == sectionId) && (levelId == null || g.levelId == levelId)
        }
    }

    fun lessonsFor(subjectId: String, levelId: String): List<Lesson> =
        lessons.filter { it.subjectId == subjectId && it.levelId == levelId }
}
