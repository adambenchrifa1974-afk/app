package com.rifaq.school.core.common.model

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** حالة اجتماعية في الذاكرة: المتابعة، القصص المشاهدة، إعجابات الريلز. */
object SocialRepository {
    private val initiallyFollowed = setOf("الأستاذ كريم", "سارة محمد")

    private val _followed = MutableStateFlow(initiallyFollowed)
    val followed: StateFlow<Set<String>> = _followed.asStateFlow()

    private val _viewedStories = MutableStateFlow<Set<Int>>(emptySet())
    val viewedStories: StateFlow<Set<Int>> = _viewedStories.asStateFlow()

    private val _likedReels = MutableStateFlow<Set<Int>>(emptySet())
    val likedReels: StateFlow<Set<Int>> = _likedReels.asStateFlow()

    private val _savedReels = MutableStateFlow<Set<Int>>(emptySet())
    val savedReels: StateFlow<Set<Int>> = _savedReels.asStateFlow()

    /** الفرق في عدد «أتابع» عن القيمة الأصلية للحساب. */
    fun followingDelta(current: Set<String> = _followed.value): Int = current.size - initiallyFollowed.size

    fun toggleFollow(name: String) {
        _followed.update { if (name in it) it - name else it + name }
    }

    fun unfollow(name: String) {
        _followed.update { it - name }
    }

    fun markStoryViewed(id: Int) {
        _viewedStories.update { it + id }
    }

    fun toggleReelLike(id: Int) {
        _likedReels.update { if (id in it) it - id else it + id }
    }

    /** إعجاب فقط (للنقر المزدوج): لا يلغي الإعجاب السابق. */
    fun likeReel(id: Int) {
        _likedReels.update { it + id }
    }

    fun toggleReelSave(id: Int) {
        _savedReels.update { if (id in it) it - id else it + id }
    }
}
