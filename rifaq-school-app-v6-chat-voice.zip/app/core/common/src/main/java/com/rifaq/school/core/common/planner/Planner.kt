package com.rifaq.school.core.common.planner

import com.rifaq.school.core.common.storage.LocalStore
import java.util.Calendar
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject

enum class TaskType(val label: String) {
    HOMEWORK("واجب"),
    EXAM("امتحان"),
    REVISION("مراجعة"),
}

data class StudyTask(
    val id: Long,
    val title: String,
    val subject: String,
    val type: TaskType,
    val dueAt: Long,
    val done: Boolean = false,
)

data class TaskSections(
    val overdue: List<StudyTask>,
    val upcoming: List<StudyTask>,
    val done: List<StudyTask>,
)

/** يقسّم المهام إلى متأخرة وقادمة ومنجزة. */
fun groupTasks(tasks: List<StudyTask>, now: Long): TaskSections {
    val open = tasks.filter { !it.done }
    return TaskSections(
        overdue = open.filter { it.dueAt < now }.sortedBy { it.dueAt },
        upcoming = open.filter { it.dueAt >= now }.sortedBy { it.dueAt },
        done = tasks.filter { it.done }.sortedByDescending { it.dueAt },
    )
}

/** نهاية اليوم (23:59) بعد [daysAhead] أيام من [now]. */
fun dueAtFor(daysAhead: Int, now: Long): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = now
    c.set(Calendar.HOUR_OF_DAY, 23)
    c.set(Calendar.MINUTE, 59)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    c.add(Calendar.DAY_OF_YEAR, daysAhead)
    return c.timeInMillis
}

/** مهام المخطط، محفوظة على الجهاز. */
object PlannerRepository {
    private const val KEY = "planner_tasks"

    private val _tasks = MutableStateFlow<List<StudyTask>>(emptyList())
    val tasks: StateFlow<List<StudyTask>> = _tasks.asStateFlow()
    private var loaded = false

    fun load() {
        if (loaded) return
        loaded = true
        _tasks.value = parse(LocalStore.getString(KEY, "[]"))
    }

    fun add(title: String, subject: String, type: TaskType, dueAt: Long) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        update { it + StudyTask(System.currentTimeMillis(), clean, subject.trim(), type, dueAt) }
    }

    fun toggle(id: Long) = update { list ->
        list.map { if (it.id == id) it.copy(done = !it.done) else it }
    }

    fun delete(id: Long) = update { list -> list.filterNot { it.id == id } }

    private fun update(transform: (List<StudyTask>) -> List<StudyTask>) {
        _tasks.update(transform)
        LocalStore.putString(KEY, serialize(_tasks.value))
    }

    private fun serialize(list: List<StudyTask>): String {
        val array = JSONArray()
        list.forEach { task ->
            array.put(
                JSONObject()
                    .put("id", task.id)
                    .put("title", task.title)
                    .put("subject", task.subject)
                    .put("type", task.type.name)
                    .put("dueAt", task.dueAt)
                    .put("done", task.done),
            )
        }
        return array.toString()
    }

    private fun parse(raw: String): List<StudyTask> = runCatching {
        val array = JSONArray(raw)
        List(array.length()) { i ->
            val o = array.getJSONObject(i)
            StudyTask(
                id = o.getLong("id"),
                title = o.getString("title"),
                subject = o.optString("subject", ""),
                type = TaskType.valueOf(o.optString("type", TaskType.HOMEWORK.name)),
                dueAt = o.getLong("dueAt"),
                done = o.optBoolean("done", false),
            )
        }
    }.getOrDefault(emptyList())
}
