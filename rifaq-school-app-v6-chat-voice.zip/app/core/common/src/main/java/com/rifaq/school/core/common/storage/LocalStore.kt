package com.rifaq.school.core.common.storage

import android.content.Context
import android.content.SharedPreferences

/** تخزين بسيط على الجهاز نفسه. يجب استدعاء [init] مرة واحدة عند تشغيل التطبيق. */
object LocalStore {
    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.applicationContext.getSharedPreferences("rifaq_local", Context.MODE_PRIVATE)
        }
    }

    private fun requirePrefs(): SharedPreferences =
        checkNotNull(prefs) { "LocalStore.init(context) must be called before use." }

    fun getString(key: String, default: String): String =
        requirePrefs().getString(key, default) ?: default

    fun putString(key: String, value: String) {
        requirePrefs().edit().putString(key, value).apply()
    }

    fun getInt(key: String, default: Int): Int = requirePrefs().getInt(key, default)

    fun putInt(key: String, value: Int) {
        requirePrefs().edit().putInt(key, value).apply()
    }
}
