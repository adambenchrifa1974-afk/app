package com.rifaq.school.core.common

import com.rifaq.school.core.common.chat.ChatTime
import java.util.Calendar
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ChatTimeTest {
    private val now = Calendar.getInstance().apply {
        set(2026, Calendar.OCTOBER, 18, 12, 0, 0)
    }.timeInMillis

    @Test fun sameDay_isClock() {
        val t = ChatTime.listTime(now - 60 * 60_000, now)
        assertTrue(t, Regex("\\d{2}:\\d{2}").matches(t))
    }

    @Test fun yesterday() = assertEquals("أمس", ChatTime.listTime(now - 24 * 60 * 60_000, now))

    @Test fun older_isDayMonth() {
        val t = ChatTime.listTime(now - 5L * 24 * 60 * 60_000, now)
        assertTrue(t, t.contains("/"))
    }

    @Test fun zero_isEmpty() = assertEquals("", ChatTime.listTime(0L, now))
}
