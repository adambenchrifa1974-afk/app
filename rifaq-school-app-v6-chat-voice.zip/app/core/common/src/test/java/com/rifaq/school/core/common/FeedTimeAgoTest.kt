package com.rifaq.school.core.common

import com.google.firebase.Timestamp
import com.rifaq.school.core.common.model.FeedRepository
import java.util.Date
import org.junit.Assert.assertEquals
import org.junit.Test

class FeedTimeAgoTest {
    private val now = 1_000_000_000_000L
    private fun ago(minutes: Long) = Timestamp(Date(now - minutes * 60_000))

    @Test fun nullTimestamp_isNow() = assertEquals("الآن", FeedRepository.timeAgo(null, now))
    @Test fun underOneMinute_isNow() = assertEquals("الآن", FeedRepository.timeAgo(ago(0), now))
    @Test fun minutes() = assertEquals("منذ 5 د", FeedRepository.timeAgo(ago(5), now))
    @Test fun hours() = assertEquals("منذ 3 ساعة", FeedRepository.timeAgo(ago(180), now))
    @Test fun yesterday() = assertEquals("أمس", FeedRepository.timeAgo(ago(30 * 60), now))
    @Test fun days() = assertEquals("منذ 4 أيام", FeedRepository.timeAgo(ago(4 * 24 * 60), now))
}
