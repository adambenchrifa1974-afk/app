package com.rifaq.school.core.common

import com.rifaq.school.core.common.gamification.Badges
import com.rifaq.school.core.common.gamification.GamificationStats
import com.rifaq.school.core.common.gamification.QuizBank
import com.rifaq.school.core.common.gamification.QuizLogic
import com.rifaq.school.core.common.gamification.QuizState
import com.rifaq.school.core.common.gamification.computeAward
import com.rifaq.school.core.common.gamification.levelFor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GamificationTest {
    @Test
    fun award_perfectDailyIsDoubleWithBonus() {
        assertEquals(10, computeAward(1, 5, false))
        assertEquals(70, computeAward(5, 5, false))
        assertEquals(140, computeAward(5, 5, true))
        assertEquals(0, computeAward(0, 0, false))
    }

    @Test
    fun level_growsEveryHundredXp() {
        assertEquals(1, levelFor(0))
        assertEquals(1, levelFor(99))
        assertEquals(2, levelFor(100))
    }

    @Test
    fun badges_areEarnedFromStats() {
        val earned = Badges.earnedIds(GamificationStats(xp = 120, quizzesCompleted = 1, perfectScores = 1), tasksDone = 5)
        assertTrue("first_quiz" in earned)
        assertTrue("perfect" in earned)
        assertTrue("xp_100" in earned)
        assertTrue("tasks_5" in earned)
        assertFalse("quiz_5" in earned)
    }

    @Test
    fun everyQuestion_hasValidCorrectIndex() {
        QuizBank.quizzes.forEach { quiz ->
            quiz.questions.forEach { q ->
                assertTrue(q.correctIndex in q.options.indices)
                assertEquals(4, q.options.size)
            }
        }
    }

    @Test
    fun quizLogic_countsCorrectAndFinishes() {
        val quiz = QuizBank.quizzes.first()
        var state = QuizState(quiz)
        quiz.questions.forEach { q ->
            state = QuizLogic.select(state, q.correctIndex)
            // اختيار ثانٍ لا يغيّر شيئًا
            state = QuizLogic.select(state, (q.correctIndex + 1) % 4)
            state = QuizLogic.advance(state)
        }
        assertTrue(state.finished)
        assertEquals(quiz.questions.size, state.correct)
    }
}
