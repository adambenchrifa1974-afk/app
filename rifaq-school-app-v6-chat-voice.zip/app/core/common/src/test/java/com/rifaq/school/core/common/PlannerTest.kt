package com.rifaq.school.core.common

import com.rifaq.school.core.common.planner.StudyTask
import com.rifaq.school.core.common.planner.TaskType
import com.rifaq.school.core.common.planner.dueAtFor
import com.rifaq.school.core.common.planner.groupTasks
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PlannerTest {
    private fun task(id: Long, due: Long, done: Boolean = false) =
        StudyTask(id, "t$id", "math", TaskType.HOMEWORK, due, done)

    @Test
    fun groupTasks_splitsOverdueUpcomingDone() {
        val now = 1_000L
        val sections = groupTasks(
            listOf(task(1, 500), task(2, 2_000), task(3, 100, done = true)),
            now,
        )
        assertEquals(listOf(1L), sections.overdue.map { it.id })
        assertEquals(listOf(2L), sections.upcoming.map { it.id })
        assertEquals(listOf(3L), sections.done.map { it.id })
    }

    @Test
    fun dueAtFor_isInTheFutureForPositiveDays() {
        val now = System.currentTimeMillis()
        assertTrue(dueAtFor(1, now) > now)
        assertTrue(dueAtFor(7, now) > dueAtFor(3, now))
    }
}
