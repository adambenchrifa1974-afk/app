package com.rifaq.school.core.common

import com.rifaq.school.core.common.model.SchoolData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SchoolDataTest {
    @Test
    fun groupIdsAreUnique() {
        assertEquals(SchoolData.groups.size, SchoolData.groups.map { it.id }.toSet().size)
    }

    @Test
    fun sectionAndLevelFilterIncludesGeneralAndSharedGroups() {
        val result = SchoolData.groupsFor("sci", "y4")
        assertTrue(result.any { it.sectionId == null && it.levelId == "y4" })
        assertTrue(result.any { it.sectionId == "sci" && it.levelId == null })
        assertTrue(result.any { it.sectionId == "sci" && it.levelId == "y4" })
        assertTrue(result.none { it.sectionId == "lit" })
    }

    @Test
    fun noFilterReturnsAllGroups() {
        assertEquals(SchoolData.groups, SchoolData.groupsFor(null, null))
    }

    @Test
    fun everyLessonReferencesRealSubjectAndLevel() {
        SchoolData.lessons.forEach { lesson ->
            assertTrue(SchoolData.subjects.any { it.id == lesson.subjectId })
            assertTrue(SchoolData.levels.any { it.id == lesson.levelId })
        }
        assertEquals(SchoolData.lessons.size, SchoolData.lessons.map { it.id }.toSet().size)
    }
}
