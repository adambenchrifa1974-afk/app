package com.rifaq.school.core.designsystem.component

import android.os.Build
import androidx.compose.foundation.border
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** التمويه الحقيقي للخلفية يحتاج Android 12 فما فوق؛ في الإصدارات الأقدم يُستعمل لون شبه معتم. */
val BlurSupported: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

/** يحمل نسخة مسجّلة من المحتوى لرسمها مموّهة تحت الأسطح الزجاجية. */
@Stable
class BackdropState internal constructor(internal val layer: GraphicsLayer) {
    internal var origin by mutableStateOf(Offset.Zero)
}

@Composable
fun rememberBackdropState(): BackdropState {
    val layer = rememberGraphicsLayer()
    return remember(layer) { BackdropState(layer) }
}

/** يعلّم هذا المحتوى كمصدر للتمويه خلف الأسطح التي تستعمل [glass]. */
fun Modifier.backdropSource(state: BackdropState): Modifier = this
    .onGloballyPositioned { state.origin = it.positionInRoot() }
    .drawWithContent {
        state.layer.record { this@drawWithContent.drawContent() }
        drawLayer(state.layer)
    }

/**
 * سطح زجاجي على طريقة Apple: يعرض المحتوى الذي خلفه مموّهًا مع طبقة لونية شفافة وحدّ رفيع.
 * يجب أن يكون المحتوى الخلفي معلَّمًا بـ [backdropSource] من نفس [state].
 */
@Composable
fun Modifier.glass(
    state: BackdropState,
    shape: Shape,
    tint: Color,
    borderColor: Color,
    blurRadius: Dp = 28.dp,
): Modifier {
    val blurLayer = rememberGraphicsLayer()
    val radiusPx = with(LocalDensity.current) { blurRadius.toPx() }
    SideEffect { blurLayer.renderEffect = BlurEffect(radiusPx, radiusPx, TileMode.Clamp) }
    var origin by remember { mutableStateOf(Offset.Zero) }
    return this
        .onGloballyPositioned { origin = it.positionInRoot() }
        .clip(shape)
        .drawBehind {
            if (BlurSupported) {
                blurLayer.record {
                    translate(state.origin.x - origin.x, state.origin.y - origin.y) {
                        drawLayer(state.layer)
                    }
                }
                drawLayer(blurLayer)
            }
            drawRect(tint)
        }
        .border(1.dp, borderColor, shape)
}
