package com.rifaq.school.core.designsystem.component

import android.content.Intent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.rifaq.school.core.designsystem.theme.InstaBlue
import com.rifaq.school.core.designsystem.theme.StoryRingGradient
import kotlinx.coroutines.delay

private val LikeRed = Color(0xFFFF3B5C)

/**
 * منشور بأسلوب إنستغرام. النقر مرتين على الصورة يضيف إعجابًا مع قلب نابض،
 * زر المتابعة بجانب الاسم، الوسوم والإشارات (#، @) بالأزرق، وتعليق قابل للتوسيع.
 * وزر المشاركة يفتح قائمة المشاركة الحقيقية في النظام.
 * الحالة (إعجاب/حفظ/متابعة) تأتي من الخارج لتبقى متزامنة بين الشاشات.
 * [cover] غير فارغ يعني أن للمنشور صورة (تُعرض حاليًا كغلاف ملوّن).
 */
@Composable
fun PostCard(
    authorName: String,
    authorRole: String,
    timeAgo: String,
    text: String,
    likes: Int,
    comments: Int,
    cover: Int?,
    modifier: Modifier = Modifier,
    liked: Boolean = false,
    saved: Boolean = false,
    following: Boolean = true,
    isMine: Boolean = false,
    onLike: () -> Unit = {},
    onDoubleTapLike: () -> Unit = onLike,
    onSave: () -> Unit = {},
    onFollow: () -> Unit = {},
    onMore: () -> Unit = {},
    onCommentsClick: () -> Unit = {},
) {
    var expanded by rememberSaveable { mutableStateOf(false) }
    var overflowing by remember { mutableStateOf(false) }
    var burstKey by remember { mutableIntStateOf(0) }
    val pulse = remember { Animatable(1f) }
    val burst = remember { Animatable(0f) }
    val scheme = MaterialTheme.colorScheme
    val context = LocalContext.current

    // نبضة القلب عند الإعجاب: ترتد كالماء بنابض ناعم.
    val firstRun = remember { booleanArrayOf(true) }
    LaunchedEffect(liked) {
        if (firstRun[0]) {
            firstRun[0] = false
            return@LaunchedEffect
        }
        if (liked) {
            pulse.snapTo(0.6f)
            pulse.animateTo(
                1f,
                spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
            )
        }
    }
    // قلب كبير يظهر فوق الصورة عند النقر المزدوج.
    LaunchedEffect(burstKey) {
        if (burstKey > 0) {
            burst.snapTo(0f)
            burst.animateTo(
                1f,
                spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessMedium),
            )
            delay(300)
            burst.animateTo(0f, tween(180))
        }
    }

    Column(modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(42.dp).border(2.dp, Brush.linearGradient(StoryRingGradient), CircleShape),
                contentAlignment = Alignment.Center,
            ) { RifaqAvatar(authorName, size = 34.dp) }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(authorName, style = MaterialTheme.typography.titleMedium)
                    if (!isMine && !following) {
                        Text(
                            "• متابعة",
                            modifier = Modifier
                                .padding(horizontal = 6.dp)
                                .clickable(onClick = onFollow),
                            style = MaterialTheme.typography.titleMedium,
                            color = InstaBlue,
                        )
                    }
                }
                Text(
                    authorRole,
                    style = MaterialTheme.typography.bodyMedium,
                    color = scheme.onSurfaceVariant,
                )
            }
            IconButton(onClick = onMore) {
                Icon(Icons.Filled.MoreHoriz, contentDescription = "خيارات", tint = scheme.onSurface)
            }
        }

        if (cover != null) {
            RifaqCover(
                seed = cover,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.25f)
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onDoubleTap = {
                                onDoubleTapLike()
                                burstKey += 1
                            },
                        )
                    },
            ) {
                Icon(
                    Icons.Filled.Favorite,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(110.dp).scale(burst.value),
                )
            }
        }

        Row(Modifier.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onLike) {
                Icon(
                    if (liked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = "إعجاب",
                    tint = if (liked) LikeRed else scheme.onSurface,
                    modifier = Modifier.scale(pulse.value),
                )
            }
            IconButton(onClick = onCommentsClick) {
                Icon(Icons.Outlined.ChatBubbleOutline, contentDescription = "تعليق")
            }
            IconButton(
                onClick = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "$authorName: $text")
                    }
                    context.startActivity(Intent.createChooser(send, null))
                },
            ) {
                Icon(Icons.AutoMirrored.Outlined.Send, contentDescription = "مشاركة")
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onSave) {
                Icon(
                    if (saved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                    contentDescription = "حفظ",
                    tint = scheme.onSurface,
                )
            }
        }

        Text(
            "$likes إعجاب",
            modifier = Modifier.padding(horizontal = 14.dp),
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Bold,
        )
        Text(
            captionText(authorName, text),
            modifier = Modifier
                .padding(horizontal = 14.dp, vertical = 4.dp)
                .clickable { expanded = !expanded },
            style = MaterialTheme.typography.bodyLarge,
            maxLines = if (expanded) Int.MAX_VALUE else 3,
            overflow = TextOverflow.Ellipsis,
            onTextLayout = { if (!expanded) overflowing = it.hasVisualOverflow },
        )
        if (overflowing && !expanded) {
            Text(
                "المزيد",
                modifier = Modifier
                    .padding(horizontal = 14.dp)
                    .clickable { expanded = true },
                style = MaterialTheme.typography.bodyMedium,
                color = scheme.onSurfaceVariant,
            )
        }
        Text(
            if (comments == 0) "أضف تعليقًا..." else "عرض جميع التعليقات ($comments)",
            modifier = Modifier.padding(horizontal = 14.dp).clickable(onClick = onCommentsClick),
            style = MaterialTheme.typography.bodyMedium,
            color = scheme.onSurfaceVariant,
        )
        Text(
            timeAgo,
            modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 2.dp, bottom = 18.dp),
            style = MaterialTheme.typography.bodyMedium,
            color = scheme.onSurfaceVariant,
        )
    }
}

private val TagRegex = Regex("[#@][\\p{L}\\p{N}_]+")

/** اسم الكاتب بخط ثقيل ثم النص مع تلوين الوسوم (#) والإشارات (@) بالأزرق. */
private fun captionText(author: String, text: String): AnnotatedString = buildAnnotatedString {
    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(author) }
    append("  ")
    var last = 0
    for (match in TagRegex.findAll(text)) {
        append(text.substring(last, match.range.first))
        withStyle(SpanStyle(color = InstaBlue)) { append(match.value) }
        last = match.range.last + 1
    }
    append(text.substring(last))
}
