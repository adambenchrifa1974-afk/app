package com.rifaq.school.core.designsystem.component

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

private val CoverPalettes = listOf(
    listOf(Color(0xFF0F766E), Color(0xFF5EEAD4)),
    listOf(Color(0xFF1D4ED8), Color(0xFF93C5FD)),
    listOf(Color(0xFF166534), Color(0xFFBBF7D0)),
    listOf(Color(0xFFB45309), Color(0xFFFDE68A)),
    listOf(Color(0xFF9D174D), Color(0xFFFBCFE8)),
    listOf(Color(0xFF6D28D9), Color(0xFFDDD6FE)),
)

/** غلاف ملوّن متدرج، يُستخدم مكان الصور الحقيقية إلى حين ربطها. */
@Composable
fun RifaqCover(
    seed: Int,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit = {},
) {
    val colors = CoverPalettes[Math.floorMod(seed, CoverPalettes.size)]
    Box(
        modifier.clipToBounds().background(Brush.linearGradient(colors)),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.matchParentSize()) {
            drawCircle(
                Color.White.copy(alpha = 0.14f),
                radius = size.minDimension * 0.55f,
                center = Offset(size.width * 0.9f, size.height * 0.1f),
            )
            drawCircle(
                Color.White.copy(alpha = 0.10f),
                radius = size.minDimension * 0.4f,
                center = Offset(size.width * 0.1f, size.height * 0.95f),
            )
        }
        content()
    }
}
