package com.rifaq.school.core.designsystem.component

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** شعار التطبيق: ثلاثة أشخاص فوق كتاب مفتوح، يُرسم بألوان الثيم. */
@Composable
fun RifaqLogo(modifier: Modifier = Modifier, size: Dp = 96.dp) {
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    Canvas(modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        fun person(cx: Float, headY: Float, headR: Float) {
            drawCircle(secondary, radius = headR, center = Offset(cx, headY))
            drawArc(
                color = secondary,
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = true,
                topLeft = Offset(cx - headR * 1.5f, headY + headR * 1.2f),
                size = Size(headR * 3f, headR * 3f),
            )
        }
        person(w * 0.5f, h * 0.14f, w * 0.085f)
        person(w * 0.27f, h * 0.27f, w * 0.07f)
        person(w * 0.73f, h * 0.27f, w * 0.07f)

        val left = Path().apply {
            moveTo(w * 0.5f, h * 0.96f)
            lineTo(w * 0.5f, h * 0.66f)
            quadraticBezierTo(w * 0.3f, h * 0.54f, w * 0.06f, h * 0.62f)
            lineTo(w * 0.06f, h * 0.86f)
            quadraticBezierTo(w * 0.3f, h * 0.78f, w * 0.5f, h * 0.96f)
            close()
        }
        val right = Path().apply {
            moveTo(w * 0.5f, h * 0.96f)
            lineTo(w * 0.5f, h * 0.66f)
            quadraticBezierTo(w * 0.7f, h * 0.54f, w * 0.94f, h * 0.62f)
            lineTo(w * 0.94f, h * 0.86f)
            quadraticBezierTo(w * 0.7f, h * 0.78f, w * 0.5f, h * 0.96f)
            close()
        }
        drawPath(left, primary)
        drawPath(right, primary)
    }
}

/** رسم مبسّط لمبنى مدرسة بين تلال وأشجار، يُستخدم في شاشة الترحيب. */
@Composable
fun SchoolIllustration(modifier: Modifier = Modifier) {
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val tint = MaterialTheme.colorScheme.primaryContainer
    val wall = MaterialTheme.colorScheme.surface
    Canvas(modifier.fillMaxWidth().height(220.dp)) {
        val w = size.width
        val h = size.height

        drawCircle(tint, radius = w * 0.55f, center = Offset(w * 0.15f, h * 1.15f))
        drawCircle(tint.copy(alpha = 0.7f), radius = w * 0.5f, center = Offset(w * 0.9f, h * 1.2f))

        fun tree(cx: Float) {
            drawRect(primary, topLeft = Offset(cx - 4f, h * 0.74f), size = Size(8f, h * 0.2f))
            drawCircle(secondary, radius = h * 0.12f, center = Offset(cx, h * 0.64f))
        }
        tree(w * 0.12f)
        tree(w * 0.2f)
        tree(w * 0.84f)
        tree(w * 0.92f)

        val bx = w * 0.26f
        val bw = w * 0.48f
        val top = h * 0.42f
        val bh = h * 0.5f
        drawRect(wall, topLeft = Offset(bx, top), size = Size(bw, bh))
        drawRect(primary, topLeft = Offset(bx, top), size = Size(bw, bh), style = Stroke(width = 3f))

        val roof = Path().apply {
            moveTo(bx - 10f, top)
            lineTo(bx + bw / 2f, top - h * 0.2f)
            lineTo(bx + bw + 10f, top)
            close()
        }
        drawPath(roof, primary)
        drawCircle(wall, radius = h * 0.06f, center = Offset(bx + bw / 2f, top - h * 0.07f))
        drawCircle(
            primary, radius = h * 0.06f, center = Offset(bx + bw / 2f, top - h * 0.07f),
            style = Stroke(width = 2f),
        )

        val ww = bw * 0.14f
        val wh = bh * 0.2f
        for (i in 0..2) {
            val xOff = bw * (0.08f + i * 0.1f)
            drawRect(tint, topLeft = Offset(bx + xOff, top + bh * 0.2f), size = Size(ww, wh))
            drawRect(
                tint,
                topLeft = Offset(bx + bw - xOff - ww, top + bh * 0.2f),
                size = Size(ww, wh),
            )
        }
        drawRect(
            secondary,
            topLeft = Offset(bx + bw * 0.42f, top + bh * 0.6f),
            size = Size(bw * 0.16f, bh * 0.4f),
        )
    }
}
