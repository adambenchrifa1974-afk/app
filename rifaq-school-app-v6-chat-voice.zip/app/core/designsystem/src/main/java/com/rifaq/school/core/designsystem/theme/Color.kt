package com.rifaq.school.core.designsystem.theme

import androidx.compose.ui.graphics.Color

// لوحة ألوان بأسلوب إنستغرام: أبيض/أسود نقي، أزرق للإجراءات، وتدرّج القصص الشهير.
val InstaBlue = Color(0xFF0095F6)
val InstaBlueDark = Color(0xFF1877F2)
val BlueContainer = Color(0xFFE0F1FF)

val BackgroundLight = Color.White
val SurfaceVariantLight = Color(0xFFEFEFEF)
val OutlineLight = Color(0xFFDBDBDB)
val TextLight = Color(0xFF262626)
val TextMutedLight = Color(0xFF737373)

val BackgroundDark = Color.Black
val SurfaceDark = Color(0xFF121212)
val SurfaceVariantDark = Color(0xFF1E1E1E)
val OutlineDark = Color(0xFF363636)
val TextDark = Color(0xFFF5F5F5)
val TextMutedDark = Color(0xFFA8A8A8)

val BrandGradient = listOf(InstaBlue, InstaBlueDark)
val StoryRingGradient = listOf(Color(0xFFFEDA75), Color(0xFFFA7E1E), Color(0xFFD62976), Color(0xFF962FBF), Color(0xFF4F5BD5))
val BadgeRed = Color(0xFFFF3040)
