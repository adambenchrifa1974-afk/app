package com.rifaq.school.feature.authentication

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rifaq.school.core.common.auth.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LoginUiState(
    val identifier: String = "",
    val password: String = "",
    val passwordVisible: Boolean = false,
    val rememberMe: Boolean = false,
    val error: String? = null,
    val signUpMode: Boolean = false,
    val name: String = "",
    val loading: Boolean = false,
    val info: String? = null,
)

/** تسجيل الدخول وإنشاء الحساب عبر Firebase Authentication (بريد إلكتروني + كلمة مرور). */
class LoginViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState: StateFlow<LoginUiState> = _uiState.asStateFlow()

    fun onIdentifierChange(value: String) = _uiState.update { it.copy(identifier = value, error = null, info = null) }
    fun onPasswordChange(value: String) = _uiState.update { it.copy(password = value, error = null) }
    fun onNameChange(value: String) = _uiState.update { it.copy(name = value, error = null) }
    fun togglePasswordVisible() = _uiState.update { it.copy(passwordVisible = !it.passwordVisible) }
    fun onRememberChange(value: Boolean) = _uiState.update { it.copy(rememberMe = value) }
    fun toggleMode() = _uiState.update { it.copy(signUpMode = !it.signUpMode, error = null) }

    /** يُرجع true إذا كانت المدخلات صالحة شكليًا. */
    fun submit(): Boolean {
        val s = _uiState.value
        val error = when {
            s.signUpMode && s.name.isBlank() -> "أدخل اسمك"
            s.identifier.isBlank() -> "أدخل البريد الإلكتروني"
            !s.identifier.contains('@') -> "أدخل بريدًا إلكترونيًا صحيحًا"
            s.password.length < 6 -> "كلمة المرور يجب ألا تقل عن 6 أحرف"
            else -> null
        }
        _uiState.update { it.copy(error = error) }
        return error == null
    }

    /** يرسل رابط إعادة تعيين كلمة المرور إلى البريد المكتوب. */
    fun resetPassword() {
        val s = _uiState.value
        if (s.loading) return
        if (!s.identifier.contains('@')) {
            _uiState.update { it.copy(error = "اكتب بريدك الإلكتروني أولًا", info = null) }
            return
        }
        _uiState.update { it.copy(loading = true, error = null, info = null) }
        viewModelScope.launch {
            val result = AuthRepository.resetPassword(s.identifier)
            _uiState.update {
                it.copy(
                    loading = false,
                    error = result.exceptionOrNull()?.message,
                    info = if (result.isSuccess) "أرسلنا رابط إعادة التعيين إلى بريدك" else null,
                )
            }
        }
    }

    /** يتحقق من المدخلات ثم يسجّل الدخول أو ينشئ الحساب حسب الوضع الحالي. */
    fun authenticate(onSuccess: () -> Unit) {
        if (_uiState.value.loading || !submit()) return
        val s = _uiState.value
        _uiState.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            val result = if (s.signUpMode) {
                AuthRepository.signUp(s.name, s.identifier, s.password)
            } else {
                AuthRepository.signIn(s.identifier, s.password)
            }
            _uiState.update { it.copy(loading = false, error = result.exceptionOrNull()?.message) }
            if (result.isSuccess) onSuccess()
        }
    }
}
