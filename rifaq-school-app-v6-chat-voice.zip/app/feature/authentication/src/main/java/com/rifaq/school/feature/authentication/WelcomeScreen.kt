package com.rifaq.school.feature.authentication

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rifaq.school.core.designsystem.component.AuroraBackground
import com.rifaq.school.core.designsystem.component.RifaqLogo
import com.rifaq.school.core.designsystem.component.RifaqPrimaryButton
import com.rifaq.school.core.designsystem.component.SchoolIllustration
import com.rifaq.school.core.designsystem.component.backdropSource
import com.rifaq.school.core.designsystem.component.glass
import com.rifaq.school.core.designsystem.component.rememberBackdropState

@Composable
fun WelcomeScreen(onStart: () -> Unit, onLoginClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val backdrop = rememberBackdropState()
    Box(Modifier.fillMaxSize()) {
        AuroraBackground(Modifier.backdropSource(backdrop))
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.weight(1f))
            RifaqLogo(size = 120.dp)
            Text(
                "رفاق المدرسة",
                modifier = Modifier.padding(top = 12.dp),
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold,
                color = scheme.primary,
            )
            Text(
                "معًا نحو مستقبل أفضل",
                modifier = Modifier.padding(top = 4.dp),
                style = MaterialTheme.typography.bodyLarge,
                color = scheme.onSurfaceVariant,
            )
            Spacer(Modifier.weight(1f))
            SchoolIllustration()
            Spacer(Modifier.weight(1f))
            Column(
                Modifier
                    .fillMaxWidth()
                    .glass(
                        state = backdrop,
                        shape = RoundedCornerShape(28.dp),
                        tint = scheme.surface.copy(alpha = 0.45f),
                        borderColor = scheme.onSurface.copy(alpha = 0.12f),
                    )
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                RifaqPrimaryButton("ابدأ الآن", onStart)
                Row(
                    Modifier.padding(top = 4.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "لديك حساب بالفعل؟",
                        style = MaterialTheme.typography.bodyMedium,
                        color = scheme.onSurfaceVariant,
                    )
                    TextButton(onClick = onLoginClick) { Text("تسجيل الدخول") }
                }
            }
        }
    }
}
