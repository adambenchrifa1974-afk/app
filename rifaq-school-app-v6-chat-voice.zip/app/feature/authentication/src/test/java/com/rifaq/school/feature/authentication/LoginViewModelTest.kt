package com.rifaq.school.feature.authentication

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LoginViewModelTest {
    @Test
    fun blankIdentifier_isRejected() {
        val vm = LoginViewModel()
        assertFalse(vm.submit())
        assertNotNull(vm.uiState.value.error)
    }

    @Test
    fun shortPassword_isRejected() {
        val vm = LoginViewModel()
        vm.onIdentifierChange("ahmed@example.com")
        vm.onPasswordChange("123")
        assertFalse(vm.submit())
    }

    @Test
    fun validInput_isAccepted() {
        val vm = LoginViewModel()
        vm.onIdentifierChange("ahmed@example.com")
        vm.onPasswordChange("123456")
        assertTrue(vm.submit())
        assertNull(vm.uiState.value.error)
        assertEquals("ahmed@example.com", vm.uiState.value.identifier)
    }
}
