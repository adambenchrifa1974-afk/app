package com.rifaq.school.feature.challenges

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rifaq.school.core.common.gamification.Badge
import com.rifaq.school.core.common.gamification.Badges
import com.rifaq.school.core.common.gamification.GamificationStats
import com.rifaq.school.core.common.gamification.Quiz
import com.rifaq.school.core.common.gamification.XP_PER_LEVEL
import com.rifaq.school.core.designsystem.component.RifaqHeader
import com.rifaq.school.core.designsystem.component.RifaqPrimaryButton
import com.rifaq.school.core.designsystem.theme.BrandGradient

@Composable
fun ChallengesRoute(
    onBack: () -> Unit,
    onOpenQuiz: (quizId: String, daily: Boolean) -> Unit,
    viewModel: ChallengesViewModel = viewModel(),
) {
    val stats by viewModel.stats.collectAsStateWithLifecycle()
    val tasks by viewModel.tasks.collectAsStateWithLifecycle()
    val earned = Badges.earnedIds(stats, tasks.count { it.done })

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        RifaqHeader(
            title = "التحديات والإنجازات",
            leading = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                }
            },
        )
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { LevelCard(stats) }
            item { DailyCard(viewModel.dailyQuiz) { onOpenQuiz(viewModel.dailyQuiz.id, true) } }
            item {
                Text("اختبارات المواد", style = MaterialTheme.typography.titleMedium)
            }
            viewModel.quizzes.forEach { quiz ->
                item(key = quiz.id) { QuizCard(quiz) { onOpenQuiz(quiz.id, false) } }
            }
            item {
                Text(
                    "الشارات (${earned.size}/${Badges.all.size})",
                    modifier = Modifier.padding(top = 8.dp),
                    style = MaterialTheme.typography.titleMedium,
                )
            }
            Badges.all.chunked(2).forEachIndexed { rowIndex, rowBadges ->
                item(key = "badges_$rowIndex") {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        rowBadges.forEach { badge ->
                            BadgeCard(badge, badge.id in earned, Modifier.weight(1f))
                        }
                        if (rowBadges.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun LevelCard(stats: GamificationStats) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(BrandGradient))
            .padding(20.dp),
    ) {
        Text("المستوى ${stats.level}", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(
            "${stats.xpIntoLevel} / $XP_PER_LEVEL نقطة خبرة",
            modifier = Modifier.padding(top = 2.dp, bottom = 12.dp),
            color = Color.White.copy(alpha = 0.9f),
        )
        LinearProgressIndicator(
            progress = { stats.xpIntoLevel / XP_PER_LEVEL.toFloat() },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
            color = Color.White,
            trackColor = Color.White.copy(alpha = 0.3f),
        )
        Text(
            "مجموع النقاط: ${stats.xp}",
            modifier = Modifier.padding(top = 10.dp),
            color = Color.White.copy(alpha = 0.9f),
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}

@Composable
private fun DailyCard(quiz: Quiz, onStart: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(scheme.surfaceVariant)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.EmojiEvents, contentDescription = null, tint = scheme.primary)
            Text(
                "تحدي اليوم",
                modifier = Modifier.padding(horizontal = 8.dp),
                style = MaterialTheme.typography.titleMedium,
            )
        }
        Text(quiz.title, style = MaterialTheme.typography.bodyLarge)
        Text(
            "نقاط مضاعفة، وتُمنح مرة واحدة في اليوم",
            style = MaterialTheme.typography.bodyMedium,
            color = scheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(6.dp))
        RifaqPrimaryButton("ابدأ التحدي", onStart)
    }
}

@Composable
private fun QuizCard(quiz: Quiz, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(scheme.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(quiz.title, style = MaterialTheme.typography.titleMedium)
            Text(
                "${quiz.questions.size} أسئلة • ${quiz.subject}",
                style = MaterialTheme.typography.bodyMedium,
                color = scheme.onSurfaceVariant,
            )
        }
        Text("ابدأ", color = scheme.primary, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun BadgeCard(badge: Badge, earned: Boolean, modifier: Modifier) {
    val scheme = MaterialTheme.colorScheme
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (earned) scheme.primary.copy(alpha = 0.16f) else scheme.surfaceVariant)
            .padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(if (earned) scheme.primary else scheme.outline),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (earned) Icons.Outlined.EmojiEvents else Icons.Outlined.Lock,
                contentDescription = null,
                tint = if (earned) scheme.onPrimary else scheme.onSurfaceVariant,
            )
        }
        Text(
            badge.title,
            modifier = Modifier.padding(top = 8.dp),
            style = MaterialTheme.typography.titleMedium,
            fontSize = 14.sp,
            color = if (earned) scheme.onSurface else scheme.onSurfaceVariant,
        )
        Text(
            badge.description,
            style = MaterialTheme.typography.bodyMedium,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            color = scheme.onSurfaceVariant,
        )
    }
}
