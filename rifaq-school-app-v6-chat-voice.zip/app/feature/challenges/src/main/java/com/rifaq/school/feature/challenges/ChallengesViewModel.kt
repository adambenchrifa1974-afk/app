package com.rifaq.school.feature.challenges

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import com.rifaq.school.core.common.gamification.GamificationRepository
import com.rifaq.school.core.common.gamification.GamificationStats
import com.rifaq.school.core.common.gamification.Quiz
import com.rifaq.school.core.common.gamification.QuizBank
import com.rifaq.school.core.common.gamification.QuizLogic
import com.rifaq.school.core.common.gamification.QuizState
import com.rifaq.school.core.common.planner.PlannerRepository
import com.rifaq.school.core.common.planner.StudyTask
import java.util.Calendar
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class ChallengesViewModel : ViewModel() {
    val stats: StateFlow<GamificationStats> = GamificationRepository.stats
    val tasks: StateFlow<List<StudyTask>> = PlannerRepository.tasks
    val quizzes: List<Quiz> = QuizBank.quizzes
    val dailyQuiz: Quiz = QuizBank.dailyQuiz(Calendar.getInstance().get(Calendar.DAY_OF_YEAR))
}

class QuizViewModel(savedStateHandle: SavedStateHandle) : ViewModel() {
    private val quizId: String = savedStateHandle.get<String>("id") ?: ""
    private val isDaily: Boolean = savedStateHandle.get<String>("daily") == "1"

    private val quiz: Quiz? = QuizBank.byId(quizId)
    private val _state = MutableStateFlow<QuizState?>(quiz?.let { QuizState(it) })
    val state: StateFlow<QuizState?> = _state.asStateFlow()

    fun select(option: Int) {
        _state.update { current -> current?.let { QuizLogic.select(it, option) } }
    }

    fun next() {
        val current = _state.value ?: return
        val advanced = QuizLogic.advance(current)
        if (advanced.finished && !current.finished) {
            val xp = GamificationRepository.completeQuiz(
                quizId = current.quiz.id,
                correct = advanced.correct,
                total = current.quiz.questions.size,
                isDaily = isDaily,
            )
            _state.value = advanced.copy(xpEarned = xp)
        } else {
            _state.value = advanced
        }
    }
}
