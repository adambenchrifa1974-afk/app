package com.rifaq.school.feature.challenges

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rifaq.school.core.common.gamification.QuizState
import com.rifaq.school.core.designsystem.component.RifaqHeader
import com.rifaq.school.core.designsystem.component.RifaqPrimaryButton

private val Correct = Color(0xFF1FA45B)
private val Wrong = Color(0xFFE5484D)

@Composable
fun QuizRoute(onBack: () -> Unit, viewModel: QuizViewModel = viewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val current = state

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        RifaqHeader(
            title = current?.quiz?.title ?: "اختبار",
            leading = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                }
            },
        )
        when {
            current == null -> Text(
                "الاختبار غير موجود",
                modifier = Modifier.fillMaxWidth().padding(32.dp),
                textAlign = TextAlign.Center,
            )
            current.finished -> ResultView(current, onBack)
            else -> QuestionView(current, viewModel::select, viewModel::next)
        }
    }
}

@Composable
private fun QuestionView(state: QuizState, onSelect: (Int) -> Unit, onNext: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val total = state.quiz.questions.size
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            "السؤال ${state.index + 1} من $total",
            style = MaterialTheme.typography.bodyMedium,
            color = scheme.onSurfaceVariant,
        )
        LinearProgressIndicator(
            progress = { (state.index + if (state.answered) 1 else 0) / total.toFloat() },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
            color = scheme.primary,
            trackColor = scheme.surfaceVariant,
        )
        Text(
            state.question.text,
            modifier = Modifier.padding(vertical = 8.dp),
            style = MaterialTheme.typography.titleLarge,
        )
        state.question.options.forEachIndexed { i, option ->
            OptionCard(
                text = option,
                answered = state.answered,
                isCorrect = i == state.question.correctIndex,
                isSelected = i == state.selected,
                onClick = { onSelect(i) },
            )
        }
        if (state.answered) {
            Text(
                state.question.explanation,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(scheme.surfaceVariant)
                    .padding(14.dp),
                style = MaterialTheme.typography.bodyLarge,
            )
            RifaqPrimaryButton(
                text = if (state.index == total - 1) "إنهاء" else "التالي",
                onClick = onNext,
            )
        }
    }
}

@Composable
private fun OptionCard(
    text: String,
    answered: Boolean,
    isCorrect: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val accent = when {
        !answered -> scheme.outline
        isCorrect -> Correct
        isSelected -> Wrong
        else -> scheme.outline
    }
    val background by animateColorAsState(
        targetValue = when {
            answered && isCorrect -> Correct.copy(alpha = 0.18f)
            answered && isSelected -> Wrong.copy(alpha = 0.18f)
            else -> scheme.surfaceVariant
        },
        label = "option",
    )
    Text(
        text,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(background)
            .border(BorderStroke(1.5.dp, accent), RoundedCornerShape(14.dp))
            .clickable(enabled = !answered, onClick = onClick)
            .padding(16.dp),
        style = MaterialTheme.typography.bodyLarge,
    )
}

@Composable
private fun ResultView(state: QuizState, onBack: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val total = state.quiz.questions.size
    Column(
        Modifier.fillMaxSize().navigationBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("النتيجة", style = MaterialTheme.typography.titleLarge)
        Text(
            "${state.correct} / $total",
            modifier = Modifier.padding(vertical = 12.dp),
            fontSize = 56.sp,
            fontWeight = FontWeight.Bold,
            color = scheme.primary,
        )
        Text(
            when {
                state.correct == total -> "ممتاز! علامة كاملة"
                state.correct * 2 >= total -> "أحسنت، واصل التقدم"
                else -> "لا بأس، حاول مرة أخرى لتتحسن"
            },
            style = MaterialTheme.typography.bodyLarge,
        )
        Text(
            if (state.xpEarned > 0) "+${state.xpEarned} نقطة خبرة"
            else "سبق أن نلت نقاط هذا الاختبار اليوم",
            modifier = Modifier.padding(top = 12.dp),
            style = MaterialTheme.typography.titleMedium,
            color = scheme.primary,
        )
        Spacer(Modifier.height(24.dp))
        RifaqPrimaryButton("العودة", onBack)
    }
}
