package com.rifaq.school.feature.chat

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rifaq.school.core.common.model.ChatMsg
import com.rifaq.school.core.designsystem.component.RifaqAvatar
import com.rifaq.school.core.designsystem.component.RifaqHeader
import com.rifaq.school.core.designsystem.theme.BadgeRed
import com.rifaq.school.core.designsystem.theme.BrandGradient
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private fun formatSeconds(total: Int): String = "%d:%02d".format(total / 60, total % 60)

@Composable
fun ChatDetailRoute(onBack: () -> Unit, viewModel: ChatDetailViewModel = viewModel()) {
    val context = LocalContext.current
    val appContext = context.applicationContext
    val scope = rememberCoroutineScope()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val scheme = MaterialTheme.colorScheme
    val listState = rememberLazyListState()
    var draft by rememberSaveable { mutableStateOf("") }

    val recorder = remember { VoiceRecorder(appContext) }
    val player = remember { VoicePlayer(appContext) }
    val playingId by player.playingId.collectAsStateWithLifecycle()
    var recording by remember { mutableStateOf(false) }
    var seconds by remember { mutableIntStateOf(0) }

    DisposableEffect(Unit) {
        onDispose {
            recorder.cancel()
            player.stop()
        }
    }

    fun beginRecording() {
        player.stop()
        if (recorder.start()) {
            seconds = 0
            recording = true
        } else {
            Toast.makeText(context, "تعذّر بدء التسجيل", Toast.LENGTH_SHORT).show()
        }
    }

    fun finishRecording(send: Boolean) {
        recording = false
        if (send) {
            val rec = recorder.stop()
            if (rec != null) viewModel.sendVoice(rec.bytes, rec.seconds)
            else Toast.makeText(context, "التسجيل قصير جدًا", Toast.LENGTH_SHORT).show()
        } else {
            recorder.cancel()
        }
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) beginRecording()
        else Toast.makeText(context, "اسمح باستخدام الميكروفون لإرسال رسالة صوتية", Toast.LENGTH_LONG).show()
    }

    fun onMicClick() {
        val granted = context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (granted) beginRecording() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    LaunchedEffect(recording) {
        if (recording) {
            while (seconds < VoiceRecorder.MAX_SECONDS) {
                delay(1000)
                seconds++
            }
            finishRecording(send = true)
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    Column(Modifier.fillMaxSize().background(scheme.background).imePadding()) {
        RifaqHeader(
            title = viewModel.title,
            leading = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                }
                RifaqAvatar(viewModel.title, size = 36.dp, shape = RoundedCornerShape(12.dp))
            },
        )
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(messages, key = { it.id }) { message ->
                Bubble(
                    message = message,
                    playing = playingId == message.id,
                    onTogglePlay = {
                        scope.launch { player.toggle(message.id) { viewModel.loadAudio(message.id) } }
                    },
                )
            }
        }
        if (recording) {
            Row(
                Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { finishRecording(send = false) }) {
                    Icon(Icons.Filled.Delete, contentDescription = "إلغاء التسجيل", tint = BadgeRed)
                }
                Box(Modifier.size(10.dp).clip(CircleShape).background(BadgeRed))
                Text(
                    "  ${formatSeconds(seconds)}",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleMedium,
                )
                SendButton(enabled = true, onClick = { finishRecording(send = true) }) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "إرسال", tint = Color.White)
                }
            }
        } else {
            Row(
                Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("اكتب رسالة") },
                    maxLines = 4,
                    shape = RoundedCornerShape(26.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = scheme.surfaceVariant,
                        unfocusedContainerColor = scheme.surfaceVariant,
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                    ),
                )
                val canSend = draft.isNotBlank()
                SendButton(
                    enabled = true,
                    onClick = {
                        if (canSend) {
                            viewModel.send(draft)
                            draft = ""
                        } else {
                            onMicClick()
                        }
                    },
                ) {
                    Icon(
                        if (canSend) Icons.AutoMirrored.Filled.Send else Icons.Filled.Mic,
                        contentDescription = if (canSend) "إرسال" else "تسجيل رسالة صوتية",
                        tint = Color.White,
                    )
                }
            }
        }
    }
}

@Composable
private fun SendButton(enabled: Boolean, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier
            .padding(start = 8.dp)
            .size(48.dp)
            .clip(CircleShape)
            .background(Brush.linearGradient(BrandGradient))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
private fun Bubble(message: ChatMsg, playing: Boolean, onTogglePlay: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    // ظهور نابض ناعم لكل فقاعة جديدة.
    val pop = remember { Animatable(0.82f) }
    LaunchedEffect(Unit) {
        pop.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium))
    }
    val bubbleShape = if (message.mine) {
        RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp)
    } else {
        RoundedCornerShape(20.dp, 20.dp, 20.dp, 6.dp)
    }
    val fg = if (message.mine) Color.White else scheme.onSurface
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.mine) Arrangement.End else Arrangement.Start,
    ) {
        Column(
            Modifier
                .scale(pop.value)
                .clip(bubbleShape)
                .then(
                    if (message.mine) Modifier.background(Brush.linearGradient(BrandGradient))
                    else Modifier.background(scheme.surfaceVariant),
                )
                .padding(horizontal = 14.dp, vertical = 9.dp),
        ) {
            if (message.voiceSeconds != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onTogglePlay, modifier = Modifier.size(36.dp)) {
                        Icon(
                            if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = if (playing) "إيقاف" else "تشغيل",
                            tint = fg,
                        )
                    }
                    Row(
                        Modifier.padding(horizontal = 8.dp).width(96.dp).height(24.dp),
                        horizontalArrangement = Arrangement.spacedBy(3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        WaveHeights.forEach { h ->
                            Box(Modifier.width(3.dp).height(h.dp).clip(CircleShape).background(fg.copy(alpha = if (playing) 1f else 0.6f)))
                        }
                    }
                    Text(formatSeconds(message.voiceSeconds), color = fg, fontSize = 13.sp)
                }
            } else {
                Text(message.text, color = fg, style = MaterialTheme.typography.bodyLarge)
            }
            Text(
                message.time,
                modifier = Modifier.padding(top = 2.dp),
                fontSize = 11.sp,
                color = if (message.mine) Color.White.copy(alpha = 0.8f) else scheme.onSurfaceVariant,
            )
        }
    }
}

private val WaveHeights = listOf(8, 14, 20, 12, 22, 16, 9, 18, 24, 13, 10, 19, 15, 8, 12, 6)
