package com.rifaq.school.feature.chat

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rifaq.school.core.common.chat.ChatRepository
import com.rifaq.school.core.common.model.ChatMsg
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn

/** محادثة حقيقية عبر Firestore: نصوص ورسائل صوتية. */
class ChatDetailViewModel(savedStateHandle: SavedStateHandle) : ViewModel() {
    private val chatId: String = savedStateHandle.get<String>("id").orEmpty()

    val title: String = ChatRepository.nameOf(chatId)
        ?: ChatRepository.chats.value.firstOrNull { it.id == chatId }?.name
        ?: "محادثة"

    val messages: StateFlow<List<ChatMsg>> = ChatRepository.messages(chatId)
        .onEach { ChatRepository.markReadIfNeeded(chatId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun send(text: String) = ChatRepository.sendText(chatId, text)

    fun sendVoice(bytes: ByteArray, seconds: Int) = ChatRepository.sendVoice(chatId, bytes, seconds)

    suspend fun loadAudio(messageId: String): ByteArray? = ChatRepository.loadAudio(chatId, messageId)
}
