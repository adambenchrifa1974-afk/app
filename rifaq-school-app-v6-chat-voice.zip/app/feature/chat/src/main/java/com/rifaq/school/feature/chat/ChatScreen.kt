package com.rifaq.school.feature.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rifaq.school.core.common.model.ChatSummary
import com.rifaq.school.core.designsystem.component.RifaqAvatar
import com.rifaq.school.core.designsystem.component.RifaqHeader
import com.rifaq.school.core.designsystem.component.RifaqSearchField
import com.rifaq.school.core.designsystem.theme.BadgeRed
import com.rifaq.school.core.designsystem.theme.BottomBarSpace

@Composable
fun ChatRoute(
    onOpenChat: (String) -> Unit,
    onNewChat: () -> Unit,
    onBack: () -> Unit,
    viewModel: ChatViewModel = viewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    ChatScreen(state, viewModel::onQueryChange, onOpenChat, onNewChat, onBack)
}

@Composable
fun ChatScreen(
    state: ChatUiState,
    onQueryChange: (String) -> Unit,
    onOpenChat: (String) -> Unit,
    onNewChat: () -> Unit,
    onBack: () -> Unit,
) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        RifaqHeader(
            title = "المحادثات",
            leading = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                }
            },
            trailing = {
                IconButton(onClick = onNewChat) {
                    Icon(Icons.Outlined.Add, contentDescription = "محادثة جديدة")
                }
            },
        )
        RifaqSearchField(
            value = state.query,
            onValueChange = onQueryChange,
            placeholder = "ابحث عن محادثة",
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
        )
        if (state.chats.isEmpty()) {
            Text(
                if (state.query.isBlank()) "لا توجد محادثات بعد. اضغط + لبدء محادثة مع زميل." else "لا توجد نتائج",
                modifier = Modifier.fillMaxWidth().padding(32.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyLarge,
            )
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = BottomBarSpace)) {
                items(state.chats, key = { it.id }) { chat ->
                    ChatRow(chat, onClick = { onOpenChat(chat.id) })
                    HorizontalDivider(
                        modifier = Modifier.padding(start = 80.dp),
                        color = MaterialTheme.colorScheme.outline,
                    )
                }
            }
        }
    }
}

@Composable
private fun ChatRow(chat: ChatSummary, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RifaqAvatar(chat.name, size = 54.dp, shape = RoundedCornerShape(16.dp))
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(
                chat.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = if (chat.unread > 0) FontWeight.Bold else FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                chat.lastMessage,
                modifier = Modifier.padding(top = 2.dp),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(
                chat.time,
                style = MaterialTheme.typography.bodyMedium,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (chat.unread > 0) {
                Box(
                    Modifier
                        .padding(top = 6.dp)
                        .defaultMinSize(minWidth = 20.dp, minHeight = 20.dp)
                        .clip(CircleShape)
                        .background(BadgeRed)
                        .padding(horizontal = 5.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "${chat.unread}",
                        color = Color.White,
                        fontSize = 11.sp,
                        lineHeight = 14.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            } else {
                Box(Modifier.padding(top = 6.dp).defaultMinSize(minHeight = 20.dp))
            }
        }
    }
}
