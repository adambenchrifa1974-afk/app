package com.rifaq.school.feature.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rifaq.school.core.common.chat.ChatRepository
import com.rifaq.school.core.common.model.ChatSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class ChatUiState(
    val query: String = "",
    val chats: List<ChatSummary> = emptyList(),
)

class ChatViewModel : ViewModel() {
    private val query = MutableStateFlow("")

    val uiState: StateFlow<ChatUiState> = combine(query, ChatRepository.chats) { q, all ->
        ChatUiState(q, filter(all, q))
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ChatUiState())

    fun onQueryChange(value: String) {
        query.value = value
    }

    private fun filter(all: List<ChatSummary>, q: String): List<ChatSummary> {
        val term = q.trim()
        if (term.isEmpty()) return all
        return all.filter { it.name.contains(term) || it.lastMessage.contains(term) }
    }
}
