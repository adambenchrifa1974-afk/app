package com.rifaq.school.feature.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rifaq.school.core.common.chat.ChatRepository
import com.rifaq.school.core.common.model.AppUser
import com.rifaq.school.core.designsystem.component.RifaqAvatar
import com.rifaq.school.core.designsystem.component.RifaqHeader
import com.rifaq.school.core.designsystem.component.RifaqSearchField
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class NewChatUiState(
    val loading: Boolean = true,
    val users: List<AppUser> = emptyList(),
    val query: String = "",
    val error: String? = null,
    val opening: Boolean = false,
) {
    val filtered: List<AppUser>
        get() = query.trim().let { q -> if (q.isEmpty()) users else users.filter { it.name.contains(q, ignoreCase = true) } }
}

class NewChatViewModel : ViewModel() {
    private val _state = MutableStateFlow(NewChatUiState())
    val state: StateFlow<NewChatUiState> = _state.asStateFlow()

    init {
        load()
    }

    fun load() {
        _state.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            ChatRepository.loadUsers()
                .onSuccess { list -> _state.update { it.copy(loading = false, users = list) } }
                .onFailure { _state.update { s -> s.copy(loading = false, error = "تعذّر تحميل المستخدمين، تحقق من الاتصال") } }
        }
    }

    fun onQueryChange(value: String) = _state.update { it.copy(query = value) }

    fun open(user: AppUser, onOpened: (String) -> Unit) {
        if (_state.value.opening) return
        _state.update { it.copy(opening = true) }
        viewModelScope.launch {
            ChatRepository.openDirectChat(user)
                .onSuccess { id ->
                    _state.update { it.copy(opening = false) }
                    onOpened(id)
                }
                .onFailure { _state.update { s -> s.copy(opening = false, error = "تعذّر فتح المحادثة") } }
        }
    }
}

@Composable
fun NewChatRoute(onBack: () -> Unit, onOpened: (String) -> Unit, viewModel: NewChatViewModel = viewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val scheme = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().background(scheme.background)) {
        RifaqHeader(
            title = "محادثة جديدة",
            leading = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                }
            },
        )
        RifaqSearchField(
            value = state.query,
            onValueChange = viewModel::onQueryChange,
            placeholder = "ابحث عن اسم",
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
        )
        when {
            state.loading -> CircularProgressIndicator(Modifier.padding(32.dp).align(Alignment.CenterHorizontally))
            state.error != null -> Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(state.error!!, color = scheme.error, style = MaterialTheme.typography.bodyLarge)
                TextButton(onClick = viewModel::load) { Text("إعادة المحاولة") }
            }
            state.filtered.isEmpty() -> Text(
                if (state.users.isEmpty()) "لا يوجد مستخدمون آخرون بعد. ادعُ أصدقاءك لإنشاء حساب." else "لا توجد نتائج",
                modifier = Modifier.fillMaxWidth().padding(32.dp),
                color = scheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyLarge,
            )
            else -> LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                items(state.filtered, key = { it.uid }) { user ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.open(user, onOpened) }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RifaqAvatar(user.name, size = 48.dp, shape = RoundedCornerShape(14.dp))
                        Column(Modifier.padding(horizontal = 12.dp)) {
                            Text(user.name, style = MaterialTheme.typography.titleMedium)
                            if (user.role.isNotBlank()) {
                                Text(user.role, style = MaterialTheme.typography.bodyMedium, color = scheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}
