package com.rifaq.school.feature.chat

import android.content.Context
import android.media.MediaPlayer
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** تشغيل رسالة صوتية واحدة في كل مرة. الصوت يُحفظ مؤقتًا في ذاكرة التخزين المؤقتة بعد أول تشغيل. */
class VoicePlayer(private val context: Context) {
    private var player: MediaPlayer? = null
    private val _playingId = MutableStateFlow<String?>(null)
    val playingId: StateFlow<String?> = _playingId.asStateFlow()

    /** يشغّل الرسالة [id] أو يوقفها إن كانت قيد التشغيل. [fetch] يجلب الصوت إن لم يكن محفوظًا. */
    suspend fun toggle(id: String, fetch: suspend () -> ByteArray?) {
        if (_playingId.value == id) {
            stop()
            return
        }
        val f = File(context.cacheDir, "voice_$id.m4a")
        if (!f.exists()) {
            val bytes = fetch() ?: return
            f.writeBytes(bytes)
        }
        start(id, f)
    }

    private fun start(id: String, f: File) {
        stop()
        val p = MediaPlayer()
        try {
            p.setDataSource(f.absolutePath)
            p.setOnCompletionListener { stop() }
            p.prepare()
            p.start()
            player = p
            _playingId.value = id
        } catch (e: Exception) {
            runCatching { p.release() }
            f.delete()
        }
    }

    fun stop() {
        player?.let {
            runCatching { it.stop() }
            runCatching { it.release() }
        }
        player = null
        _playingId.value = null
    }
}
