package com.rifaq.school.feature.chat

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.os.SystemClock
import java.io.File

/** تسجيل صوت AAC أحادي بجودة منخفضة (≈ 3 كيلوبايت/ثانية) ليبقى حجم الرسالة صغيرًا. */
class VoiceRecorder(private val context: Context) {
    class Recorded(val bytes: ByteArray, val seconds: Int)

    private var recorder: MediaRecorder? = null
    private var file: File? = null
    private var startedAt = 0L

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else MediaRecorder()

    fun start(): Boolean {
        val target = File(context.cacheDir, "rec_${System.currentTimeMillis()}.m4a")
        val r = newRecorder()
        return try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioChannels(1)
            r.setAudioSamplingRate(16_000)
            r.setAudioEncodingBitRate(24_000)
            r.setOutputFile(target.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            file = target
            startedAt = SystemClock.elapsedRealtime()
            true
        } catch (e: Exception) {
            runCatching { r.release() }
            target.delete()
            false
        }
    }

    /** يوقف التسجيل ويُرجع الصوت، أو null إذا كان أقصر من ثانية أو فشل. */
    fun stop(): Recorded? {
        val r = recorder ?: return null
        val f = file
        recorder = null
        file = null
        val seconds = ((SystemClock.elapsedRealtime() - startedAt) / 1000).toInt()
        val ok = try {
            r.stop()
            true
        } catch (e: RuntimeException) {
            false
        } finally {
            runCatching { r.release() }
        }
        if (!ok || f == null) {
            f?.delete()
            return null
        }
        val bytes = runCatching { f.readBytes() }.getOrNull()
        f.delete()
        if (bytes == null || bytes.isEmpty() || seconds < 1) return null
        return Recorded(bytes, seconds.coerceAtMost(MAX_SECONDS))
    }

    fun cancel() {
        recorder?.let {
            runCatching { it.stop() }
            runCatching { it.release() }
        }
        recorder = null
        file?.delete()
        file = null
    }

    companion object {
        const val MAX_SECONDS = 60
    }
}
