package com.rifaq.school.feature.chat

import org.junit.Assert.assertEquals
import org.junit.Test

class ChatViewModelTest {
    @Test
    fun emptyInitialQuery() {
        assertEquals("", ChatUiState().query)
    }
}
