package com.rifaq.school.feature.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rifaq.school.core.common.model.Comment
import com.rifaq.school.core.common.model.FeedRepository
import com.rifaq.school.core.designsystem.component.RifaqAvatar

private val QuickEmojis = listOf("❤️", "🙌", "🔥", "👏", "😢", "😍", "😮", "😂")

/**
 * قائمة تعليقات سفلية بأسلوب إنستغرام: ردود متداخلة، إعجاب بالتعليق، ورد بالإشارة (@).
 * التعليقات مخزنة في [FeedRepository] (Firestore، والريلز محلية).
 * [postId] قد يكون منشورًا أو ريلز ([FeedRepository.REEL_PREFIX] + رقمه).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun CommentsSheet(postId: String, onDismiss: () -> Unit) {
    DisposableEffect(postId) {
        FeedRepository.observeComments(postId)
        onDispose { FeedRepository.stopObservingComments(postId) }
    }
    val all by FeedRepository.comments.collectAsStateWithLifecycle()
    val comments = all[postId].orEmpty()
    val topLevel = comments.filter { it.parentId == null }
    var draft by rememberSaveable { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<Comment?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        Column(Modifier.fillMaxWidth().imePadding().navigationBarsPadding()) {
            Text(
                "التعليقات (${comments.size})",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                style = MaterialTheme.typography.titleMedium,
            )
            if (comments.isEmpty()) {
                Text(
                    "لا توجد تعليقات بعد. كن أول من يعلّق!",
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            LazyColumn(Modifier.weight(1f, fill = false).heightIn(max = 360.dp)) {
                topLevel.forEach { parent ->
                    val replies = comments.filter { it.parentId == parent.id }
                    item(key = parent.id) {
                        CommentRow(
                            comment = parent,
                            isReply = false,
                            onLike = { FeedRepository.toggleCommentLike(postId, parent.id) },
                            onReply = {
                                replyTo = parent
                                draft = "@${parent.author} "
                            },
                        )
                    }
                    items(replies, key = { it.id }) { reply ->
                        CommentRow(
                            comment = reply,
                            isReply = true,
                            onLike = { FeedRepository.toggleCommentLike(postId, reply.id) },
                            onReply = {
                                replyTo = reply
                                draft = "@${reply.author} "
                            },
                        )
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                QuickEmojis.forEach { emoji ->
                    Text(
                        emoji,
                        modifier = Modifier.clickable { draft += emoji }.padding(6.dp),
                        fontSize = 22.sp,
                    )
                }
            }

            val target = replyTo
            if (target != null) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "الرد على ${target.author}",
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    IconButton(
                        onClick = {
                            replyTo = null
                            draft = ""
                        },
                        modifier = Modifier.size(32.dp),
                    ) { Icon(Icons.Filled.Close, contentDescription = "إلغاء الرد", modifier = Modifier.size(18.dp)) }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("أضف تعليقًا...") },
                    singleLine = true,
                    shape = RoundedCornerShape(26.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                    ),
                )
                TextButton(
                    onClick = {
                        val parent = replyTo?.let { it.parentId ?: it.id }
                        FeedRepository.addComment(postId, draft, parent)
                        draft = ""
                        replyTo = null
                    },
                    enabled = draft.isNotBlank(),
                ) { Text("نشر", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun CommentRow(
    comment: Comment,
    isReply: Boolean,
    onLike: () -> Unit,
    onReply: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = if (isReply) 56.dp else 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
    ) {
        RifaqAvatar(comment.author, size = if (isReply) 26.dp else 34.dp)
        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(comment.author, style = MaterialTheme.typography.titleMedium)
                Text(
                    "  ${comment.timeAgo}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(comment.text, style = MaterialTheme.typography.bodyLarge)
            Row(Modifier.padding(top = 4.dp)) {
                if (comment.likes > 0) {
                    Text(
                        "${comment.likes} إعجاب",
                        modifier = Modifier.padding(end = 14.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Text(
                    "رد",
                    modifier = Modifier.clickable(onClick = onReply),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        IconButton(onClick = onLike, modifier = Modifier.size(36.dp)) {
            Icon(
                if (comment.liked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                contentDescription = "إعجاب بالتعليق",
                tint = if (comment.liked) Color(0xFFFF3B5C) else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp),
            )
        }
    }
}
