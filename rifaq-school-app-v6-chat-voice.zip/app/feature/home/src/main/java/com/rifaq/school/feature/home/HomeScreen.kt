package com.rifaq.school.feature.home

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.PlayCircleOutline
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rifaq.school.core.common.model.DemoData
import com.rifaq.school.core.common.model.Post
import com.rifaq.school.core.common.model.Story
import com.rifaq.school.core.common.model.UserProfile
import com.rifaq.school.core.designsystem.component.PostCard
import com.rifaq.school.core.designsystem.component.RifaqAvatar
import com.rifaq.school.core.designsystem.component.RifaqHeader
import com.rifaq.school.core.designsystem.theme.BottomBarSpace
import com.rifaq.school.core.designsystem.theme.BrandGradient
import com.rifaq.school.core.designsystem.theme.StoryRingGradient

@Composable
fun HomeRoute(
    onCreatePost: () -> Unit,
    onOpenPlanner: () -> Unit,
    onOpenChallenges: () -> Unit,
    onOpenChats: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenReels: () -> Unit,
    viewModel: HomeViewModel = viewModel(),
) {
    val posts by viewModel.posts.collectAsStateWithLifecycle()
    val followed by viewModel.followed.collectAsStateWithLifecycle()
    val viewed by viewModel.viewedStories.collectAsStateWithLifecycle()
    val unreadChats by viewModel.unreadChats.collectAsStateWithLifecycle()
    HomeScreen(
        user = viewModel.user,
        stories = viewModel.stories,
        posts = posts,
        followed = followed,
        viewedStories = viewed,
        unreadChats = unreadChats,
        onCreatePost = onCreatePost,
        onOpenPlanner = onOpenPlanner,
        onOpenChallenges = onOpenChallenges,
        onOpenChats = onOpenChats,
        onOpenNotifications = onOpenNotifications,
        onOpenReels = onOpenReels,
        onToggleLike = viewModel::toggleLike,
        onDoubleTapLike = viewModel::like,
        onToggleSave = viewModel::toggleSave,
        onToggleFollow = viewModel::toggleFollow,
        onUnfollow = viewModel::unfollow,
        onHide = viewModel::hide,
        onDelete = viewModel::delete,
    )
}

@Composable
fun HomeScreen(
    user: UserProfile,
    stories: List<Story>,
    posts: List<Post>,
    followed: Set<String>,
    viewedStories: Set<Int>,
    unreadChats: Int,
    onCreatePost: () -> Unit,
    onOpenPlanner: () -> Unit,
    onOpenChallenges: () -> Unit,
    onOpenChats: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenReels: () -> Unit,
    onToggleLike: (String) -> Unit,
    onDoubleTapLike: (String) -> Unit,
    onToggleSave: (String) -> Unit,
    onToggleFollow: (String) -> Unit,
    onUnfollow: (String) -> Unit,
    onHide: (String) -> Unit,
    onDelete: (String) -> Unit,
) {
    var openStory by remember { mutableStateOf<Int?>(null) }
    var commentsPostId by remember { mutableStateOf<String?>(null) }
    var optionsPostId by remember { mutableStateOf<String?>(null) }

    BackHandler(enabled = openStory != null) { openStory = null }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            RifaqHeader(
                title = "رفاق المدرسة",
                titleColor = MaterialTheme.colorScheme.primary,
                leading = {
                    Row {
                        IconButton(onClick = onCreatePost) {
                            Icon(Icons.Filled.Add, contentDescription = "منشور جديد")
                        }
                        IconButton(onClick = onOpenNotifications) {
                            Icon(Icons.Outlined.FavoriteBorder, contentDescription = "الإشعارات")
                        }
                    }
                },
                trailing = {
                    Row {
                        IconButton(onClick = onOpenReels) {
                            Icon(Icons.Outlined.PlayCircleOutline, contentDescription = "ريلز")
                        }
                        IconButton(onClick = onOpenChats) {
                            BadgedBox(badge = { if (unreadChats > 0) Badge { Text("$unreadChats") } }) {
                                Icon(Icons.AutoMirrored.Outlined.Send, contentDescription = "المحادثات")
                            }
                        }
                    }
                },
            )
            LazyColumn(contentPadding = PaddingValues(bottom = BottomBarSpace)) {
                item { ShortcutsRow(onOpenPlanner, onOpenChallenges) }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        itemsIndexed(stories, key = { _, story -> story.id }) { index, story ->
                            StoryItem(
                                story = story,
                                viewed = story.id in viewedStories,
                                onClick = { openStory = index },
                            )
                        }
                    }
                }
                item { HorizontalDivider(color = MaterialTheme.colorScheme.outline) }
                items(posts, key = { it.id }) { post ->
                    PostCard(
                        authorName = post.authorName,
                        authorRole = post.authorRole,
                        timeAgo = post.timeAgo,
                        text = post.text,
                        likes = post.likes,
                        comments = post.comments,
                        cover = post.cover,
                        liked = post.liked,
                        saved = post.saved,
                        following = post.authorName in followed,
                        isMine = post.mine,
                        onLike = { onToggleLike(post.id) },
                        onDoubleTapLike = { onDoubleTapLike(post.id) },
                        onSave = { onToggleSave(post.id) },
                        onFollow = { onToggleFollow(post.authorName) },
                        onMore = { optionsPostId = post.id },
                        onCommentsClick = { commentsPostId = post.id },
                        modifier = Modifier.animateItem(),
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = openStory != null,
            enter = fadeIn(tween(200)) + scaleIn(
                initialScale = 0.6f,
                animationSpec = spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMediumLow),
            ),
            exit = fadeOut(tween(180)) + scaleOut(targetScale = 0.8f),
        ) {
            StoryViewer(
                stories = stories,
                startIndex = openStory ?: 0,
                onClose = { openStory = null },
            )
        }
    }

    commentsPostId?.let { id ->
        CommentsSheet(postId = id, onDismiss = { commentsPostId = null })
    }

    optionsPostId?.let { id ->
        posts.firstOrNull { it.id == id }?.let { post ->
            PostOptionsSheet(
                post = post,
                isMine = post.mine,
                following = post.authorName in followed,
                onDismiss = { optionsPostId = null },
                onToggleSave = { onToggleSave(post.id) },
                onUnfollow = { onUnfollow(post.authorName) },
                onHide = { onHide(post.id) },
                onDelete = { onDelete(post.id) },
            )
        }
    }
}

@Composable
private fun StoryItem(story: Story, viewed: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .width(76.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
            ),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) {
            if (!story.isMine) {
                Box(
                    Modifier
                        .size(72.dp)
                        .border(
                            2.5.dp,
                            if (viewed) {
                                Brush.linearGradient(
                                    listOf(
                                        MaterialTheme.colorScheme.outline,
                                        MaterialTheme.colorScheme.outline,
                                    ),
                                )
                            } else {
                                Brush.linearGradient(StoryRingGradient)
                            },
                            CircleShape,
                        ),
                )
            }
            RifaqAvatar(story.name, size = if (story.isMine) 68.dp else 60.dp)
            if (story.isMine) {
                Box(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                        .border(2.dp, MaterialTheme.colorScheme.background, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Filled.Add, contentDescription = null,
                        tint = Color.White, modifier = Modifier.size(15.dp),
                    )
                }
            }
        }
        Text(
            story.name,
            modifier = Modifier.padding(top = 4.dp),
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun ShortcutsRow(onOpenPlanner: () -> Unit, onOpenChallenges: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        ShortcutCard("الواجبات", "نظّم مهامك", Icons.Outlined.TaskAlt, onOpenPlanner, Modifier.weight(1f))
        ShortcutCard("التحديات", "اختبر نفسك", Icons.Outlined.EmojiEvents, onOpenChallenges, Modifier.weight(1f))
    }
}

@Composable
private fun ShortcutCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Brush.linearGradient(BrandGradient)),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, contentDescription = null, tint = Color.White) }
        Column(Modifier.padding(horizontal = 10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
