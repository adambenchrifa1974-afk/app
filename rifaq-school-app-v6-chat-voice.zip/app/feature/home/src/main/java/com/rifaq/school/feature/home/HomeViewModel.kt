package com.rifaq.school.feature.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rifaq.school.core.common.chat.ChatRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import com.rifaq.school.core.common.model.DemoData
import com.rifaq.school.core.common.model.FeedRepository
import com.rifaq.school.core.common.model.Post
import com.rifaq.school.core.common.model.SocialRepository
import com.rifaq.school.core.common.model.Story
import com.rifaq.school.core.common.model.UserProfile
import kotlinx.coroutines.flow.StateFlow

class HomeViewModel : ViewModel() {
    val user: UserProfile = DemoData.user
    val stories: List<Story> = DemoData.stories
    val posts: StateFlow<List<Post>> = FeedRepository.posts
    val followed: StateFlow<Set<String>> = SocialRepository.followed
    val unreadChats: StateFlow<Int> = ChatRepository.totalUnread
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
    val viewedStories: StateFlow<Set<Int>> = SocialRepository.viewedStories

    fun toggleLike(id: String) = FeedRepository.toggleLike(id)
    fun like(id: String) = FeedRepository.like(id)
    fun toggleSave(id: String) = FeedRepository.toggleSave(id)
    fun toggleFollow(name: String) = SocialRepository.toggleFollow(name)
    fun unfollow(name: String) = SocialRepository.unfollow(name)
    fun hide(id: String) = FeedRepository.hidePost(id)
    fun delete(id: String) = FeedRepository.deletePost(id)
}
