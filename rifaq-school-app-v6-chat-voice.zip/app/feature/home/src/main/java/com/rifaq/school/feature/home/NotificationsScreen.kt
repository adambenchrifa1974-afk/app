package com.rifaq.school.feature.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rifaq.school.core.common.model.DemoData
import com.rifaq.school.core.common.model.Notice
import com.rifaq.school.core.common.model.NoticeKind
import com.rifaq.school.core.common.model.SocialRepository
import com.rifaq.school.core.designsystem.component.RifaqAvatar
import com.rifaq.school.core.designsystem.component.RifaqCover
import com.rifaq.school.core.designsystem.component.RifaqHeader
import com.rifaq.school.core.designsystem.theme.BottomBarSpace
import com.rifaq.school.core.designsystem.theme.InstaBlue

/** شاشة النشاط: إعجابات، تعليقات، إشارات، ومتابعون جدد مع زر «متابعة بالمثل». */
@Composable
fun NotificationsRoute(onBack: () -> Unit) {
    val followed by SocialRepository.followed.collectAsStateWithLifecycle()
    val today = DemoData.notices.filter { it.today }
    val earlier = DemoData.notices.filterNot { it.today }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        RifaqHeader(
            title = "النشاط",
            leading = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                }
            },
        )
        LazyColumn(contentPadding = PaddingValues(bottom = BottomBarSpace)) {
            if (today.isNotEmpty()) {
                item { SectionTitle("اليوم") }
                items(today, key = { it.id }) { notice ->
                    NoticeRow(notice, notice.user in followed) { SocialRepository.toggleFollow(notice.user) }
                }
            }
            if (earlier.isNotEmpty()) {
                item { SectionTitle("هذا الأسبوع") }
                items(earlier, key = { it.id }) { notice ->
                    NoticeRow(notice, notice.user in followed) { SocialRepository.toggleFollow(notice.user) }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
    )
}

@Composable
private fun NoticeRow(notice: Notice, following: Boolean, onToggleFollow: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RifaqAvatar(notice.user, size = 44.dp)
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(notice.user) }
                append(" ")
                append(notice.text)
                withStyle(SpanStyle(color = scheme.onSurfaceVariant)) { append("  ${notice.timeAgo}") }
            },
            modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
            style = MaterialTheme.typography.bodyLarge,
        )
        when {
            notice.kind == NoticeKind.FOLLOW -> {
                Box(
                    Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (following) scheme.surfaceVariant else InstaBlue)
                        .clickable(onClick = onToggleFollow)
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                ) {
                    Text(
                        if (following) "تتابعه" else "متابعة بالمثل",
                        fontWeight = FontWeight.Bold,
                        color = if (following) scheme.onSurface else Color.White,
                    )
                }
            }
            else -> {
                notice.cover?.let { cover ->
                    RifaqCover(
                        seed = cover,
                        modifier = Modifier.size(44.dp).clip(RoundedCornerShape(6.dp)),
                    )
                }
            }
        }
    }
}
