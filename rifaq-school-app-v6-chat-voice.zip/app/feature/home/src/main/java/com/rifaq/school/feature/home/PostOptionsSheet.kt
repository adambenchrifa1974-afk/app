package com.rifaq.school.feature.home

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.PersonRemove
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.rifaq.school.core.common.model.Post

/** قائمة خيارات المنشور (⋯): حفظ، نسخ الرابط، مشاركة، إلغاء المتابعة، إخفاء، إبلاغ، حذف. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun PostOptionsSheet(
    post: Post,
    isMine: Boolean,
    following: Boolean,
    onDismiss: () -> Unit,
    onToggleSave: () -> Unit,
    onUnfollow: () -> Unit,
    onHide: () -> Unit,
    onDelete: () -> Unit,
) {
    val context = LocalContext.current
    val danger = Color(0xFFED4956)

    fun toast(message: String) = Toast.makeText(context, message, Toast.LENGTH_SHORT).show()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 12.dp)) {
            OptionRow(Icons.Outlined.BookmarkBorder, if (post.saved) "إلغاء الحفظ" else "حفظ") {
                onToggleSave()
                onDismiss()
            }
            OptionRow(Icons.Outlined.Link, "نسخ الرابط") {
                val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                manager.setPrimaryClip(
                    ClipData.newPlainText("post", "https://rifaq.school/p/${post.id}"),
                )
                toast("تم نسخ الرابط")
                onDismiss()
            }
            OptionRow(Icons.AutoMirrored.Outlined.Send, "مشاركة") {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, "${post.authorName}: ${post.text}")
                }
                context.startActivity(Intent.createChooser(send, null))
                onDismiss()
            }
            if (!isMine && following) {
                OptionRow(Icons.Outlined.PersonRemove, "إلغاء متابعة ${post.authorName}") {
                    onUnfollow()
                    toast("تم إلغاء المتابعة")
                    onDismiss()
                }
            }
            if (!isMine) {
                OptionRow(Icons.Outlined.VisibilityOff, "إخفاء هذا المنشور") {
                    onHide()
                    toast("تم إخفاء المنشور")
                    onDismiss()
                }
                OptionRow(Icons.Outlined.Flag, "إبلاغ", tint = danger) {
                    toast("شكرًا لك، سنراجع المنشور")
                    onDismiss()
                }
            } else {
                OptionRow(Icons.Outlined.Delete, "حذف المنشور", tint = danger) {
                    onDelete()
                    toast("تم حذف المنشور")
                    onDismiss()
                }
            }
        }
    }
}

@Composable
private fun OptionRow(
    icon: ImageVector,
    label: String,
    tint: Color = MaterialTheme.colorScheme.onSurface,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = tint)
        Text(
            label,
            modifier = Modifier.padding(horizontal = 16.dp),
            style = MaterialTheme.typography.titleMedium,
            color = tint,
        )
    }
}
