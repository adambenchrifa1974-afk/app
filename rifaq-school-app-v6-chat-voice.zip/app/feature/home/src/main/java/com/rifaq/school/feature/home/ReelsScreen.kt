package com.rifaq.school.feature.home

import android.content.Intent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rifaq.school.core.common.model.DemoData
import com.rifaq.school.core.common.model.FeedRepository
import com.rifaq.school.core.common.model.Reel
import com.rifaq.school.core.common.model.SocialRepository
import com.rifaq.school.core.designsystem.component.RifaqAvatar
import com.rifaq.school.core.designsystem.component.RifaqCover
import kotlinx.coroutines.delay

private val ReelLikeRed = Color(0xFFFF3B5C)

/**
 * ريلز: مقاطع قصيرة بتمرير عمودي بملء الشاشة. نقر مزدوج للإعجاب، تعليقات، حفظ، مشاركة، ومتابعة.
 * المقاطع تُعرض حاليًا كأغلفة ملوّنة إلى حين ربط فيديو حقيقي.
 */
@Composable
fun ReelsRoute(onBack: () -> Unit) {
    val reels = DemoData.reels
    val pagerState = rememberPagerState(pageCount = { reels.size })
    val liked by SocialRepository.likedReels.collectAsStateWithLifecycle()
    val saved by SocialRepository.savedReels.collectAsStateWithLifecycle()
    val followed by SocialRepository.followed.collectAsStateWithLifecycle()
    val allComments by FeedRepository.comments.collectAsStateWithLifecycle()
    var commentsReelId by remember { mutableStateOf<Int?>(null) }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        VerticalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
            val reel = reels[page]
            val isLiked = reel.id in liked
            ReelPage(
                reel = reel,
                liked = isLiked,
                saved = reel.id in saved,
                following = reel.author in followed,
                likeCount = reel.likes + if (isLiked) 1 else 0,
                commentCount = allComments[FeedRepository.REEL_PREFIX + reel.id]?.size ?: reel.comments,
                onLike = { SocialRepository.toggleReelLike(reel.id) },
                onDoubleTapLike = { SocialRepository.likeReel(reel.id) },
                onSave = { SocialRepository.toggleReelSave(reel.id) },
                onFollow = { SocialRepository.toggleFollow(reel.author) },
                onComments = { commentsReelId = reel.id },
            )
        }
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع", tint = Color.White)
            }
            Text("ريلز", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }

    commentsReelId?.let { id ->
        CommentsSheet(postId = FeedRepository.REEL_PREFIX + id, onDismiss = { commentsReelId = null })
    }
}

@Composable
private fun ReelPage(
    reel: Reel,
    liked: Boolean,
    saved: Boolean,
    following: Boolean,
    likeCount: Int,
    commentCount: Int,
    onLike: () -> Unit,
    onDoubleTapLike: () -> Unit,
    onSave: () -> Unit,
    onFollow: () -> Unit,
    onComments: () -> Unit,
) {
    val context = LocalContext.current
    var burstKey by remember { mutableIntStateOf(0) }
    val burst = remember { Animatable(0f) }
    LaunchedEffect(burstKey) {
        if (burstKey > 0) {
            burst.snapTo(0f)
            burst.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessMedium))
            delay(300)
            burst.animateTo(0f, tween(180))
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(reel.id) {
                detectTapGestures(onDoubleTap = {
                    onDoubleTapLike()
                    burstKey += 1
                })
            },
    ) {
        RifaqCover(seed = reel.cover, modifier = Modifier.fillMaxSize())

        Icon(
            Icons.Filled.Favorite,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.align(Alignment.Center).size(120.dp).scale(burst.value),
        )

        // أزرار التفاعل على الجانب.
        Column(
            Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(end = 8.dp, bottom = 96.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            ReelAction(
                icon = if (liked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                label = "$likeCount",
                tint = if (liked) ReelLikeRed else Color.White,
                onClick = onLike,
            )
            ReelAction(Icons.Outlined.ChatBubbleOutline, "$commentCount", Color.White, onComments)
            ReelAction(Icons.AutoMirrored.Outlined.Send, "مشاركة", Color.White) {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, "${reel.author}: ${reel.caption}")
                }
                context.startActivity(Intent.createChooser(send, null))
            }
            ReelAction(
                icon = if (saved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                label = "حفظ",
                tint = Color.White,
                onClick = onSave,
            )
        }

        // معلومات الكاتب والوصف والموسيقى.
        Column(
            Modifier
                .align(Alignment.BottomStart)
                .navigationBarsPadding()
                .padding(start = 16.dp, end = 80.dp, bottom = 24.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RifaqAvatar(reel.author, size = 36.dp)
                Text(
                    reel.author,
                    modifier = Modifier.padding(horizontal = 10.dp),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                )
                if (!following) {
                    Text(
                        "متابعة",
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, Color.White, RoundedCornerShape(8.dp))
                            .clickable(onClick = onFollow)
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
            Text(
                reel.caption,
                modifier = Modifier.padding(top = 10.dp),
                color = Color.White,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
            )
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Filled.MusicNote,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(16.dp),
                )
                Text(
                    reel.music,
                    modifier = Modifier.padding(horizontal = 6.dp),
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun ReelAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(vertical = 8.dp)) {
        IconButton(onClick = onClick, modifier = Modifier.size(44.dp).clip(CircleShape)) {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(30.dp))
        }
        Text(label, color = Color.White, style = androidx.compose.material3.MaterialTheme.typography.bodyMedium)
    }
}
