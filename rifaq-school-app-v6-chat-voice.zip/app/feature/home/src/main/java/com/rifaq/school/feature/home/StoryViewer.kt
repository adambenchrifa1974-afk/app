package com.rifaq.school.feature.home

import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rifaq.school.core.common.model.SocialRepository
import com.rifaq.school.core.common.model.Story
import com.rifaq.school.core.designsystem.component.RifaqAvatar
import com.rifaq.school.core.designsystem.component.RifaqCover

private const val STORY_DURATION_MS = 5_000L
private val StoryEmojis = listOf("❤️", "😂", "😮", "😢", "🔥", "👏")

/**
 * عارض القصص بملء الشاشة بأسلوب إنستغرام:
 * شريط تقدم لكل قصة، نقرة على الجانبين للتنقل، الضغط المطوّل يوقف القصة مؤقتًا،
 * تفاعلات سريعة بالإيموجي، إعجاب، ورد نصي. القصص المشاهدة تُسجَّل في [SocialRepository].
 */
@Composable
internal fun StoryViewer(stories: List<Story>, startIndex: Int, onClose: () -> Unit) {
    var index by remember { mutableIntStateOf(startIndex) }
    var progress by remember { mutableFloatStateOf(0f) }
    var holding by remember { mutableStateOf(false) }
    var typing by remember { mutableStateOf(false) }
    var reply by remember { mutableStateOf("") }
    var liked by remember { mutableStateOf(false) }
    var reaction by remember { mutableStateOf<String?>(null) }
    val reactionScale = remember { Animatable(0f) }
    val paused by rememberUpdatedState(holding || typing)
    val context = LocalContext.current

    LaunchedEffect(index) {
        progress = 0f
        liked = false
        reply = ""
        SocialRepository.markStoryViewed(stories[index.coerceIn(0, stories.lastIndex)].id)
        var elapsed = 0L
        var last = withFrameMillis { it }
        while (elapsed < STORY_DURATION_MS) {
            val now = withFrameMillis { it }
            if (!paused) elapsed += now - last
            last = now
            progress = (elapsed.toFloat() / STORY_DURATION_MS).coerceAtMost(1f)
        }
        if (index < stories.lastIndex) index += 1 else onClose()
    }

    // الإيموجي الكبير الذي يظهر عند اختيار تفاعل.
    LaunchedEffect(reaction) {
        if (reaction != null) {
            reactionScale.snapTo(0f)
            reactionScale.animateTo(1f, spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessMedium))
            kotlinx.coroutines.delay(500)
            reactionScale.animateTo(0f, tween(200))
            reaction = null
        }
    }

    val story = stories[index.coerceIn(0, stories.lastIndex)]

    Box(Modifier.fillMaxSize().background(Color.Black).imePadding()) {
        RifaqCover(seed = story.id + 2, modifier = Modifier.fillMaxSize()) {
            Text(
                story.name,
                color = Color.White,
                fontSize = 44.sp,
                fontWeight = FontWeight.Bold,
            )
        }

        // مناطق اللمس: الجانب الأول (اليمين في RTL) للسابق، والثاني للتالي، والضغط المطوّل يوقف القصة.
        Row(Modifier.fillMaxSize()) {
            for (isNext in listOf(false, true)) {
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .pointerInput(isNext, stories.size) {
                            detectTapGestures(
                                onPress = {
                                    holding = true
                                    tryAwaitRelease()
                                    holding = false
                                },
                                onTap = {
                                    if (isNext) {
                                        if (index < stories.lastIndex) index += 1 else onClose()
                                    } else if (index > 0) {
                                        index -= 1
                                    }
                                },
                            )
                        },
                )
            }
        }

        Column(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                stories.forEachIndexed { i, _ ->
                    val fraction = when {
                        i < index -> 1f
                        i == index -> progress
                        else -> 0f
                    }
                    Box(
                        Modifier
                            .weight(1f)
                            .height(3.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.35f)),
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth(fraction)
                                .fillMaxHeight()
                                .background(Color.White),
                        )
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(top = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RifaqAvatar(story.name, size = 36.dp)
                Text(
                    story.name,
                    modifier = Modifier.weight(1f).padding(horizontal = 10.dp),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                )
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.Close, contentDescription = "إغلاق", tint = Color.White)
                }
            }
        }

        reaction?.let { emoji ->
            Text(
                emoji,
                modifier = Modifier.align(Alignment.Center).scale(reactionScale.value),
                fontSize = 96.sp,
            )
        }

        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
        ) {
            if (typing) {
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    StoryEmojis.forEach { emoji ->
                        Text(
                            emoji,
                            modifier = Modifier
                                .pointerInput(emoji) { detectTapGestures { reaction = emoji } }
                                .padding(6.dp),
                            fontSize = 28.sp,
                        )
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = reply,
                    onValueChange = { reply = it },
                    modifier = Modifier.weight(1f).onFocusChanged { typing = it.isFocused },
                    placeholder = { Text("أرسل رسالة...", color = Color.White.copy(alpha = 0.85f)) },
                    singleLine = true,
                    shape = CircleShape,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = Color.White,
                        focusedContainerColor = Color.White.copy(alpha = 0.22f),
                        unfocusedContainerColor = Color.White.copy(alpha = 0.22f),
                        focusedBorderColor = Color.White.copy(alpha = 0.6f),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.35f),
                    ),
                )
                if (reply.isNotBlank()) {
                    IconButton(
                        onClick = {
                            Toast.makeText(context, "تم إرسال ردك إلى ${story.name}", Toast.LENGTH_SHORT).show()
                            reply = ""
                        },
                    ) { Icon(Icons.AutoMirrored.Outlined.Send, contentDescription = "إرسال", tint = Color.White) }
                } else {
                    IconButton(onClick = { liked = !liked }) {
                        Icon(
                            if (liked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "إعجاب",
                            tint = if (liked) Color(0xFFFF3B5C) else Color.White,
                        )
                    }
                }
            }
        }
    }
}
