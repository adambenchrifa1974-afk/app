package com.rifaq.school.feature.home

import org.junit.Assert.assertTrue
import org.junit.Test

class HomeViewModelTest {
    @Test
    fun initialState_hasStoriesAndPosts() {
        val vm = HomeViewModel()
        assertTrue(vm.stories.isNotEmpty())
        assertTrue(vm.posts.value.isNotEmpty())
    }
}
