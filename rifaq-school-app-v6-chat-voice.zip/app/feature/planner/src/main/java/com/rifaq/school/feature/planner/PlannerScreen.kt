package com.rifaq.school.feature.planner

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rifaq.school.core.common.planner.StudyTask
import com.rifaq.school.core.common.planner.TaskSections
import com.rifaq.school.core.common.planner.TaskType
import com.rifaq.school.core.common.planner.dueAtFor
import com.rifaq.school.core.common.planner.groupTasks
import com.rifaq.school.core.designsystem.component.RifaqHeader
import com.rifaq.school.core.designsystem.component.RifaqPrimaryButton
import com.rifaq.school.core.designsystem.component.RifaqTextField
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Danger = Color(0xFFE5484D)

@Composable
fun PlannerRoute(onBack: () -> Unit, viewModel: PlannerViewModel = viewModel()) {
    val tasks by viewModel.tasks.collectAsStateWithLifecycle()
    var showAdd by rememberSaveable { mutableStateOf(false) }
    val sections = remember(tasks) { groupTasks(tasks, System.currentTimeMillis()) }
    val scheme = MaterialTheme.colorScheme

    Box(Modifier.fillMaxSize().background(scheme.background)) {
        Column(Modifier.fillMaxSize()) {
            RifaqHeader(
                title = "الواجبات والمراجعة",
                leading = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
            )
            if (tasks.isEmpty()) {
                Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text("لا توجد مهام بعد", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "اضغط على زر + لإضافة واجب أو امتحان أو حصة مراجعة.",
                        modifier = Modifier.padding(top = 8.dp),
                        style = MaterialTheme.typography.bodyLarge,
                        color = scheme.onSurfaceVariant,
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 100.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    item { Summary(sections) }
                    taskSection("متأخرة", sections.overdue, true, viewModel::toggle, viewModel::delete)
                    taskSection("قادمة", sections.upcoming, false, viewModel::toggle, viewModel::delete)
                    taskSection("منجزة", sections.done, false, viewModel::toggle, viewModel::delete)
                }
            }
        }
        FloatingActionButton(
            onClick = { showAdd = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(20.dp),
            containerColor = scheme.primary,
            contentColor = scheme.onPrimary,
        ) { Icon(Icons.Filled.Add, contentDescription = "إضافة مهمة") }
    }

    if (showAdd) {
        AddTaskSheet(
            onDismiss = { showAdd = false },
            onSave = { title, subject, type, dueAt ->
                viewModel.add(title, subject, type, dueAt)
                showAdd = false
            },
        )
    }
}

@Composable
private fun Summary(sections: TaskSections) {
    val scheme = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        SummaryBox("متأخرة", sections.overdue.size, Danger, Modifier.weight(1f))
        SummaryBox("قادمة", sections.upcoming.size, scheme.primary, Modifier.weight(1f))
        SummaryBox("منجزة", sections.done.size, scheme.onSurfaceVariant, Modifier.weight(1f))
    }
}

@Composable
private fun SummaryBox(label: String, count: Int, color: Color, modifier: Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("$count", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = color)
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

private fun LazyListScope.taskSection(
    title: String,
    list: List<StudyTask>,
    danger: Boolean,
    onToggle: (Long) -> Unit,
    onDelete: (Long) -> Unit,
) {
    if (list.isEmpty()) return
    item(key = "header_$title") {
        Text(
            title,
            modifier = Modifier.padding(top = 8.dp),
            style = MaterialTheme.typography.titleMedium,
            color = if (danger) Danger else MaterialTheme.colorScheme.onBackground,
        )
    }
    items(list, key = { it.id }) { task ->
        TaskRow(task, danger, onToggle = { onToggle(task.id) }, onDelete = { onDelete(task.id) })
    }
}

private fun formatDue(timestamp: Long): String =
    SimpleDateFormat("EEEE d MMMM", Locale.forLanguageTag("ar")).format(Date(timestamp))

@Composable
private fun TaskRow(task: StudyTask, overdue: Boolean, onToggle: () -> Unit, onDelete: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(scheme.surfaceVariant)
            .clickable(onClick = onToggle)
            .padding(start = 8.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            if (task.done) Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
            contentDescription = if (task.done) "منجزة" else "غير منجزة",
            tint = if (task.done) scheme.primary else scheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
        Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
            Text(
                task.title,
                style = MaterialTheme.typography.titleMedium,
                textDecoration = if (task.done) TextDecoration.LineThrough else TextDecoration.None,
                color = if (task.done) scheme.onSurfaceVariant else scheme.onSurface,
            )
            val subject = if (task.subject.isBlank()) "" else task.subject + " • "
            Text(
                subject + task.type.label + " • " + formatDue(task.dueAt),
                style = MaterialTheme.typography.bodyMedium,
                color = if (overdue) Danger else scheme.onSurfaceVariant,
            )
        }
        IconButton(onClick = onDelete) {
            Icon(Icons.Outlined.Delete, contentDescription = "حذف", tint = scheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ChoiceChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Text(
        text,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) scheme.primary else scheme.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        color = if (selected) scheme.onPrimary else scheme.onSurface,
        style = MaterialTheme.typography.labelLarge,
    )
}

private val DueOptions = listOf("اليوم" to 0, "غدًا" to 1, "بعد 3 أيام" to 3, "الأسبوع القادم" to 7)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddTaskSheet(
    onDismiss: () -> Unit,
    onSave: (String, String, TaskType, Long) -> Unit,
) {
    var title by rememberSaveable { mutableStateOf("") }
    var subject by rememberSaveable { mutableStateOf("") }
    var typeIndex by rememberSaveable { mutableIntStateOf(0) }
    var dueIndex by rememberSaveable { mutableIntStateOf(1) }
    val types = TaskType.entries

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .imePadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("مهمة جديدة", style = MaterialTheme.typography.titleMedium)
            RifaqTextField(title, { title = it }, "العنوان (مثال: تمارين الدرس 4)")
            RifaqTextField(subject, { subject = it }, "المادة (اختياري)")
            Text("النوع", style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                types.forEachIndexed { i, type ->
                    ChoiceChip(type.label, selected = i == typeIndex) { typeIndex = i }
                }
            }
            Text("الموعد", style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DueOptions.forEachIndexed { i, option ->
                    ChoiceChip(option.first, selected = i == dueIndex) { dueIndex = i }
                }
            }
            Spacer(Modifier.height(4.dp))
            RifaqPrimaryButton(
                text = "حفظ",
                onClick = {
                    if (title.isNotBlank()) {
                        onSave(
                            title,
                            subject,
                            types[typeIndex],
                            dueAtFor(DueOptions[dueIndex].second, System.currentTimeMillis()),
                        )
                    }
                },
            )
            Spacer(Modifier.height(8.dp))
        }
    }
}
