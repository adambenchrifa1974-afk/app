package com.rifaq.school.feature.planner

import androidx.lifecycle.ViewModel
import com.rifaq.school.core.common.planner.PlannerRepository
import com.rifaq.school.core.common.planner.StudyTask
import com.rifaq.school.core.common.planner.TaskType
import kotlinx.coroutines.flow.StateFlow

class PlannerViewModel : ViewModel() {
    val tasks: StateFlow<List<StudyTask>> = PlannerRepository.tasks

    fun add(title: String, subject: String, type: TaskType, dueAt: Long) =
        PlannerRepository.add(title, subject, type, dueAt)

    fun toggle(id: Long) = PlannerRepository.toggle(id)
    fun delete(id: Long) = PlannerRepository.delete(id)
}
