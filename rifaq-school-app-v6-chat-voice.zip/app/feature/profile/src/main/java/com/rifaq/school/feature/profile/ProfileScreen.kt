package com.rifaq.school.feature.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.DynamicFeed
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rifaq.school.core.common.gamification.Badges
import com.rifaq.school.core.common.gamification.GamificationRepository
import com.rifaq.school.core.common.gamification.GamificationStats
import com.rifaq.school.core.common.model.FeedRepository
import com.rifaq.school.core.common.model.Post
import com.rifaq.school.core.common.model.ProfileRepository
import com.rifaq.school.core.common.model.SocialRepository
import com.rifaq.school.core.common.model.UserProfile
import com.rifaq.school.core.common.planner.PlannerRepository
import com.rifaq.school.core.common.planner.StudyTask
import com.rifaq.school.core.designsystem.component.RifaqAvatar
import com.rifaq.school.core.designsystem.component.RifaqCover
import com.rifaq.school.core.designsystem.component.RifaqHeader
import com.rifaq.school.core.designsystem.component.RifaqPrimaryButton
import com.rifaq.school.core.designsystem.component.RifaqTextField
import com.rifaq.school.core.designsystem.theme.BottomBarSpace
import com.rifaq.school.core.designsystem.theme.StoryRingGradient
import kotlinx.coroutines.flow.StateFlow

class ProfileViewModel : ViewModel() {
    val profile: StateFlow<UserProfile> = ProfileRepository.profile
    val stats: StateFlow<GamificationStats> = GamificationRepository.stats
    val tasks: StateFlow<List<StudyTask>> = PlannerRepository.tasks
    val posts: StateFlow<List<Post>> = FeedRepository.posts
    val followed: StateFlow<Set<String>> = SocialRepository.followed

    fun updateProfile(name: String, role: String) = ProfileRepository.update(name, role)
}

@Composable
fun ProfileRoute(
    onOpenSettings: () -> Unit,
    onOpenChallenges: () -> Unit,
    viewModel: ProfileViewModel = viewModel(),
) {
    val profile by viewModel.profile.collectAsStateWithLifecycle()
    val stats by viewModel.stats.collectAsStateWithLifecycle()
    val tasks by viewModel.tasks.collectAsStateWithLifecycle()
    val posts by viewModel.posts.collectAsStateWithLifecycle()
    val followed by viewModel.followed.collectAsStateWithLifecycle()
    ProfileScreen(
        profile = profile.copy(following = profile.following + SocialRepository.followingDelta(followed)),
        stats = stats,
        tasksDone = tasks.count { it.done },
        myPosts = posts.filter { it.mine },
        savedPosts = posts.filter { it.saved },
        onOpenSettings = onOpenSettings,
        onOpenChallenges = onOpenChallenges,
        onSaveProfile = viewModel::updateProfile,
    )
}

@Composable
fun ProfileScreen(
    profile: UserProfile,
    stats: GamificationStats,
    tasksDone: Int,
    myPosts: List<Post>,
    savedPosts: List<Post>,
    onOpenSettings: () -> Unit,
    onOpenChallenges: () -> Unit,
    onSaveProfile: (String, String) -> Unit,
) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var editing by rememberSaveable { mutableStateOf(false) }
    val earned = Badges.earnedIds(stats, tasksDone)

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        RifaqHeader(
            title = "حسابي",
            trailing = {
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Outlined.Settings, contentDescription = "الإعدادات")
                }
            },
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            contentPadding = PaddingValues(bottom = BottomBarSpace),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                ProfileTop(
                    profile = profile,
                    stats = stats,
                    badgeCount = earned.size,
                    onEdit = { editing = true },
                    onOpenChallenges = onOpenChallenges,
                )
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                ProfileTabs(selected = tab, onSelect = { tab = it })
            }
            if (tab == 0) {
                items(Badges.all) { badge ->
                    val isEarned = badge.id in earned
                    Column(
                        Modifier
                            .aspectRatio(1f)
                            .background(
                                if (isEarned) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                                else MaterialTheme.colorScheme.surfaceVariant,
                            )
                            .padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Icon(
                            if (isEarned) Icons.Outlined.EmojiEvents else Icons.Outlined.Lock,
                            contentDescription = null,
                            tint = if (isEarned) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(30.dp),
                        )
                        Text(
                            badge.title,
                            modifier = Modifier.padding(top = 6.dp),
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            color = if (isEarned) MaterialTheme.colorScheme.onSurface
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            } else {
                val shown = if (tab == 1) myPosts else savedPosts
                if (shown.isEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text(
                            if (tab == 1) {
                                "لم تنشر شيئًا بعد. اضغط + في الرئيسية لإنشاء منشور."
                            } else {
                                "لا توجد منشورات محفوظة. اضغط على أيقونة الحفظ في أي منشور."
                            },
                            modifier = Modifier.fillMaxWidth().padding(32.dp),
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                } else {
                    items(shown, key = { it.id }) { post ->
                        RifaqCover(seed = post.cover ?: post.id.hashCode().let { if (it < 0) -it else it }, modifier = Modifier.aspectRatio(1f)) {
                            Text(
                                post.text,
                                modifier = Modifier.padding(8.dp),
                                color = Color.White,
                                fontSize = 12.sp,
                                maxLines = 4,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                }
            }
        }
    }

    if (editing) {
        EditProfileSheet(
            profile = profile,
            onDismiss = { editing = false },
            onSave = { name, role ->
                onSaveProfile(name, role)
                editing = false
            },
        )
    }
}

@Composable
private fun ProfileTop(
    profile: UserProfile,
    stats: GamificationStats,
    badgeCount: Int,
    onEdit: () -> Unit,
    onOpenChallenges: () -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(92.dp).border(3.dp, Brush.linearGradient(StoryRingGradient), CircleShape),
                contentAlignment = Alignment.Center,
            ) { RifaqAvatar(profile.name, size = 80.dp) }
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat("نقاط الخبرة", stats.xp)
                Stat("المستوى", stats.level)
                Stat("الشارات", badgeCount)
            }
        }
        Text(
            profile.name,
            modifier = Modifier.padding(top = 12.dp),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
        )
        if (profile.role.isNotBlank()) {
            Text(
                profile.role,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Row(
            Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            ProfileButton("تعديل الملف الشخصي", Modifier.weight(1f), onEdit)
            ProfileButton("التحديات", Modifier.weight(1f), onOpenChallenges)
        }
    }
}

@Composable
private fun ProfileButton(text: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .height(36.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
private fun Stat(label: String, value: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("$value", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun ProfileTabs(selected: Int, onSelect: (Int) -> Unit) {
    Column {
        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
        Row(Modifier.fillMaxWidth()) {
            TabIcon(Icons.Outlined.EmojiEvents, "الشارات", selected == 0, Modifier.weight(1f)) { onSelect(0) }
            TabIcon(Icons.Outlined.DynamicFeed, "منشوراتي", selected == 1, Modifier.weight(1f)) { onSelect(1) }
            TabIcon(Icons.Outlined.BookmarkBorder, "المحفوظات", selected == 2, Modifier.weight(1f)) { onSelect(2) }
        }
    }
}

@Composable
private fun TabIcon(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    Box(
        modifier.height(46.dp).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon, contentDescription = label,
            tint = if (selected) MaterialTheme.colorScheme.onBackground
            else MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (selected) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(2.dp)
                    .background(MaterialTheme.colorScheme.onBackground),
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditProfileSheet(
    profile: UserProfile,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit,
) {
    var name by rememberSaveable { mutableStateOf(profile.name) }
    var role by rememberSaveable { mutableStateOf(profile.role) }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .imePadding()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("تعديل الملف الشخصي", style = MaterialTheme.typography.titleMedium)
            RifaqTextField(name, { name = it }, "الاسم")
            RifaqTextField(role, { role = it }, "الصف والمؤسسة (مثال: طالب في ثانوية ابن رشد)")
            RifaqPrimaryButton("حفظ", onClick = { onSave(name, role) })
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
internal fun MenuDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(horizontal = 16.dp),
        color = MaterialTheme.colorScheme.outline,
    )
}
