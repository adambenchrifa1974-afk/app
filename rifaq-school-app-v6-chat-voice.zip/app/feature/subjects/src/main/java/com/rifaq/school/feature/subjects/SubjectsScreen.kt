package com.rifaq.school.feature.subjects

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rifaq.school.core.common.model.Lesson
import com.rifaq.school.core.common.model.SchoolData
import com.rifaq.school.core.common.model.Subject
import com.rifaq.school.core.designsystem.component.RifaqCover
import com.rifaq.school.core.designsystem.component.RifaqHeader
import com.rifaq.school.core.designsystem.theme.BottomBarSpace

/** قائمة المواد: لكل مادة بطاقة تفتح دروسها المنظمة حسب الوحدات. */
@Composable
fun SubjectsRoute(
    onOpenSubject: (String) -> Unit,
    viewModel: SubjectsViewModel = viewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        RifaqHeader(title = "المواد")
        LevelChips(state.levelId, viewModel::selectLevel)
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 12.dp + BottomBarSpace),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(SchoolData.subjects, key = { it.id }) { subject ->
                val count = SchoolData.lessonsFor(subject.id, state.levelId).size
                SubjectCard(subject, count, onClick = { onOpenSubject(subject.id) })
            }
        }
    }
}

@Composable
private fun LevelChips(selected: String, onSelect: (String) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(SchoolData.levels, key = { it.id }) { level ->
            FilterChip(selected == level.id, onClick = { onSelect(level.id) }, label = { Text(level.name) })
        }
    }
}

@Composable
private fun SubjectCard(subject: Subject, lessons: Int, onClick: () -> Unit) {
    Card(
        modifier = Modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Column {
            RifaqCover(seed = SchoolData.subjects.indexOf(subject), modifier = Modifier.fillMaxWidth().height(88.dp)) {
                Text(subject.symbol, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.padding(10.dp)) {
                Text(subject.name, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                Text(
                    subject.teacher,
                    style = MaterialTheme.typography.bodyMedium,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
                Text(
                    if (lessons == 0) "لا دروس بعد" else "$lessons دروس",
                    style = MaterialTheme.typography.bodyMedium,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        }
    }
}

/** دروس مادة واحدة، مرتبة ومجمّعة حسب الوحدة، مع شريط تقدّم وعلامة «تمت المراجعة». */
@Composable
fun SubjectDetailRoute(
    subjectId: String,
    onBack: () -> Unit,
    viewModel: SubjectsViewModel = viewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val subject = SchoolData.subjects.firstOrNull { it.id == subjectId }
    val lessons = SchoolData.lessonsFor(subjectId, state.levelId)
    val done = lessons.count { it.id in state.doneIds }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        RifaqHeader(
            title = subject?.name ?: "المادة",
            leading = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                }
            },
        )
        LevelChips(state.levelId, viewModel::selectLevel)
        if (lessons.isNotEmpty()) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text(
                    "أنجزت $done من ${lessons.size}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { done / lessons.size.toFloat() },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                )
            }
        }
        if (lessons.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("لم يُنشر أي درس في هذا المستوى بعد", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            val byUnit = lessons.groupBy { it.unit }
            LazyColumn(contentPadding = PaddingValues(bottom = BottomBarSpace)) {
                byUnit.forEach { (unit, unitLessons) ->
                    item(key = "unit-$unit") {
                        Text(
                            unit,
                            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 6.dp),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                    items(unitLessons, key = { it.id }) { lesson ->
                        LessonRow(lesson, lesson.id in state.doneIds) { viewModel.toggleDone(lesson.id) }
                    }
                }
            }
        }
    }
}

@Composable
private fun LessonRow(lesson: Lesson, done: Boolean, onToggle: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            if (done) Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
            contentDescription = if (done) "تمت المراجعة" else "لم تُراجع",
            tint = if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(26.dp),
        )
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(lesson.title, style = MaterialTheme.typography.bodyLarge)
            Text(
                "${lesson.teacher} • ${lesson.date}",
                style = MaterialTheme.typography.bodyMedium,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Text(
            lesson.type.label,
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(horizontal = 10.dp, vertical = 4.dp),
            fontSize = 12.sp,
        )
    }
}
