package com.rifaq.school.feature.subjects

import androidx.lifecycle.ViewModel
import com.rifaq.school.core.common.model.SchoolData
import com.rifaq.school.core.common.storage.LocalStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

private const val DONE_KEY = "done_lessons"
private const val LEVEL_KEY = "subjects_level"

data class SubjectsUiState(
    val levelId: String,
    /** معرّفات الدروس التي علّمها الطالب «تمت المراجعة»؛ محفوظة على الجهاز. */
    val doneIds: Set<Int>,
)

class SubjectsViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(
        SubjectsUiState(
            levelId = LocalStore.getString(LEVEL_KEY, SchoolData.levels.first().id)
                .takeIf { id -> SchoolData.levels.any { it.id == id } } ?: SchoolData.levels.first().id,
            doneIds = LocalStore.getString(DONE_KEY, "")
                .split(',').mapNotNull { it.toIntOrNull() }.toSet(),
        ),
    )
    val uiState: StateFlow<SubjectsUiState> = _uiState.asStateFlow()

    fun selectLevel(id: String) {
        LocalStore.putString(LEVEL_KEY, id)
        _uiState.update { it.copy(levelId = id) }
    }

    fun toggleDone(lessonId: Int) {
        _uiState.update { state ->
            val next = if (lessonId in state.doneIds) state.doneIds - lessonId else state.doneIds + lessonId
            LocalStore.putString(DONE_KEY, next.joinToString(","))
            state.copy(doneIds = next)
        }
    }
}
