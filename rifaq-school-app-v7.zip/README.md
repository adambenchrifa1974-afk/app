# رفاق المدرسة (Rifaq School)

تطبيق Android أصلي لمجتمع مدرسي. اللغة الأساسية: العربية الفصحى مع دعم RTL.

## التقنيات
Kotlin · Jetpack Compose · Material 3 · MVVM · Coroutines/Flow · Navigation Compose · Gradle Kotlin DSL + Version Catalog · minSdk 26.

## البنية الحالية
```
app/                     MainActivity + NavHost + شريط التنقل السفلي
core/common              النماذج (Models) وبيانات العرض التجريبية (DemoData) وUiState
core/designsystem        الثيم (فاتح/داكن) والمكوّنات المشتركة (ترويسة، حقول، أزرار، بطاقة منشور، شعار)
core/navigation          مسارات التنقل
feature/authentication   شاشة الترحيب وتسجيل الدخول
feature/home             الرئيسية: القصص + منشورات
feature/posts            استكشاف (شبكة منشورات بأسلوب Xiaohongshu مع تصنيفات وبحث)
feature/chat             المحادثات (قائمة بأسلوب WeChat مع بحث)
feature/groups           المجموعات حسب القسم والمستوى (تصفية بالرقائق) مع زر انضمام
feature/profile          الملف الشخصي (تعديل الاسم والصف، النقاط، الشارات، منشوراتي) والإعدادات
feature/subjects          المواد: لكل مادة دروسها منظمة حسب الوحدة والمستوى مع تتبع المراجعة
feature/planner          الواجبات والمراجعة: إضافة/إنجاز/حذف مهام، محفوظة على الجهاز
feature/challenges       اختبارات المواد وتحدي اليوم، نقاط الخبرة والمستويات والشارات
```
**تعمل فعليًا على الجهاز (بدون خادم):** المخطط، الاختبارات والنقاط والشارات، تعديل الملف الشخصي، الوضع الليلي المحفوظ، تسجيل الخروج.
**المزايا:** شريط تنقل عائم بتمويه زجاجي حقيقي (Android 12+)، انتقالات نابضة، قصص بشريط تقدم، تعليقات في ورقة سفلية،
محادثة بفقاعات، إنشاء منشور، مشاركة عبر قائمة النظام، ووضع ليلي.
**حالة البيانات:** الواجهات تعمل ببيانات تجريبية في الذاكرة (`DemoData`/`FeedRepository`) وتُفقد عند إغلاق التطبيق.
تسجيل الدخول يتحقق من المدخلات محليًا فقط ولا يوجد خادم أو مصادقة حقيقية، والمحادثات لا تصل لأحد، وأزرار Google ونسيت كلمة المرور وإنشاء حساب تعرض «غير متاحة بعد».
الصور الحالية أغلفة ملوّنة إلى حين ربط الصور الفعلية. وحدات `network` و`database` وفعاليات/مكالمات/إشراف ستُضاف لاحقًا.

## البناء
المتطلبات: Android Studio (إصدار حديث يدعم AGP 8.7) وJDK 17 وAndroid SDK 35.

1. افتح المشروع في Android Studio ودَعه يزامن Gradle (سيُنشئ ملف `local.properties` تلقائيًا).
2. أو من سطر الأوامر، بعد توليد الـ wrapper لمرة واحدة بوجود Gradle 8.10.2:
   ```
   gradle wrapper --gradle-version 8.10.2
   ./gradlew :app:assembleDebug
   ./gradlew test
   ```

## ملاحظات
- لم تُضَف Firebase أو WebRTC بعد، وستُضاف بعد استقرار البنية الأساسية.
- لا توجد أي بيانات اعتماد في الكود؛ ملفات المفاتيح (`*.jks`, `*.keystore`) مستثناة في `.gitignore`.
- الخط الحالي هو خط النظام؛ يمكن تضمين خط عربي لاحقًا في `Type.kt`.


## Firebase
- `app/google-services.json` يخص مشروعك؛ مفتاح Firebase ليس سرًّا لكن قيّده بحزمة التطبيق `com.rifaq.school` من Google Cloud، ولا تجعل قواعد Firestore مفتوحة.
- فعّل في الـ console: Authentication ← E-mail/Mot de passe، وFirestore Database.
- انسخ محتوى `firestore.rules` إلى Firestore ← Règles ثم انشر.
- المنشورات والتعليقات والإعجابات والحفظ تُخزَّن في `posts` و`posts/{id}/comments`. الريلز والمحادثات والمجموعات ما زالت تجريبية.

## البناء على GitHub (بدون كمبيوتر)
- كل push إلى `main` يشغّل Actions ويبني `app-debug.apk`: Actions ← آخر تشغيل ← Artifacts ← `rifaq-school-debug-apk`.
- يمكن تشغيله يدويًا من Actions ← Build APK ← Run workflow.
- ملف `app/google-services.json` يجب أن يكون في المستودع أو في سر باسم `GOOGLE_SERVICES_JSON` (محتوى الملف كما هو).

## المحادثات والرسائل الصوتية
- محادثات فردية حقيقية: `chats/{uidA_uidB}` مع `messages` و`audio`.
- الرسائل الصوتية AAC أحادية 24 كيلوبت/ث، حد أقصى 60 ثانية، تُخزَّن كنص base64 داخل Firestore (لا تحتاج Firebase Storage ولا خطة Blaze).
- نشر `firestore.rules` مطلوب لعمل المحادثات.

## إن فشل البناء على GitHub
- افتح التشغيل الفاشل ← اضغط على الخطوة الحمراء ← انسخ آخر 30 سطرًا من الرسالة.
- ملف `.github/workflows/build.yml` يجب أن يكون في **جذر** المستودع، والـ workflow يجد مجلد المشروع بنفسه.
