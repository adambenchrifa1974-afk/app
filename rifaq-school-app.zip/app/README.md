# رفاق المدرسة (Rifaq School)

تطبيق Android أصلي لمجتمع مدرسي. اللغة الأساسية: العربية الفصحى مع دعم RTL.

## التقنيات
Kotlin · Jetpack Compose · Material 3 · MVVM · Coroutines/Flow · Navigation Compose · Gradle Kotlin DSL + Version Catalog · minSdk 26.

## البنية الحالية
```
app/                     MainActivity + NavHost + شريط التنقل السفلي
core/common              النماذج (Models) وبيانات العرض التجريبية (DemoData) وUiState
core/designsystem        الثيم (فاتح/داكن) والمكوّنات المشتركة (ترويسة، حقول، أزرار، بطاقة منشور، شعار)
core/navigation          مسارات التنقل
feature/authentication   شاشة الترحيب وتسجيل الدخول
feature/home             الرئيسية: القصص + منشورات
feature/posts            المنشورات
feature/chat             المحادثات مع بحث
feature/groups           المجموعات
feature/profile          الملف الشخصي والإعدادات (الوضع الليلي يعمل)
```
**حالة الشاشات:** الواجهات مبنية على تصميم المشروع وتعمل ببيانات تجريبية (`DemoData`).
تسجيل الدخول يتحقق من المدخلات محليًا فقط ولا يوجد خادم أو مصادقة حقيقية، وأزرار Google ونسيت كلمة المرور وإنشاء حساب تعرض رسالة «غير متاحة بعد».
الصور الحالية مؤقتة (حروف أولى وخلفيات متدرجة) إلى حين ربط الصور الفعلية.
وحدات `network` و`database` وفعاليات/مكالمات/إشراف ستُضاف لاحقًا.

## البناء
المتطلبات: Android Studio (إصدار حديث يدعم AGP 8.7) وJDK 17 وAndroid SDK 35.

1. افتح المشروع في Android Studio ودَعه يزامن Gradle (سيُنشئ ملف `local.properties` تلقائيًا).
2. أو من سطر الأوامر، بعد توليد الـ wrapper لمرة واحدة بوجود Gradle 8.10.2:
   ```
   gradle wrapper --gradle-version 8.10.2
   ./gradlew :app:assembleDebug
   ./gradlew test
   ```

## ملاحظات
- لم تُضَف Firebase أو WebRTC بعد، وستُضاف بعد استقرار البنية الأساسية.
- لا توجد أي بيانات اعتماد في الكود؛ `google-services.json` وملفات المفاتيح مستثناة في `.gitignore`.
- الخط الحالي هو خط النظام؛ يمكن تضمين خط عربي لاحقًا في `Type.kt`.
