package com.rifaq.school

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** حالة على مستوى التطبيق. null = اتباع إعداد النظام. (لا يُحفظ بعد إغلاق التطبيق.) */
class AppViewModel : ViewModel() {
    private val _darkOverride = MutableStateFlow<Boolean?>(null)
    val darkOverride: StateFlow<Boolean?> = _darkOverride.asStateFlow()

    fun setDarkMode(enabled: Boolean) {
        _darkOverride.value = enabled
    }
}
