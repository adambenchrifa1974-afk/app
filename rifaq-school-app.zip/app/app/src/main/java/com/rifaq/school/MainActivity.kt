package com.rifaq.school

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rifaq.school.core.common.gamification.GamificationRepository
import com.rifaq.school.core.common.model.ProfileRepository
import com.rifaq.school.core.common.planner.PlannerRepository
import com.rifaq.school.core.common.storage.LocalStore
import com.rifaq.school.core.designsystem.theme.RifaqTheme

class MainActivity : ComponentActivity() {
    private val appViewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LocalStore.init(applicationContext)
        ProfileRepository.load()
        PlannerRepository.load()
        GamificationRepository.load()
        enableEdgeToEdge()
        setContent {
            val override by appViewModel.darkOverride.collectAsStateWithLifecycle()
            val dark = override ?: isSystemInDarkTheme()
            RifaqTheme(darkTheme = dark) {
                RifaqApp(darkMode = dark, onDarkModeChange = appViewModel::setDarkMode)
            }
        }
    }
}
