package com.rifaq.school

import android.graphics.Color as AndroidColor
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.DynamicFeed
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.DynamicFeed
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.rifaq.school.core.common.model.DemoData
import com.rifaq.school.core.navigation.RifaqDestination
import com.rifaq.school.feature.authentication.LoginScreen
import com.rifaq.school.feature.authentication.WelcomeScreen
import com.rifaq.school.feature.chat.ChatRoute
import com.rifaq.school.feature.groups.GroupsRoute
import com.rifaq.school.feature.home.HomeRoute
import com.rifaq.school.feature.posts.PostsRoute
import com.rifaq.school.feature.profile.ProfileRoute
import com.rifaq.school.feature.profile.SettingsScreen

private data class TopLevelTab(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val selectedIcon: ImageVector,
)

// الترتيب هنا يبدأ من اليمين في الواجهة العربية (RTL).
private val TopLevelTabs = listOf(
    TopLevelTab(RifaqDestination.HOME, "الرئيسية", Icons.Outlined.Home, Icons.Filled.Home),
    TopLevelTab(RifaqDestination.CHATS, "المحادثات", Icons.Outlined.ChatBubbleOutline, Icons.Filled.ChatBubble),
    TopLevelTab(RifaqDestination.POSTS, "المنشورات", Icons.Outlined.DynamicFeed, Icons.Filled.DynamicFeed),
    TopLevelTab(RifaqDestination.GROUPS, "المجموعات", Icons.Outlined.Groups, Icons.Filled.Groups),
    TopLevelTab(RifaqDestination.PROFILE, "حسابي", Icons.Outlined.Person, Icons.Filled.Person),
)

@Composable
fun RifaqApp(darkMode: Boolean, onDarkModeChange: (Boolean) -> Unit) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val route = backStackEntry?.destination?.route
    val showBottomBar = TopLevelTabs.any { it.route == route }

    // الترويسات الآن بخلفية الشاشة، لذلك تتبع أيقونات النظام الوضع الفاتح/الداكن.
    val activity = LocalContext.current as? ComponentActivity
    LaunchedEffect(darkMode) {
        val style = if (darkMode) {
            SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        } else {
            SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
        }
        activity?.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (showBottomBar) {
                RifaqBottomBar(
                    route = route,
                    unreadChats = DemoData.chats.sumOf { it.unread },
                    onSelect = { target ->
                        navController.navigate(target) {
                            popUpTo(RifaqDestination.HOME) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                )
            }
        },
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = RifaqDestination.WELCOME,
            modifier = Modifier.padding(padding),
        ) {
            composable(RifaqDestination.WELCOME) {
                WelcomeScreen(
                    onStart = { navController.navigate(RifaqDestination.LOGIN) },
                    onLoginClick = { navController.navigate(RifaqDestination.LOGIN) },
                )
            }
            composable(RifaqDestination.LOGIN) {
                LoginScreen(
                    onLoginSuccess = {
                        navController.navigate(RifaqDestination.HOME) {
                            popUpTo(RifaqDestination.WELCOME) { inclusive = true }
                        }
                    },
                )
            }
            composable(RifaqDestination.HOME) { HomeRoute() }
            composable(RifaqDestination.CHATS) { ChatRoute() }
            composable(RifaqDestination.POSTS) { PostsRoute() }
            composable(RifaqDestination.GROUPS) { GroupsRoute() }
            composable(RifaqDestination.PROFILE) {
                ProfileRoute(onOpenSettings = { navController.navigate(RifaqDestination.SETTINGS) })
            }
            composable(RifaqDestination.SETTINGS) {
                SettingsScreen(
                    darkMode = darkMode,
                    onDarkModeChange = onDarkModeChange,
                    onBack = { navController.popBackStack() },
                )
            }
        }
    }
}

/** شريط تنقل بأيقونات فقط على طريقة إنستغرام، مع شارة للمحادثات غير المقروءة. */
@Composable
private fun RifaqBottomBar(route: String?, unreadChats: Int, onSelect: (String) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Column(Modifier.background(scheme.background)) {
        HorizontalDivider(color = scheme.outline)
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().height(54.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TopLevelTabs.forEach { tab ->
                val selected = tab.route == route
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable { onSelect(tab.route) },
                    contentAlignment = Alignment.Center,
                ) {
                    val icon = @Composable {
                        Icon(
                            if (selected) tab.selectedIcon else tab.icon,
                            contentDescription = tab.label,
                            tint = if (selected) scheme.onBackground else scheme.onSurfaceVariant,
                            modifier = Modifier.size(26.dp),
                        )
                    }
                    if (tab.route == RifaqDestination.CHATS && unreadChats > 0) {
                        BadgedBox(badge = { Badge { Text("$unreadChats") } }) { icon() }
                    } else {
                        icon()
                    }
                }
            }
        }
    }
}
