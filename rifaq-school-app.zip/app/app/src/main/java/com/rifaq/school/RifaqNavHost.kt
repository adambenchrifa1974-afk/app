package com.rifaq.school

import android.graphics.Color as AndroidColor
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.DynamicFeed
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.DynamicFeed
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.rifaq.school.core.navigation.RifaqDestination
import com.rifaq.school.feature.authentication.LoginScreen
import com.rifaq.school.feature.authentication.WelcomeScreen
import com.rifaq.school.feature.chat.ChatRoute
import com.rifaq.school.feature.groups.GroupsRoute
import com.rifaq.school.feature.home.HomeRoute
import com.rifaq.school.feature.posts.PostsRoute
import com.rifaq.school.feature.profile.ProfileRoute
import com.rifaq.school.feature.profile.SettingsScreen

private data class TopLevelTab(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val selectedIcon: ImageVector,
)

// الترتيب هنا يبدأ من اليمين في الواجهة العربية (RTL).
private val TopLevelTabs = listOf(
    TopLevelTab(RifaqDestination.HOME, "الرئيسية", Icons.Outlined.Home, Icons.Filled.Home),
    TopLevelTab(RifaqDestination.CHATS, "المحادثات", Icons.Outlined.ChatBubbleOutline, Icons.Filled.ChatBubble),
    TopLevelTab(RifaqDestination.POSTS, "المنشورات", Icons.Outlined.DynamicFeed, Icons.Filled.DynamicFeed),
    TopLevelTab(RifaqDestination.GROUPS, "المجموعات", Icons.Outlined.Groups, Icons.Filled.Groups),
    TopLevelTab(RifaqDestination.PROFILE, "حسابي", Icons.Outlined.Person, Icons.Filled.Person),
)

@Composable
fun RifaqApp(darkMode: Boolean, onDarkModeChange: (Boolean) -> Unit) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val route = backStackEntry?.destination?.route
    val showBottomBar = TopLevelTabs.any { it.route == route }
    val hasGreenHeader = showBottomBar || route == RifaqDestination.SETTINGS

    // أيقونات شريط الحالة: فاتحة فوق الترويسة الخضراء، وحسب الثيم في شاشتي الترحيب والدخول.
    val activity = LocalContext.current as? ComponentActivity
    LaunchedEffect(hasGreenHeader, darkMode) {
        val lightIcons = hasGreenHeader || darkMode
        activity?.enableEdgeToEdge(
            statusBarStyle = if (lightIcons) {
                SystemBarStyle.dark(AndroidColor.TRANSPARENT)
            } else {
                SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
            },
            navigationBarStyle = if (darkMode) {
                SystemBarStyle.dark(AndroidColor.TRANSPARENT)
            } else {
                SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
            },
        )
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    TopLevelTabs.forEach { tab ->
                        val selected = tab.route == route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(tab.route) {
                                    popUpTo(RifaqDestination.HOME) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(if (selected) tab.selectedIcon else tab.icon, contentDescription = null)
                            },
                            label = { Text(tab.label) },
                        )
                    }
                }
            }
        },
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = RifaqDestination.WELCOME,
            modifier = Modifier.padding(padding),
        ) {
            composable(RifaqDestination.WELCOME) {
                WelcomeScreen(
                    onStart = { navController.navigate(RifaqDestination.LOGIN) },
                    onLoginClick = { navController.navigate(RifaqDestination.LOGIN) },
                )
            }
            composable(RifaqDestination.LOGIN) {
                LoginScreen(
                    onLoginSuccess = {
                        navController.navigate(RifaqDestination.HOME) {
                            popUpTo(RifaqDestination.WELCOME) { inclusive = true }
                        }
                    },
                )
            }
            composable(RifaqDestination.HOME) { HomeRoute() }
            composable(RifaqDestination.CHATS) { ChatRoute() }
            composable(RifaqDestination.POSTS) { PostsRoute() }
            composable(RifaqDestination.GROUPS) { GroupsRoute() }
            composable(RifaqDestination.PROFILE) {
                ProfileRoute(onOpenSettings = { navController.navigate(RifaqDestination.SETTINGS) })
            }
            composable(RifaqDestination.SETTINGS) {
                SettingsScreen(
                    darkMode = darkMode,
                    onDarkModeChange = onDarkModeChange,
                    onBack = { navController.popBackStack() },
                )
            }
        }
    }
}
