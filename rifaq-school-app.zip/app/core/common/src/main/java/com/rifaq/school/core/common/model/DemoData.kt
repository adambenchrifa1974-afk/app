package com.rifaq.school.core.common.model

/**
 * بيانات تجريبية لعرض الواجهات فقط. ستُستبدل بمصدر بيانات حقيقي (شبكة/قاعدة بيانات)
 * عند بناء وحدتي network وdatabase.
 */
object DemoData {
    val user = UserProfile(
        name = "أحمد السعيدي",
        role = "طالب في ثانوية ابن رشد",
        posts = 42,
        followers = 124,
        following = 98,
    )

    val stories = listOf(
        Story(0, "قصتي", isMine = true),
        Story(1, "سارة"),
        Story(2, "يوسف"),
        Story(3, "مريم"),
        Story(4, "ليلى"),
    )

    val posts = listOf(
        Post(
            id = 1,
            authorName = "أحمد السعيدي",
            authorRole = "طالب",
            timeAgo = "منذ ساعتين",
            text = "كانت تجربة رائعة في مسابقة العلوم اليوم! شكرًا لكل من ساهم في التنظيم.",
            likes = 48, comments = 12, cover = 0,
        ),
        Post(
            id = 2,
            authorName = "مريم العلوي",
            authorRole = "طالبة",
            timeAgo = "منذ 3 ساعات",
            text = "هنا حل التمرين رقم 5 من الصفحة 12، لمن يريد المراجعة قبل الاختبار.",
            likes = 15, comments = 15, cover = 3,
        ),
        Post(
            id = 3,
            authorName = "الأستاذ كريم",
            authorRole = "أستاذ الرياضيات",
            timeAgo = "أمس",
            text = "تذكير: امتحان الرياضيات يوم الإثنين القادم، بالتوفيق للجميع.",
            likes = 63, comments = 9, cover = null,
        ),
        Post(
            id = 4,
            authorName = "سارة محمد",
            authorRole = "طالبة",
            timeAgo = "منذ 5 ساعات",
            text = "صور من رحلة النادي العلمي إلى المتحف، كانت رحلة ممتعة ومفيدة!",
            likes = 87, comments = 21, cover = 2,
        ),
        Post(
            id = 5,
            authorName = "يوسف",
            authorRole = "طالب",
            timeAgo = "أمس",
            text = "نتيجة مباراة الأقسام: فاز فريقنا 3-1، شكرًا لكل من شجّعنا.",
            likes = 54, comments = 8, cover = 1,
        ),
    )

    val comments = listOf(
        Comment("سارة محمد", "مبروك يا أحمد! تستحق ذلك"),
        Comment("يوسف", "كان عرضكم من أجمل العروض"),
        Comment("مريم العلوي", "شكرًا على المشاركة، أين الصور الأخرى؟"),
    )

    val chats = listOf(
        ChatPreview(1, "أصدقاء القسم", "سارة: تمام، سنلتقي غدًا", "10:24", 3),
        ChatPreview(2, "المحادثة الخاصة", "أحمد: شكرًا لك", "09:50", 1),
        ChatPreview(3, "مجموعة الرياضيات", "مريم: هل المسألة صعبة نوعًا ما؟", "09:12", 2),
        ChatPreview(4, "مجموعة العلوم", "يوسف: هذا مفيد جدًا", "08:45", 1),
        ChatPreview(5, "المكتبة المدرسية", "تم إرسال الملف", "أمس", 0),
        ChatPreview(6, "الإدارة", "إعلان: امتحان الرياضيات يوم الإثنين", "أمس", 0),
    )

    /** رسائل ابتدائية لمحادثة معيّنة (تجريبية). */
    fun messagesFor(chatId: Int): List<ChatMessage> {
        val chat = chats.firstOrNull { it.id == chatId } ?: return emptyList()
        return listOf(
            ChatMessage(1, "مرحبًا! هل راجعت درس اليوم؟", mine = false, time = "09:40"),
            ChatMessage(2, "نعم، سأرسل لك الملخص بعد قليل", mine = true, time = "09:42"),
            ChatMessage(3, chat.lastMessage.substringAfter(": "), mine = false, time = chat.time),
        )
    }

    val groups = listOf(
        GroupPreview(1, "قسم الرياضيات", "π", 24, 1),
        GroupPreview(2, "قسم الفيزياء", "Φ", 18, 3),
        GroupPreview(3, "قسم اللغة العربية", "ع", 27, 2),
        GroupPreview(4, "قسم الإنجليزية", "A", 21, 1),
        GroupPreview(5, "النشاطات المدرسية", "★", 15, 15),
    )

    val exploreCategories = listOf("الكل", "الدراسة", "المسابقات", "الفعاليات", "الرياضة", "الفن")

    val explore = listOf(
        ExploreItem(1, "ملخص درس الفيزياء: الحركة الدائرية", "مريم العلوي", 128, "الدراسة", 1.25f),
        ExploreItem(2, "صور من مسابقة العلوم", "أحمد السعيدي", 96, "المسابقات", 0.9f),
        ExploreItem(3, "جدول مباريات كرة القدم المدرسية", "يوسف", 74, "الرياضة", 1.1f),
        ExploreItem(4, "معرض الفنون التشكيلية", "ليلى", 211, "الفن", 1.4f),
        ExploreItem(5, "نصائح للمراجعة قبل الامتحانات", "الأستاذ كريم", 305, "الدراسة", 1.0f),
        ExploreItem(6, "رحلة النادي العلمي", "سارة محمد", 88, "الفعاليات", 1.2f),
        ExploreItem(7, "تحدي الرياضيات الأسبوعي", "مريم العلوي", 142, "المسابقات", 1.3f),
        ExploreItem(8, "تدريبات فريق السلة", "يوسف", 57, "الرياضة", 0.85f),
        ExploreItem(9, "ورشة الخط العربي", "ليلى", 119, "الفن", 1.15f),
        ExploreItem(10, "حفل نهاية الفصل", "سارة محمد", 173, "الفعاليات", 1.35f),
    )
}
