package com.rifaq.school.core.common.model

/**
 * بيانات تجريبية لعرض الواجهات فقط. ستُستبدل بمصدر بيانات حقيقي (شبكة/قاعدة بيانات)
 * عند بناء وحدتي network وdatabase.
 */
object DemoData {
    val user = UserProfile(
        name = "أحمد السعيدي",
        role = "طالب في ثانوية ابن رشد",
        posts = 42,
        followers = 124,
        following = 98,
    )

    val stories = listOf(
        Story(0, "قصتي", isMine = true),
        Story(1, "سارة"),
        Story(2, "يوسف"),
        Story(3, "مريم"),
        Story(4, "ليلى"),
    )

    val posts = listOf(
        Post(
            id = 1,
            authorName = "أحمد السعيدي",
            authorRole = "طالب",
            timeAgo = "منذ ساعتين",
            text = "كانت تجربة رائعة في مسابقة العلوم اليوم! شكرًا لكل من ساهم في التنظيم.",
            likes = 48, comments = 12, hasImage = true,
        ),
        Post(
            id = 2,
            authorName = "مريم العلوي",
            authorRole = "طالبة",
            timeAgo = "منذ 3 ساعات",
            text = "هنا حل التمرين رقم 5 من الصفحة 12، لمن يريد المراجعة قبل الاختبار.",
            likes = 15, comments = 15, hasImage = true,
        ),
        Post(
            id = 3,
            authorName = "الأستاذ كريم",
            authorRole = "أستاذ الرياضيات",
            timeAgo = "أمس",
            text = "تذكير: امتحان الرياضيات يوم الإثنين القادم، بالتوفيق للجميع.",
            likes = 63, comments = 9, hasImage = false,
        ),
    )

    val chats = listOf(
        ChatPreview(1, "أصدقاء القسم", "سارة: تمام، سنلتقي غدًا", "10:24", 3),
        ChatPreview(2, "المحادثة الخاصة", "أحمد: شكرًا لك", "09:50", 1),
        ChatPreview(3, "مجموعة الرياضيات", "مريم: هل المسألة صعبة نوعًا ما؟", "09:12", 2),
        ChatPreview(4, "مجموعة العلوم", "يوسف: هذا مفيد جدًا", "08:45", 1),
        ChatPreview(5, "المكتبة المدرسية", "تم إرسال الملف", "أمس", 0),
        ChatPreview(6, "الإدارة", "إعلان: امتحان الرياضيات يوم الإثنين", "أمس", 0),
    )

    val groups = listOf(
        GroupPreview(1, "قسم الرياضيات", "π", 24, 1),
        GroupPreview(2, "قسم الفيزياء", "Φ", 18, 3),
        GroupPreview(3, "قسم اللغة العربية", "ع", 27, 2),
        GroupPreview(4, "قسم الإنجليزية", "A", 21, 1),
        GroupPreview(5, "النشاطات المدرسية", "★", 15, 15),
    )
}
