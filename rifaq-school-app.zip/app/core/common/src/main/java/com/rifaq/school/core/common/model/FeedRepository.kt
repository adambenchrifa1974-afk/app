package com.rifaq.school.core.common.model

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * مصدر منشورات الرئيسية في الذاكرة فقط (يُفقد عند إغلاق التطبيق).
 * سيُستبدل لاحقًا بمستودع حقيقي مدعوم بالشبكة وقاعدة البيانات.
 */
object FeedRepository {
    private val _posts = MutableStateFlow(DemoData.posts)
    val posts: StateFlow<List<Post>> = _posts.asStateFlow()

    fun addPost(text: String, cover: Int?) {
        val user = DemoData.user
        _posts.update { current ->
            val nextId = (current.maxOfOrNull { it.id } ?: 0) + 1
            listOf(
                Post(
                    id = nextId,
                    authorName = user.name,
                    authorRole = "طالب",
                    timeAgo = "الآن",
                    text = text.trim(),
                    likes = 0,
                    comments = 0,
                    cover = cover,
                ),
            ) + current
        }
    }
}
