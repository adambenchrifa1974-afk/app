package com.rifaq.school.core.common.model

data class UserProfile(
    val name: String,
    val role: String,
    val posts: Int,
    val followers: Int,
    val following: Int,
) {
    val firstName: String get() = name.substringBefore(' ')
}

data class Story(val id: Int, val name: String, val isMine: Boolean = false)

/** [cover] رقم الغلاف الملوّن للصورة، أو null إذا كان المنشور نصيًا فقط. */
data class Post(
    val id: Int,
    val authorName: String,
    val authorRole: String,
    val timeAgo: String,
    val text: String,
    val likes: Int,
    val comments: Int,
    val cover: Int?,
)

data class Comment(val author: String, val text: String)

data class ChatPreview(
    val id: Int,
    val name: String,
    val lastMessage: String,
    val time: String,
    val unread: Int,
)

data class ChatMessage(val id: Int, val text: String, val mine: Boolean, val time: String)

data class GroupPreview(
    val id: Int,
    val name: String,
    val symbol: String,
    val members: Int,
    val posts: Int,
)

data class ExploreItem(
    val id: Int,
    val title: String,
    val author: String,
    val likes: Int,
    val category: String,
    /** نسبة الارتفاع إلى العرض لبطاقة الصورة. */
    val ratio: Float,
)
