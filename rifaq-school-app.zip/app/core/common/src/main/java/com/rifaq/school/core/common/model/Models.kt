package com.rifaq.school.core.common.model

data class UserProfile(
    val name: String,
    val role: String,
    val posts: Int,
    val followers: Int,
    val following: Int,
) {
    val firstName: String get() = name.substringBefore(' ')
}

data class Story(val id: Int, val name: String, val isMine: Boolean = false)

data class Post(
    val id: Int,
    val authorName: String,
    val authorRole: String,
    val timeAgo: String,
    val text: String,
    val likes: Int,
    val comments: Int,
    val hasImage: Boolean,
)

data class ChatPreview(
    val id: Int,
    val name: String,
    val lastMessage: String,
    val time: String,
    val unread: Int,
)

data class GroupPreview(
    val id: Int,
    val name: String,
    val symbol: String,
    val members: Int,
    val posts: Int,
)
