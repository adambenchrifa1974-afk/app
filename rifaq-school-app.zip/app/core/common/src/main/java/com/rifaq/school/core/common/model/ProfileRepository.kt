package com.rifaq.school.core.common.model

import com.rifaq.school.core.common.storage.LocalStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** الملف الشخصي المحفوظ على هذا الجهاز. سيرتبط بحساب حقيقي عند إضافة الخادم. */
object ProfileRepository {
    private val _profile = MutableStateFlow(DemoData.user)
    val profile: StateFlow<UserProfile> = _profile.asStateFlow()
    private var loaded = false

    fun load() {
        if (loaded) return
        loaded = true
        val saved = DemoData.user
        _profile.value = saved.copy(
            name = LocalStore.getString("profile_name", saved.name),
            role = LocalStore.getString("profile_role", saved.role),
        )
    }

    fun update(name: String, role: String) {
        val cleanName = name.trim()
        if (cleanName.isEmpty()) return
        val cleanRole = role.trim()
        _profile.update { it.copy(name = cleanName, role = cleanRole) }
        LocalStore.putString("profile_name", cleanName)
        LocalStore.putString("profile_role", cleanRole)
    }
}
