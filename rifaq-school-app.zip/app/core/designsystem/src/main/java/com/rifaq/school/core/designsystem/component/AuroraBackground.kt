package com.rifaq.school.core.designsystem.component

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** خلفية من بقع ضوئية ناعمة تتحرك ببطء كالماء، تُستعمل خلف الأسطح الزجاجية. */
@Composable
fun AuroraBackground(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "aurora")
    val drift by transition.animateFloat(
        initialValue = -24f,
        targetValue = 24f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 7000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "drift",
    )
    fun orb(color: Color) = Brush.radialGradient(listOf(color, Color.Transparent))

    Box(modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Box(
            Modifier
                .align(Alignment.TopStart)
                .offset(x = (-90 + drift).dp, y = (-70 - drift).dp)
                .size(340.dp)
                .background(orb(Color(0xFF2ED3B7).copy(alpha = 0.55f)), CircleShape),
        )
        Box(
            Modifier
                .align(Alignment.CenterEnd)
                .offset(x = (100 - drift).dp, y = (-60 + drift).dp)
                .size(300.dp)
                .background(orb(Color(0xFF0E9F7E).copy(alpha = 0.45f)), CircleShape),
        )
        Box(
            Modifier
                .align(Alignment.BottomStart)
                .offset(x = (-110 + drift).dp, y = (110 + drift).dp)
                .size(360.dp)
                .background(orb(Color(0xFFB8E65A).copy(alpha = 0.40f)), CircleShape),
        )
    }
}
