package com.rifaq.school.core.designsystem.component

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.rifaq.school.core.designsystem.theme.StoryRingGradient

private val LikeRed = Color(0xFFFF3B5C)

/**
 * منشور بأسلوب إنستغرام: ترويسة، صورة بعرض الشاشة، أزرار تفاعل، ثم وصف.
 * النقر مرتين على الصورة يضيف إعجابًا. [imageSeed] غير فارغ يعني أن للمنشور صورة
 * (تُعرض حاليًا كغلاف ملوّن).
 */
@Composable
fun PostCard(
    authorName: String,
    authorRole: String,
    timeAgo: String,
    text: String,
    likes: Int,
    comments: Int,
    imageSeed: Int?,
    modifier: Modifier = Modifier,
) {
    var liked by rememberSaveable { mutableStateOf(false) }
    var saved by rememberSaveable { mutableStateOf(false) }
    val heartScale by animateFloatAsState(if (liked) 1.18f else 1f, label = "heart")
    val scheme = MaterialTheme.colorScheme

    Column(modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(42.dp).border(2.dp, Brush.linearGradient(StoryRingGradient), CircleShape),
                contentAlignment = Alignment.Center,
            ) { RifaqAvatar(authorName, size = 34.dp) }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(authorName, style = MaterialTheme.typography.titleMedium)
                Text(
                    authorRole,
                    style = MaterialTheme.typography.bodyMedium,
                    color = scheme.onSurfaceVariant,
                )
            }
            Icon(Icons.Filled.MoreHoriz, contentDescription = null, tint = scheme.onSurface)
        }

        if (imageSeed != null) {
            RifaqCover(
                seed = imageSeed,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .pointerInput(Unit) { detectTapGestures(onDoubleTap = { liked = true }) },
            ) {
                Icon(
                    Icons.Outlined.Image, contentDescription = null,
                    tint = Color.White.copy(alpha = 0.75f), modifier = Modifier.size(56.dp),
                )
            }
        }

        Row(Modifier.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { liked = !liked }) {
                Icon(
                    if (liked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = "إعجاب",
                    tint = if (liked) LikeRed else scheme.onSurface,
                    modifier = Modifier.scale(heartScale),
                )
            }
            IconButton(onClick = {}) {
                Icon(Icons.Outlined.ChatBubbleOutline, contentDescription = "تعليق")
            }
            IconButton(onClick = {}) {
                Icon(Icons.AutoMirrored.Outlined.Send, contentDescription = "مشاركة")
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { saved = !saved }) {
                Icon(
                    if (saved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                    contentDescription = "حفظ",
                )
            }
        }

        Text(
            "${likes + if (liked) 1 else 0} إعجاب",
            modifier = Modifier.padding(horizontal = 14.dp),
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Bold,
        )
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(authorName) }
                append("  ")
                append(text)
            },
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp),
            style = MaterialTheme.typography.bodyLarge,
        )
        Text(
            "عرض جميع التعليقات ($comments)",
            modifier = Modifier.padding(horizontal = 14.dp),
            style = MaterialTheme.typography.bodyMedium,
            color = scheme.onSurfaceVariant,
        )
        Text(
            timeAgo,
            modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 2.dp, bottom = 18.dp),
            style = MaterialTheme.typography.bodyMedium,
            color = scheme.onSurfaceVariant,
        )
    }
}
