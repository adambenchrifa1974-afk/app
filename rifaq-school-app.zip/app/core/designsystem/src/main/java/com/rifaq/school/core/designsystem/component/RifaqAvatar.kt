package com.rifaq.school.core.designsystem.component

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val AvatarPalette = listOf(
    Color(0xFF0B5D44), Color(0xFF1FA39A), Color(0xFF2F7DA8),
    Color(0xFF7B5EA7), Color(0xFFC77D2E), Color(0xFFB04A5A),
)

/** صورة رمزية بالحرف الأول من الاسم، إلى حين ربط صور المستخدمين الحقيقية. */
@Composable
fun RifaqAvatar(name: String, modifier: Modifier = Modifier, size: Dp = 44.dp) {
    val color = AvatarPalette[Math.floorMod(name.hashCode(), AvatarPalette.size)]
    Box(
        modifier = modifier.size(size).clip(CircleShape).background(color),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = name.firstOrNull()?.toString() ?: "؟",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = (size.value * 0.42f).sp,
        )
    }
}
