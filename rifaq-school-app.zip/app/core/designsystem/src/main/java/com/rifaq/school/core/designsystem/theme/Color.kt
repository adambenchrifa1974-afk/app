package com.rifaq.school.core.designsystem.theme

import androidx.compose.ui.graphics.Color

// الوضع الفاتح
val GreenDeep = Color(0xFF0B5D44)
val GreenContainer = Color(0xFFD6EFE4)
val Teal = Color(0xFF1FA39A)
val TealContainer = Color(0xFFCBEFEA)
val BackgroundLight = Color(0xFFF3F6F5)
val FieldLight = Color(0xFFEAF0EE)
val OutlineLight = Color(0xFFD5DEDB)
val TextLight = Color(0xFF14201C)
val TextMutedLight = Color(0xFF66766F)

// الوضع الداكن
val BackgroundDark = Color(0xFF081E1C)
val SurfaceDark = Color(0xFF0E2926)
val FieldDark = Color(0xFF153531)
val OutlineDark = Color(0xFF24433F)
val HeaderDark = Color(0xFF0B3B33)
val TealOnDark = Color(0xFF2FB5A5)
val TextDark = Color(0xFFE3EEEA)
val TextMutedDark = Color(0xFF9DB4AF)
