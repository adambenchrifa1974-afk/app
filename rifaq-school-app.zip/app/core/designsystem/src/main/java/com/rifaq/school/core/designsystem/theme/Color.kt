package com.rifaq.school.core.designsystem.theme

import androidx.compose.ui.graphics.Color

val GreenDeep = Color(0xFF0B5D44)
val Teal = Color(0xFF14B8A0)
val GreenContainer = Color(0xFFD6EFE4)
val TealContainer = Color(0xFFCBEFEA)

val BackgroundLight = Color.White
val SurfaceVariantLight = Color(0xFFF2F4F3)
val OutlineLight = Color(0xFFE3E8E6)
val TextLight = Color(0xFF111917)
val TextMutedLight = Color(0xFF6E7B77)

val BackgroundDark = Color(0xFF0A0F0E)
val SurfaceDark = Color(0xFF121A18)
val SurfaceVariantDark = Color(0xFF1B2623)
val OutlineDark = Color(0xFF26332F)
val TealOnDark = Color(0xFF2ED3B7)
val HeaderDark = Color(0xFF0B3B33)
val TextDark = Color(0xFFE8F0ED)
val TextMutedDark = Color(0xFF93A6A0)

val BrandGradient = listOf(Color(0xFF14B8A0), Color(0xFF0B7A5C))
val StoryRingGradient = listOf(Color(0xFFB8E65A), Color(0xFF2ED3B7), Color(0xFF0E9F7E))
val BadgeRed = Color(0xFFFA5151)
