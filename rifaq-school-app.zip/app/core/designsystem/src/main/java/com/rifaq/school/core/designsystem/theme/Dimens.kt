package com.rifaq.school.core.designsystem.theme

import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** مساحة أسفل القوائم حتى لا يغطي شريط التنقل العائم آخر عنصر. */
val BottomBarSpace: Dp = 112.dp
