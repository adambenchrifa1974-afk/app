package com.rifaq.school.core.designsystem.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

// ملاحظة: يُستخدم لون tertiary كلون ترويسة الشاشات (أخضر داكن في الوضعين).
private val LightColors = lightColorScheme(
    primary = GreenDeep,
    onPrimary = Color.White,
    primaryContainer = GreenContainer,
    onPrimaryContainer = GreenDeep,
    secondary = Teal,
    onSecondary = Color.White,
    secondaryContainer = TealContainer,
    onSecondaryContainer = GreenDeep,
    tertiary = GreenDeep,
    onTertiary = Color.White,
    background = BackgroundLight,
    onBackground = TextLight,
    surface = Color.White,
    onSurface = TextLight,
    surfaceVariant = FieldLight,
    onSurfaceVariant = TextMutedLight,
    outline = OutlineLight,
)

private val DarkColors = darkColorScheme(
    primary = TealOnDark,
    onPrimary = Color(0xFF03211C),
    primaryContainer = HeaderDark,
    onPrimaryContainer = Color(0xFFBDEFE6),
    secondary = TealOnDark,
    onSecondary = Color(0xFF03211C),
    secondaryContainer = FieldDark,
    onSecondaryContainer = Color(0xFFBDEFE6),
    tertiary = HeaderDark,
    onTertiary = Color.White,
    background = BackgroundDark,
    onBackground = TextDark,
    surface = SurfaceDark,
    onSurface = TextDark,
    surfaceVariant = FieldDark,
    onSurfaceVariant = TextMutedDark,
    outline = OutlineDark,
)

/** اللغة الأساسية عربية، لذلك يُفرض الاتجاه RTL على كامل الواجهة. */
@Composable
fun RifaqTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = if (darkTheme) DarkColors else LightColors,
            typography = RifaqTypography,
            content = content,
        )
    }
}
