package com.rifaq.school.core.navigation

object RifaqDestination {
    const val WELCOME = "welcome"
    const val LOGIN = "login"
    const val HOME = "home"
    const val CHATS = "chats"
    const val POSTS = "posts"
    const val GROUPS = "groups"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"
    const val CREATE = "create"

    const val CHAT_ID_ARG = "id"
    const val CHAT_DETAIL = "chat/{$CHAT_ID_ARG}"
    fun chatDetail(id: Int) = "chat/$id"
}
