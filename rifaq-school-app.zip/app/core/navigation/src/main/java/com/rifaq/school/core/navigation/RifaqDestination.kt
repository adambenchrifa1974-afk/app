package com.rifaq.school.core.navigation

object RifaqDestination {
    const val WELCOME = "welcome"
    const val LOGIN = "login"
    const val HOME = "home"
    const val CHATS = "chats"
    const val POSTS = "posts"
    const val GROUPS = "groups"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"
}
