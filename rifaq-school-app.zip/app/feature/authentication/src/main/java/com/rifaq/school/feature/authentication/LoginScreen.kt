package com.rifaq.school.feature.authentication

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rifaq.school.core.designsystem.component.AuroraBackground
import com.rifaq.school.core.designsystem.component.RifaqLogo
import com.rifaq.school.core.designsystem.component.RifaqOutlinedButton
import com.rifaq.school.core.designsystem.component.RifaqPrimaryButton
import com.rifaq.school.core.designsystem.component.RifaqTextField
import com.rifaq.school.core.designsystem.component.backdropSource
import com.rifaq.school.core.designsystem.component.glass
import com.rifaq.school.core.designsystem.component.rememberBackdropState
import kotlinx.coroutines.launch

private const val NOT_AVAILABLE = "هذه الميزة غير متاحة بعد"

@Composable
fun LoginScreen(onLoginSuccess: () -> Unit, viewModel: LoginViewModel = viewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val scheme = MaterialTheme.colorScheme
    val backdrop = rememberBackdropState()
    fun notAvailable() { scope.launch { snackbar.showSnackbar(NOT_AVAILABLE) } }

    Box(Modifier.fillMaxSize()) {
    AuroraBackground(Modifier.backdropSource(backdrop))
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = Color.Transparent,
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(16.dp))
            RifaqLogo(size = 84.dp)
            Text(
                "رفاق المدرسة",
                modifier = Modifier.padding(top = 6.dp),
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = scheme.primary,
            )
            Spacer(Modifier.height(24.dp))
            Column(
                Modifier
                    .fillMaxWidth()
                    .glass(
                        state = backdrop,
                        shape = RoundedCornerShape(28.dp),
                        tint = scheme.surface.copy(alpha = 0.5f),
                        borderColor = scheme.onSurface.copy(alpha = 0.12f),
                    )
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
            Text(
                "مرحبًا بك مجددًا",
                modifier = Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.headlineMedium,
            )
            Text(
                "سجّل دخولك للمتابعة",
                modifier = Modifier.fillMaxWidth().padding(top = 2.dp, bottom = 20.dp),
                style = MaterialTheme.typography.bodyMedium,
                color = scheme.onSurfaceVariant,
            )

            RifaqTextField(
                value = state.identifier,
                onValueChange = viewModel::onIdentifierChange,
                placeholder = "البريد الإلكتروني أو رقم الهاتف",
                leadingIcon = Icons.Outlined.Email,
                keyboardType = KeyboardType.Email,
            )
            Spacer(Modifier.height(12.dp))
            RifaqTextField(
                value = state.password,
                onValueChange = viewModel::onPasswordChange,
                placeholder = "كلمة المرور",
                leadingIcon = Icons.Outlined.Lock,
                keyboardType = KeyboardType.Password,
                visualTransformation = if (state.passwordVisible) VisualTransformation.None
                else PasswordVisualTransformation(),
                trailing = {
                    IconButton(onClick = viewModel::togglePasswordVisible) {
                        Icon(
                            if (state.passwordVisible) Icons.Outlined.VisibilityOff
                            else Icons.Outlined.Visibility,
                            contentDescription = "إظهار أو إخفاء كلمة المرور",
                        )
                    }
                },
            )
            if (state.error != null) {
                Text(
                    state.error!!,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    style = MaterialTheme.typography.bodyMedium,
                    color = scheme.error,
                )
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Checkbox(checked = state.rememberMe, onCheckedChange = viewModel::onRememberChange)
                Text("تذكّرني", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                TextButton(onClick = ::notAvailable) { Text("نسيت كلمة المرور؟") }
            }

            RifaqPrimaryButton("تسجيل الدخول", onClick = { if (viewModel.submit()) onLoginSuccess() })

            Row(
                Modifier.fillMaxWidth().padding(vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                HorizontalDivider(Modifier.weight(1f), color = scheme.outline)
                Text("أو", color = scheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                HorizontalDivider(Modifier.weight(1f), color = scheme.outline)
            }

            RifaqOutlinedButton("تسجيل الدخول باستخدام Google", onClick = ::notAvailable)

            Row(
                Modifier.padding(vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "ليس لديك حساب؟",
                    style = MaterialTheme.typography.bodyMedium,
                    color = scheme.onSurfaceVariant,
                )
                TextButton(onClick = ::notAvailable) { Text("إنشاء حساب جديد") }
            }
            }
        }
    }
    }
}
