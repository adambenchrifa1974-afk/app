package com.rifaq.school.feature.authentication

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class LoginUiState(
    val identifier: String = "",
    val password: String = "",
    val passwordVisible: Boolean = false,
    val rememberMe: Boolean = false,
    val error: String? = null,
)

/**
 * التحقق هنا محلي فقط؛ لا يوجد خادم أو مصادقة حقيقية بعد.
 * ستُربط شاشة الدخول بنظام المصادقة لاحقًا.
 */
class LoginViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState: StateFlow<LoginUiState> = _uiState.asStateFlow()

    fun onIdentifierChange(value: String) = _uiState.update { it.copy(identifier = value, error = null) }
    fun onPasswordChange(value: String) = _uiState.update { it.copy(password = value, error = null) }
    fun togglePasswordVisible() = _uiState.update { it.copy(passwordVisible = !it.passwordVisible) }
    fun onRememberChange(value: Boolean) = _uiState.update { it.copy(rememberMe = value) }

    /** يُرجع true إذا كانت المدخلات صالحة شكليًا. */
    fun submit(): Boolean {
        val s = _uiState.value
        val error = when {
            s.identifier.isBlank() -> "أدخل البريد الإلكتروني أو رقم الهاتف"
            s.password.length < 6 -> "كلمة المرور يجب ألا تقل عن 6 أحرف"
            else -> null
        }
        _uiState.update { it.copy(error = error) }
        return error == null
    }
}
