package com.rifaq.school.feature.authentication

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rifaq.school.core.designsystem.component.RifaqLogo
import com.rifaq.school.core.designsystem.component.RifaqPrimaryButton
import com.rifaq.school.core.designsystem.component.SchoolIllustration

@Composable
fun WelcomeScreen(onStart: () -> Unit, onLoginClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(scheme.primaryContainer.copy(alpha = 0.55f), scheme.background)))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.weight(1f))
        RifaqLogo(size = 120.dp)
        Text(
            "رفاق المدرسة",
            modifier = Modifier.padding(top = 12.dp),
            fontSize = 40.sp,
            fontWeight = FontWeight.Bold,
            color = scheme.primary,
        )
        Text(
            "معًا نحو مستقبل أفضل",
            modifier = Modifier.padding(top = 4.dp),
            style = MaterialTheme.typography.bodyLarge,
            color = scheme.onSurfaceVariant,
        )
        Spacer(Modifier.weight(1f))
        SchoolIllustration()
        Spacer(Modifier.weight(1f))
        RifaqPrimaryButton("ابدأ الآن", onStart)
        Row(
            Modifier.padding(top = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "لديك حساب بالفعل؟",
                style = MaterialTheme.typography.bodyMedium,
                color = scheme.onSurfaceVariant,
            )
            TextButton(onClick = onLoginClick) { Text("تسجيل الدخول") }
        }
    }
}
