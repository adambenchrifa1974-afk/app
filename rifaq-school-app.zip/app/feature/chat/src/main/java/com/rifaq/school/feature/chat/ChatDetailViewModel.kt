package com.rifaq.school.feature.chat

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import com.rifaq.school.core.common.model.ChatMessage
import com.rifaq.school.core.common.model.ChatPreview
import com.rifaq.school.core.common.model.DemoData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** المحادثة محلية في الذاكرة فقط؛ لا يوجد خادم، فلا تصل الرسائل لأحد. */
class ChatDetailViewModel(savedStateHandle: SavedStateHandle) : ViewModel() {
    private val chatId: Int = savedStateHandle.get<Int>("id") ?: 0

    val chat: ChatPreview? = DemoData.chats.firstOrNull { it.id == chatId }

    private val _messages = MutableStateFlow(DemoData.messagesFor(chatId))
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        _messages.update { current ->
            current + ChatMessage(
                id = (current.maxOfOrNull { it.id } ?: 0) + 1,
                text = clean,
                mine = true,
                time = "الآن",
            )
        }
    }
}
