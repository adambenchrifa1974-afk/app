package com.rifaq.school.feature.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rifaq.school.core.common.model.ChatPreview
import com.rifaq.school.core.common.model.DemoData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

data class ChatUiState(
    val query: String = "",
    val chats: List<ChatPreview> = DemoData.chats,
)

class ChatViewModel : ViewModel() {
    private val query = MutableStateFlow("")

    val uiState: StateFlow<ChatUiState> = query
        .map { q -> ChatUiState(q, filter(q)) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ChatUiState())

    fun onQueryChange(value: String) {
        query.value = value
    }

    private fun filter(q: String): List<ChatPreview> {
        val term = q.trim()
        if (term.isEmpty()) return DemoData.chats
        return DemoData.chats.filter { it.name.contains(term) || it.lastMessage.contains(term) }
    }
}
