package com.rifaq.school.feature.groups

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rifaq.school.core.common.model.DemoData
import com.rifaq.school.core.common.model.GroupPreview
import com.rifaq.school.core.designsystem.component.RifaqCover
import com.rifaq.school.core.designsystem.component.RifaqHeader
import com.rifaq.school.core.designsystem.theme.BottomBarSpace
import com.rifaq.school.core.designsystem.theme.BrandGradient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class GroupsUiState(val groups: List<GroupPreview> = DemoData.groups)

class GroupsViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(GroupsUiState())
    val uiState: StateFlow<GroupsUiState> = _uiState.asStateFlow()
}

@Composable
fun GroupsRoute(viewModel: GroupsViewModel = viewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        RifaqHeader(
            title = "المجموعات",
            trailing = {
                IconButton(onClick = {}) {
                    Icon(Icons.Filled.Add, contentDescription = "مجموعة جديدة")
                }
            },
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 12.dp + BottomBarSpace),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(state.groups, key = { it.id }) { GroupCard(it) }
        }
    }
}

@Composable
private fun GroupCard(group: GroupPreview) {
    var joined by rememberSaveable(group.id) { mutableStateOf(false) }
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Column {
            RifaqCover(seed = group.id, modifier = Modifier.fillMaxWidth().height(96.dp)) {
                Text(
                    group.symbol,
                    color = Color.White,
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
            Column(Modifier.padding(10.dp)) {
                Text(
                    group.name,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    "${group.members} عضو • ${group.posts} منشور",
                    style = MaterialTheme.typography.bodyMedium,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                JoinPill(joined = joined, onClick = { joined = !joined })
            }
        }
    }
}

@Composable
private fun JoinPill(joined: Boolean, onClick: () -> Unit) {
    val base = Modifier.fillMaxWidth().height(34.dp).clip(CircleShape)
    Box(
        modifier = (
            if (joined) base.border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
            else base.background(Brush.horizontalGradient(BrandGradient))
            ).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            if (joined) "منضم" else "انضمام",
            color = if (joined) MaterialTheme.colorScheme.onSurfaceVariant else Color.White,
            fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp,
        )
    }
}
