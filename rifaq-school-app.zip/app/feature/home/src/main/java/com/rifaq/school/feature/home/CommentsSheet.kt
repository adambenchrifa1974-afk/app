package com.rifaq.school.feature.home

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rifaq.school.core.common.model.Comment
import com.rifaq.school.core.common.model.DemoData
import com.rifaq.school.core.common.model.Post
import com.rifaq.school.core.designsystem.component.RifaqAvatar

/** قائمة تعليقات سفلية. التعليقات الجديدة تُضاف محليًا فقط (لا يوجد خادم بعد). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun CommentsSheet(post: Post, onDismiss: () -> Unit) {
    val comments = remember(post.id) {
        mutableStateListOf<Comment>().apply { addAll(DemoData.comments) }
    }
    var draft by rememberSaveable { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        Column(Modifier.fillMaxWidth().imePadding().navigationBarsPadding()) {
            Text(
                "التعليقات (${comments.size})",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                style = MaterialTheme.typography.titleMedium,
            )
            LazyColumn(Modifier.weight(1f, fill = false).heightIn(max = 360.dp)) {
                items(comments) { comment -> CommentRow(comment) }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("أضف تعليقًا...") },
                    singleLine = true,
                    shape = RoundedCornerShape(26.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                    ),
                )
                TextButton(
                    onClick = {
                        val text = draft.trim()
                        if (text.isNotEmpty()) {
                            comments.add(Comment(DemoData.user.name, text))
                            draft = ""
                        }
                    },
                    enabled = draft.isNotBlank(),
                ) { Text("نشر", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun CommentRow(comment: Comment) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        RifaqAvatar(comment.author, size = 34.dp)
        Column(Modifier.padding(horizontal = 10.dp)) {
            Text(comment.author, style = MaterialTheme.typography.titleMedium)
            Text(comment.text, style = MaterialTheme.typography.bodyLarge)
        }
    }
}
