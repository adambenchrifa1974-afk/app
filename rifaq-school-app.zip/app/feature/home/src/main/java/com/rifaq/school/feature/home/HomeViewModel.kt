package com.rifaq.school.feature.home

import androidx.lifecycle.ViewModel
import com.rifaq.school.core.common.model.DemoData
import com.rifaq.school.core.common.model.FeedRepository
import com.rifaq.school.core.common.model.Post
import com.rifaq.school.core.common.model.Story
import com.rifaq.school.core.common.model.UserProfile
import kotlinx.coroutines.flow.StateFlow

class HomeViewModel : ViewModel() {
    val user: UserProfile = DemoData.user
    val stories: List<Story> = DemoData.stories
    val posts: StateFlow<List<Post>> = FeedRepository.posts
}
