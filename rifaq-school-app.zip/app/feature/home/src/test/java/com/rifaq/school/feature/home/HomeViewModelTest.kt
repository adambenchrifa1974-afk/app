package com.rifaq.school.feature.home

import org.junit.Assert.assertTrue
import org.junit.Test

class HomeViewModelTest {
    @Test
    fun initialState_hasStoriesAndPosts() {
        val state = HomeViewModel().uiState.value
        assertTrue(state.stories.isNotEmpty())
        assertTrue(state.posts.isNotEmpty())
    }
}
