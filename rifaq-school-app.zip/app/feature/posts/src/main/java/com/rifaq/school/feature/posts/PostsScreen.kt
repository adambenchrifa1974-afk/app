package com.rifaq.school.feature.posts

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rifaq.school.core.common.model.DemoData
import com.rifaq.school.core.common.model.Post
import com.rifaq.school.core.designsystem.component.PostCard
import com.rifaq.school.core.designsystem.component.RifaqHeader
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class PostsUiState(val posts: List<Post> = DemoData.posts)

class PostsViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(PostsUiState())
    val uiState: StateFlow<PostsUiState> = _uiState.asStateFlow()
}

@Composable
fun PostsRoute(viewModel: PostsViewModel = viewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        RifaqHeader(title = "المنشورات")
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(state.posts, key = { it.id }) { post ->
                PostCard(
                    authorName = post.authorName,
                    authorRole = post.authorRole,
                    timeAgo = post.timeAgo,
                    text = post.text,
                    likes = post.likes,
                    comments = post.comments,
                    imageSeed = if (post.hasImage) post.id else null,
                    modifier = Modifier.padding(0.dp),
                )
            }
        }
    }
}
