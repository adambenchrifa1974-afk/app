package com.rifaq.school.feature.posts

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rifaq.school.core.common.model.DemoData
import com.rifaq.school.core.common.model.ExploreItem
import com.rifaq.school.core.designsystem.component.RifaqAvatar
import com.rifaq.school.core.designsystem.component.RifaqCover
import com.rifaq.school.core.designsystem.component.RifaqHeader
import com.rifaq.school.core.designsystem.component.RifaqSearchField
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class PostsUiState(
    val query: String = "",
    val categories: List<String> = DemoData.exploreCategories,
    val selected: String = DemoData.exploreCategories.first(),
    val items: List<ExploreItem> = DemoData.explore,
)

class PostsViewModel : ViewModel() {
    private val query = MutableStateFlow("")
    private val selected = MutableStateFlow(DemoData.exploreCategories.first())

    val uiState: StateFlow<PostsUiState> = combine(query, selected) { q, cat ->
        val term = q.trim()
        PostsUiState(
            query = q,
            selected = cat,
            items = DemoData.explore.filter {
                (cat == DemoData.exploreCategories.first() || it.category == cat) &&
                    (term.isEmpty() || it.title.contains(term))
            },
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), PostsUiState())

    fun onQueryChange(value: String) { query.value = value }
    fun onCategorySelected(value: String) { selected.value = value }
}

@Composable
fun PostsRoute(viewModel: PostsViewModel = viewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    PostsScreen(state, viewModel::onQueryChange, viewModel::onCategorySelected)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PostsScreen(
    state: PostsUiState,
    onQueryChange: (String) -> Unit,
    onCategorySelected: (String) -> Unit,
) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        RifaqHeader(title = "استكشف")
        RifaqSearchField(
            value = state.query,
            onValueChange = onQueryChange,
            placeholder = "ابحث في المنشورات",
            modifier = Modifier.padding(horizontal = 12.dp),
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(state.categories) { category ->
                val selected = category == state.selected
                Text(
                    category,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            if (selected) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceVariant,
                        )
                        .clickable { onCategorySelected(category) }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    color = if (selected) MaterialTheme.colorScheme.onPrimary
                    else MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.labelLarge,
                )
            }
        }
        if (state.items.isEmpty()) {
            Text(
                "لا توجد نتائج",
                modifier = Modifier.fillMaxWidth().padding(32.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            LazyVerticalStaggeredGrid(
                columns = StaggeredGridCells.Fixed(2),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalItemSpacing = 10.dp,
            ) {
                items(state.items, key = { it.id }) { ExploreTile(it) }
            }
        }
    }
}

@Composable
private fun ExploreTile(item: ExploreItem) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Column {
            RifaqCover(
                seed = item.id,
                modifier = Modifier.fillMaxWidth().aspectRatio(1f / item.ratio),
            ) {
                Text(
                    item.category,
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
            Text(
                item.title,
                modifier = Modifier.padding(start = 8.dp, end = 8.dp, top = 8.dp),
                style = MaterialTheme.typography.titleMedium,
                fontSize = 14.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Row(
                Modifier.padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RifaqAvatar(item.author, size = 20.dp)
                Text(
                    item.author,
                    modifier = Modifier.weight(1f).padding(horizontal = 6.dp),
                    style = MaterialTheme.typography.bodyMedium,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Icon(
                    Icons.Outlined.FavoriteBorder, contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(14.dp),
                )
                Text(
                    "${item.likes}",
                    modifier = Modifier.padding(start = 3.dp),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
