pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "RifaqSchool"

include(":app")
include(":core:common")
include(":core:designsystem")
include(":core:navigation")
include(":feature:home")
include(":feature:authentication")
include(":feature:posts")
include(":feature:chat")
include(":feature:groups")
include(":feature:profile")
include(":feature:planner")
include(":feature:challenges")
